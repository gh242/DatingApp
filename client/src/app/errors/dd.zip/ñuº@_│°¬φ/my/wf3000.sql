--select * from V$NLS_PARAMETERS; 


--*Cdate(Format(DateAdd("d", -1, today()), "yyyy-MM") & "-01 07:20:00");
--

--*to_date(''2019-11-27'',''yyyy-mm-dd'')
--*

--*SELECT (to_char(SYSDATE-1,'yyyy-mm') + "-01 07:20:00") FROM DUAL;

--SELECT to_date((to_char(SYSDATE-1,'yyyy-mm')||'-01 07:20:00'),'yyyy-MM-dd HH:mm:ss') FROM DUAL;

SELECT (to_char(SYSDATE-1,'yyyy-mm')||'-01 07:20:00') FROM DUAL;