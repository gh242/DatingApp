DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';


select 'Print_Date'=DateAdd(mi, 1760, @YYYYMMDD)
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
          ,'Normal'=-1*MANU_QTY
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'
AND MANU_FMLB='M'
and MANU_QTY>0
