USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with TempA as (
-- Copper
select 'Line'='Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,'FinalCleaner'=FinalCleaner  --FinalCleaner+FinalCleanSide
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by PreCleaner+PreCleanSide, FinalCleaner

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,'FinalCleaner'=FinalCleaner  --FinalCleaner+FinalCleanSide
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
--and LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by PreCleaner+PreCleanSide, FinalCleaner
)


select a.*
          ,'Yield'=1.0000*a.Pass/a.Total
from TempA a

GO

/*
執行時間為:20230719 10:16
產生結果如下 
Line	PreCleaner	FinalCleaner	Pass	Mech	Total	Yield
-----------------------------------------------------------------------------
Copper	    Ebara1R	ACM1	        220	    5	    307	    0.716612377850162
Copper	    Ebara3L	ACM1	        296	    7	    330	    0.896969696969696
Copper	    Ebara3R	ACM1	        356	    2	    385	    0.924675324675324
Copper	    FC3L	SC2	            16	    2	    24	    0.666666666666666
Copper	    FC3R	SC2	            14	    1	    24	    0.583333333333333
Copper	    Ebara1L	ACM1	        140	    3	    176	    0.795454545454545
Non-Copper	SCC1A	NULL	        473	    184	    807	    0.586121437422552
Non-Copper	N-	    NULL	        3	    0	    9	    0.333333333333333
Non-Copper	SCC1C	NULL	        507	    200	    860	    0.589534883720930
Non-Copper	Ebara4R	SCC1	        17	    6	    23	    0.739130434782608
Non-Copper	SCC1C	ACM1	        65	    11	    94	    0.691489361702127
Non-Copper	SCC1B	SCC1	        47	    20	    68	    0.691176470588235
Non-Copper	SCC1D	NULL	        513	    178	    834	    0.615107913669064
Non-Copper	Ebara4R	ACM1	        70	    5	    99	    0.707070707070707
Non-Copper	SCC1B	NULL	        508	    134	    770	    0.659740259740259
Non-Copper	Ebara4L	ACM1	        208	    0	    238	    0.873949579831932
Non-Copper	SCC1C	SCC1	        50	    10	    60	    0.833333333333333
Non-Copper	SCC1D	SCC1	        32	    16	    48	    0.666666666666666
Non-Copper	SCC1D	ACM1	        72	    17	    104	    0.692307692307692
Non-Copper	SCC1A	SCC1	        37	    25	    62	    0.596774193548387
Non-Copper	SCC1A	ACM1	        60	    15	    84	    0.714285714285714
Non-Copper	SCC1B	ACM1	        58	    14	    77	    0.753246753246753
*/