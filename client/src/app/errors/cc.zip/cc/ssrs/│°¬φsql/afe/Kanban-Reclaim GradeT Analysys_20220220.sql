USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230710';
DECLARE @DailyNo int;
SET @DailyNo = 14;


select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ProcessThickness
          ,'TotalQty'=count(*)
          ,'Tqty'=sum(case when WaferGrade='GradeT' then 1
		    else 0
		    end)    
          ,'Yield'=1.0000*sum(case when WaferGrade='GradeT' then 1
		     else 0
		     end) / count(*)
from EDA_Tencorlog with(nolock)
where ParticleSize1=19
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by [dbo].[RealDateToMfgDate](CollectionTime), cast(Polisher as varchar), PreCleaner+'+'+FinalCleaner, ProcessThickness

union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ProcessThickness
          ,'TotalQty'=count(*)
          ,'Tqty'=sum(case when WaferGrade='GradeT' then 1
		    else 0
		    end)    
          ,'Yield'=1.0000*sum(case when WaferGrade='GradeT' then 1
		     else 0
		     end) / count(*)
from EDA_Tencorlog with(nolock)
where ParticleSize1=19
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by [dbo].[RealDateToMfgDate](CollectionTime), PreCleaner+'+'+FinalCleaner, ProcessThickness

union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=' All'
          ,ProcessThickness
          ,'TotalQty'=count(*)
          ,'Tqty'=sum(case when WaferGrade='GradeT' then 1
		    else 0
		    end)    
          ,'Yield'=1.0000*sum(case when WaferGrade='GradeT' then 1
		     else 0
		     end) / count(*)
from EDA_Tencorlog with(nolock)
where ParticleSize1=19
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by [dbo].[RealDateToMfgDate](CollectionTime), cast(Polisher as varchar), ProcessThickness

union all
-- Non-Copper
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=' All'
          ,ProcessThickness
          ,'TotalQty'=count(*)
          ,'Tqty'=sum(case when WaferGrade='GradeT' then 1
		    else 0
		    end)    
          ,'Yield'=1.0000*sum(case when WaferGrade='GradeT' then 1
		     else 0
		     end) / count(*)
from EDA_Tencorlog with(nolock)
where ParticleSize1=19
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by [dbo].[RealDateToMfgDate](CollectionTime) ,ProcessThickness


GO