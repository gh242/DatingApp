USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230717';

DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;

with TempA as (
select Print_Date
         ,'HighT'=Qty
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer like 'V65%[T]'
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=Qty
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer like 'V65%[Q]'
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=Qty
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and ( FG_Customer like 'V65%P' or
          FG_Customer like 'V65%P2' or
          FG_Customer='180-ECLX8' or
          FG_Customer='180-ECLR8' or 
          FG_Customer='180-ECLT8' or
          FG_Customer='180-ECLX8' or
          FG_Customer='180-EALX8' or
          FG_Customer='180-ELR18' or
          FG_Customer='180-ELT08' 
         )
/*
執行時間為:20230720 10:08
產生結果如下 
Print_Date	            HighT	HighQ	HighP	Normal	Low
-----------------------------------------------------------
2023-07-18 04:04:41.000	0	    25	    0	    0	    0
2023-07-18 03:23:58.000	0	    25	    0	    0	    0
2023-07-18 06:41:11.000	0	    25	    0	    0	    0
2023-07-18 05:08:42.000	0	    25	    0	    0	    0
2023-07-17 21:19:12.000	0	    0	    25	    0	    0
2023-07-17 16:43:24.000	0	    0	    25	    0	    0
2023-07-17 23:09:09.000	0	    0	    25	    0	    0
*/

union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=Qty
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer not like 'V65%[PQT]'
and FG_Customer not like 'V65%P2'
and FG_Customer not like 'V650000[DF]%'
and FG_Customer not like 'V65000[67][DF]%'
and FG_Customer not like 'V6500[12][12][DF]%'
and FG_Customer<>'V65000013D'
and FG_Customer<>'V600001F'
and FG_Customer not like '02-14-0018'
and FG_Customer not like '02-14-002[1568]'
and FG_Customer not like '02-14-003[034]'
--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
and FG_Customer<>'180-ECLX8'     
and FG_Customer<>'180-ECLR8'
and FG_Customer<>'180-ECDR8'
and FG_Customer<>'180-ECDT8'
and FG_Customer<>'180-ECLT8'
and FG_Customer<>'180-ECLX8'
and FG_Customer<>'180-EALX8'
and FG_Customer<>'180-EDR38'
and FG_Customer<>'180-EDT38'
and FG_Customer<>'180-ELR18'
and FG_Customer<>'180-ELT08' 
and LotNo not like 'PSD2MZ_F[TX]%]'
/*
執行時間為:20230720 10:12
產生結果如下 
Print_Date	            HighT	HighQ	HighP	Normal	Low
-----------------------------------------------------------
2023-07-17 15:20:38.000	0	    0	    0	    25	    0
2023-07-17 21:50:45.000	0	    0	    0	    25	    0
2023-07-17 07:52:39.000	0	    0	    0	    25	    0
2023-07-18 06:20:13.000	0	    0	    0	    25	    0
2023-07-18 03:49:27.000	0	    0	    0	    25	    0
2023-07-17 16:31:23.000	0	    0	    0	    25	    0
2023-07-17 16:25:09.000	0	    0	    0	    25	    0
2023-07-17 13:02:34.000	0	    0	    0	    25	    0
2023-07-18 02:45:17.000	0	    0	    0	    25	    0
2023-07-17 23:16:02.000	0	    0	    0	    25	    0
2023-07-18 06:37:29.000	0	    0	    0	    25	    0
2023-07-17 16:51:18.000	0	    0	    0	    25	    0
2023-07-17 08:55:44.000	0	    0	    0	    25	    0
2023-07-18 01:40:14.000	0	    0	    0	    25	    0
2023-07-17 08:40:14.000	0	    0	    0	    25	    0
2023-07-17 09:17:59.000	0	    0	    0	    25	    0
2023-07-18 04:08:23.000	0	    0	    0	    25	    0
2023-07-18 01:09:17.000	0	    0	    0	    25	    0
2023-07-18 04:16:58.000	0	    0	    0	    25	    0
2023-07-17 20:51:07.000	0	    0	    0	    25	    0
...
*/

union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=Qty
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and ( FG_Customer like 'V650000[DF]%' or 
         FG_Customer like 'V65000[67][DF]%' or
         FG_Customer like 'V6500[12][12][DF]%' or
         FG_Customer='V65000013D' or
         FG_Customer='V600001F' or
         FG_Customer like '02-14-0018' or 
         FG_Customer like '02-14-002[1568]' or 
         FG_Customer like '02-14-003[034]' or
         FG_Customer='180-ECDR8' or
         FG_Customer='180-ECDT8' or
         FG_Customer='180-EDR38' or
         FG_Customer='180-EDT38' or
         LotNo like 'PSD2MZ_F[TX]%]')
union all
select 'Print_Date'=DateAdd(mi, 1760, @YYYYMMDD)
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
          ,'Normal'=-1*MANU_QTY   
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'  
AND MANU_FMLB='M'
and MANU_QTY>0
/*
執行時間為:20230720 10:14
產生結果如下 
Print_Date	            HighT	HighQ	HighP	Normal	Low
-----------------------------------------------------------
2023-07-19 12:21:21.000	0	    0	    0	    0	    25
2023-07-17 17:00:59.000	0	    0	    0	    0	    25
2023-07-17 23:14:23.000	0	    0	    0	    0	    25
2023-07-17 12:48:32.000	0	    0	    0	    0	    25
2023-07-17 21:32:17.000	0	    0	    0	    0	    25
2023-07-17 18:49:00.000	0	    0	    0	    0	    25
2023-07-18 00:05:53.000	0	    0	    0	    0	    25
2023-07-17 13:40:04.000	0	    0	    0	    0	    25
2023-07-17 09:39:59.000	0	    0	    0	    0	    25
2023-07-17 09:08:53.000	0	    0	    0	    0	    25
2023-07-18 05:20:00.000	0	    0	    0	    -23	    0
2023-07-18 05:20:00.000	0	    0	    0	    -24	    0
2023-07-18 05:20:00.000	0	    0	    0	    -25	    0
2023-07-18 05:20:00.000	0	    0	    0	    -50	    0
2023-07-18 05:20:00.000	0	    0	    0	    -50	    0
2023-07-18 05:20:00.000	0	    0	    0	    -50	    0
2023-07-18 05:20:00.000	0	    0	    0	    -50	    0
2023-07-18 05:20:00.000	0	    0	    0	    -50	    0
2023-07-18 05:20:00.000	0	    0	    0	    -75	    0
2023-07-18 05:20:00.000	0	    0	    0	    -100	0
2023-07-18 05:20:00.000	0	    0	    0	    -125	0
2023-07-18 05:20:00.000	0	    0	    0	    -146	0
2023-07-18 05:20:00.000	0	    0	    0	    -175	0
2023-07-18 05:20:00.000	0	    0	    0	    -442	0
...
*/
),
-- with
TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),
-- select * from TempB
/*
N
----
680
800
920
1040
1160
1280
1400
1520
1640
1760
1880
*/


tempC as (
select 'N'=(N-440)/120*@TargetOutput300mm/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)
-- select * from tempC
/*
執行時間為:20230720 10:16
產生結果如下 
N	    Interval
----------------------------
2133	2023-07-17 11:20:00
3200	2023-07-17 13:20:00
4266	2023-07-17 15:20:00
5333	2023-07-17 17:20:00
6400	2023-07-17 19:20:00
7466	2023-07-17 21:20:00
8533	2023-07-17 23:20:00
9600	2023-07-18 01:20:00
10666	2023-07-18 03:20:00
11733	2023-07-18 05:20:00
12800	2023-07-18 07:20:00
*/


select x.Interval
         ,'HighT'=case when DateAdd(mi, 120, getdate())>x.Interval then x.HighT
                             else null 
                             end 
         ,'HighQ'=case when DateAdd(mi, 120, getdate())>x.Interval then x.HighQ
                             else null 
                             end 
         ,'HighP'=case when DateAdd(mi, 120, getdate())>x.Interval then x.HighP
                             else null 
                             end 
         ,'Normal'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Normal
                                 else null 
                                 end
         ,'Low'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Low
                            else null 
                            end
         ,TargetQty
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
          ,'HighT'=sum(a.HighT) 
          ,'HighQ'=sum(a.HighQ) 
          ,'HighP'=sum(a.HighP) 
          ,'Normal'=sum(a.Normal)
          ,'Low'=sum(a.Low)
          ,'TargetQty'=@TargetOutput300mm/12
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD)
            )
union all
select 'Interval'=b.Interval
          ,'HighT'=sum(a.HighT) 
          ,'HighQ'=sum(a.HighQ) 
          ,'HighP'=sum(a.HighP) 
          ,'Normal'=sum(a.Normal)
          ,'Low'=sum(a.Low)
          ,'TargetQty'=b.N
from TempA a, tempC b
where (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<b.Interval)
group by b.Interval, b.N
) x

/*
執行時間為:20230720 10:23
產生結果如下 
-- Interval			    HightT  HightQ    HigthP    Normal   Low    TargetQty
-------------------------------------------------------------------------
2023-07-17 09:20:00	    0	    0	      150	    600	    400	    1066
2023-07-17 11:20:00	    0	    0	      300	    1150	550	    2133
2023-07-17 13:20:00	    0	    0	      400	    1750	875	    3200
2023-07-17 15:20:00	    0	    0	      550	    2275	1100	4266
2023-07-17 17:20:00	    0	    0	      875	    2800	1450	5333
2023-07-17 19:20:00	    0	    0	      925	    3375	1825	6400
2023-07-17 21:20:00	    0	    0	      1050	    3800	2075	7466
2023-07-17 23:20:00	    0	    0	      1175	    4200	2250	8533
2023-07-18 01:20:00	    0	    0	      1425	    4650	2475	9600
2023-07-18 03:20:00	    0	    0	      1550	    5175	2675	10666
2023-07-18 05:20:00	    0	    75	      1750	    5600	2975	11733
2023-07-18 07:20:00	    0	    100	      1850	    4715	3275	12800
*/