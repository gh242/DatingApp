USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
-- DECLARE @Mode VARCHAR(2);
-- SET @Mode = 'A';


with CTE    as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

--會傳回 Variant (Long)，指定兩個指定日期之間的時間間隔數目。
-- select DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) --14
-- select DateDiff(d, @YYYYMMDD-1*14, @YYYYMMDD) --14
-- select * from TempDay
/*
MFGDate
-------------------
2023-07-04 00:00:00
2023-07-03 00:00:00
2023-07-02 00:00:00
2023-07-01 00:00:00
2023-06-30 00:00:00
2023-06-29 00:00:00
2023-06-28 00:00:00
2023-06-27 00:00:00
2023-06-26 00:00:00
2023-06-25 00:00:00
2023-06-24 00:00:00
2023-06-23 00:00:00
2023-06-22 00:00:00
2023-06-21 00:00:00
2023-06-20 00:00:00
*/




-- Copper
-- with
/*
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'QtyT'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'PercentageT'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
          ,'QtyQ'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'PercentageQ'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
          ,'QtyP'=sum(case when WaferGrade='GradeP' then 1
	                      else 0
		      end)
          ,'PercentageP'=1.0000*sum(case when WaferGrade='GradeP' then 1
	                                            else 0
		                             end) / Count(*)
          ,'TotalQty'=Count(*)
from EDA_Tencorlog with(nolock)
where StationName='TENCOR_17'
and ( ParticleSize1 between 18 and 21)
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime)
)
*/
--,
--select * from TempC
-- 以上沒有資料


-- Non-Copper
--with

TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'QtyT'=sum(case when WaferGrade='GradeT' then 1
	                       else 0
		              end)
          ,'PercentageT'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                            end) / Count(*)
          ,'QtyQ'=sum(case when WaferGrade='GradeQ' then 1
	                       else 0
		              end)
          ,'PercentageQ'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                     else 0
		                             end) / Count(*)
          ,'QtyP'=sum(case when WaferGrade='GradeP' then 1
	                       else 0
		              end)
          ,'PercentageP'=1.0000*sum(case when WaferGrade='GradeP' then 1
	                                     else 0
		                            end) / Count(*)
          ,'TotalQty'=Count(*)
from EDA_Tencorlog with(nolock)
where StationName='TENCOR_17'
and ( ParticleSize1 between 18 and 21 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%' -- ?? 不是2_ 開頭的
group by dbo.RealDateToMfgDate(CollectionTime) -- 前一天
)

-- select * from TempD

/*
Line	    MFGDate	                QtyT	PercentageT	        QtyQ	PercentageQ	        QtyP	PercentageP	        TotalQty
--------------------------------------------------------------------------------------------------------------------------------
Non-Copper	2023-06-29 00:00:00.000	14	    0.482758620689655	10	    0.344827586206896	3	    0.103448275862068	29
Non-Copper	2023-06-30 00:00:00.000	261	    0.422330097087378	163	    0.263754045307443	41	    0.066343042071197	618
Non-Copper	2023-07-01 00:00:00.000	280	    0.563380281690140	160	    0.321931589537223	22	    0.044265593561368	497
*/

-- select * from EDA_Tencorlog
-- where 
-- StationName='TENCOR_17'
-- and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
-- and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)



-- Non-Copper

select a.MFGDate
         ,'Line'='Non-Copper'
         ,b.QtyT
         ,b.PercentageT
         ,b.QtyQ
         ,b.PercentageQ
         ,b.QtyP
         ,b.PercentageP
         ,b.TotalQty
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate


/*
-- 產生結果如下  20230717 執行時間，為20230717 16:04
MFGDate	            Line	    QtyT	PercentageT	        QtyQ	    PercentageQ	        QtyP	PercentageP	        TotalQty
--------------------------------------------------------------------------------------------------------------------------------
2023-06-29 00:00:00	Non-Copper	14	    0.482758620689655	10	        0.344827586206896	3	    0.103448275862068	29
2023-06-30 00:00:00	Non-Copper	261	    0.422330097087378	163	        0.263754045307443	41	    0.066343042071197	618
2023-07-01 00:00:00	Non-Copper	280	    0.563380281690140	160	        0.321931589537223	22	    0.044265593561368	497
2023-06-23 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-07-02 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-26 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-21 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-27 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-24 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-07-03 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-25 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-22 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-07-04 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-20 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
2023-06-28 00:00:00	Non-Copper	NULL	NULL	            NULL	    NULL	            NULL	NULL	            NULL
*/          