USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

-- 報表35-內容測試-DataSet_300mm555
-- 與 報表 40(815),45(700),50(680) 很像，MANU_FROM_EQUID 不同

with TempA as ( 
-- Non-Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Non-Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and (MANU_FROM_EQUID=700 or MANU_FROM_EQUID=701)
and (MANU_FROM_LOTNO like '[1-9]___[EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

union all
-- Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and (MANU_FROM_EQUID=700 or MANU_FROM_EQUID=701)
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

/*
執行時間為:20230721 13:27
產生結果如下 
Print_Date	            Line	      Qty	Loss
----------------------------------------------
2023-07-11 08:03:39.000	Non-Copper	0	325
2023-07-11 08:04:01.000	Non-Copper	0	330
2023-07-11 17:36:35.000	Non-Copper	0	200
2023-07-11 10:49:15.000	Non-Copper	0	1
2023-07-11 10:49:15.000	Non-Copper	0	6
2023-07-11 10:49:15.000	Non-Copper	0	17
2023-07-11 10:49:15.000	Non-Copper	0	3
2023-07-11 10:49:15.000	Non-Copper	0	8
2023-07-11 10:51:18.000	Non-Copper	0	2
2023-07-11 10:51:18.000	Non-Copper	0	4
2023-07-11 10:51:18.000	Non-Copper	0	3
2023-07-11 10:52:17.000	Non-Copper	0	3
2023-07-11 10:52:17.000	Non-Copper	0	1
2023-07-11 10:52:36.000	Non-Copper	3	0
2023-07-11 11:26:20.000	Non-Copper	45	0
2023-07-11 11:26:28.000	Non-Copper	25	0
2023-07-11 11:26:35.000	Non-Copper	31	0
2023-07-11 11:26:42.000	Non-Copper	25	0
2023-07-11 11:27:17.000	Non-Copper	11	0
2023-07-11 11:27:48.000	Non-Copper	3	0
2023-07-11 14:45:01.000	Non-Copper	200	0
2023-07-11 14:45:07.000	Non-Copper	163	0
2023-07-11 14:45:12.000	Non-Copper	200	0
2023-07-11 14:45:18.000	Non-Copper	99	0
2023-07-11 14:45:25.000	Non-Copper	15	0
2023-07-11 14:46:35.000	Non-Copper	13	0
2023-07-11 14:47:04.000	Non-Copper	39	0
2023-07-11 14:47:17.000	Non-Copper	121	0
2023-07-11 14:47:26.000	Non-Copper	94	0
2023-07-11 14:47:40.000	Non-Copper	109	0
2023-07-11 14:47:46.000	Non-Copper	64	0
2023-07-11 14:48:45.000	Non-Copper	68	0
2023-07-11 14:48:56.000	Non-Copper	35	0
2023-07-11 14:49:01.000	Non-Copper	25	0
2023-07-11 14:49:08.000	Non-Copper	18	0
2023-07-11 14:49:13.000	Non-Copper	15	0
2023-07-11 14:50:17.000	Non-Copper	3	0
2023-07-11 16:32:08.000	Non-Copper	342	0
2023-07-11 18:29:40.000	Copper	0	19
2023-07-11 18:29:40.000	Copper	0	8
2023-07-11 18:29:40.000	Copper	0	32
2023-07-11 18:37:03.000	Copper	0	3
2023-07-11 18:37:03.000	Copper	0	35
2023-07-11 18:37:03.000	Copper	0	9
2023-07-11 18:37:03.000	Copper	0	36
2023-07-11 18:37:03.000	Copper	0	1
2023-07-11 18:56:41.000	Copper	0	5
2023-07-11 18:56:41.000	Copper	0	2
2023-07-11 15:34:27.000	Copper	63	0
2023-07-11 15:34:39.000	Copper	80	0
2023-07-12 06:27:53.000	Copper	24	0
2023-07-12 06:29:19.000	Copper	37	0
2023-07-12 06:29:53.000	Copper	9	0
2023-07-12 06:30:01.000	Copper	15	0
2023-07-12 06:30:10.000	Copper	31	0
2023-07-12 06:30:22.000	Copper	23	0
2023-07-12 06:30:29.000	Copper	5	0
2023-07-12 06:31:00.000	Copper	4	0
2023-07-12 06:49:55.000	Copper	36	0
2023-07-12 06:50:03.000	Copper	38	0
2023-07-12 06:50:28.000	Copper	116	0
2023-07-12 06:50:43.000	Copper	121	0
2023-07-12 06:50:49.000	Copper	23	0
2023-07-12 06:51:17.000	Copper	23	0
...
共378筆
*/

)


select x.Interval
         ,x.Line
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,'Loss'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Loss
                             else null 
                             end 
         ,'TargetQty'=x.TargetQty/2
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
          ,'TargetQty'=1*@Stripper*@TargetOutput300mm/12  --1*1.05*12800/12
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD) 
            )
group by a.Line

union all
select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=2*@Stripper*@TargetOutput300mm/12   --2*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD)  and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=3*@Stripper*@TargetOutput300mm/12   --3*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=4*@Stripper*@TargetOutput300mm/12   --4*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=5*@Stripper*@TargetOutput300mm/12   --5*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=6*@Stripper*@TargetOutput300mm/12   --6*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=7*@Stripper*@TargetOutput300mm/12   --7*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=8*@Stripper*@TargetOutput300mm/12   --8*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=9*@Stripper*@TargetOutput300mm/12   --9*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=10*@Stripper*@TargetOutput300mm/12   --10*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=11*@Stripper*@TargetOutput300mm/12   --11*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=12*@Stripper*@TargetOutput300mm/12    --12*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
group by a.Line
) x


GO


/*
執行時間為:20230721 13:25
產生結果如下 
Interval	            Line	    Qty	    Loss	TargetQty
-------------------------------------------------------------
2023-07-11 09:20:00	    Non-Copper	0	    655     560
2023-07-11 11:20:00	    Non-Copper	508	    709     1120
2023-07-11 13:20:00	    Non-Copper	648	    727     1680
2023-07-11 15:20:00	    Non-Copper	1929	801     2240
2023-07-11 17:20:00	    Copper	    1940	540     2800
2023-07-11 17:20:00	    Non-Copper	2657	920     2800
2023-07-11 19:20:00	    Copper	    4144	725     3360
2023-07-11 19:20:00	    Non-Copper	4154	1324	3360
2023-07-11 21:20:00	    Copper	    4144	725	    3920
2023-07-11 21:20:00	    Non-Copper	4154	1324	3920
2023-07-11 23:20:00	    Copper	    4409	741	    4480
2023-07-11 23:20:00	    Non-Copper	4949	1457	4480
2023-07-12 01:20:00	    Copper	    5192	908	    5040
2023-07-12 01:20:00	    Non-Copper	5357	1470	5040
2023-07-12 03:20:00	    Copper	    5192	908	    5600
2023-07-12 03:20:00	    Non-Copper	6158	1640	5600
2023-07-12 05:20:00	    Copper	    5867	1008	6160
2023-07-12 05:20:00	    Non-Copper	6158	1640	6160
2023-07-12 07:20:00	    Copper	    8725	1318	6720
2023-07-12 07:20:00	    Non-Copper	6541	1706	6720
*/