USE [WarInfo]
GO

DECLARE @StartDate SMALLDATETIME;
SET @StartDate = '20230701';
DECLARE @EndDate SMALLDATETIME;
SET @EndDate = '20230730';
DECLARE @Mode VARCHAR(2);
SET @Mode = 'A';

-------------------------TempA--------------------
with TempA as (
select MFGDate
          ,CustomerPN
         ,'Qty'=sum(Qty)
from SSRS_Output_200mm with(nolock)  -- 200mm
where MFGDate between @StartDate and @EndDate
and PsiPN like case when @Mode='R' then '___________[A-LO-Z]%'
                    when @Mode='T' then '___________[MN]%'
                    else '%'
               end
and CustomerPN like case when @Mode='Y' then 'V%'
                         else '%'
                    end
and CustomerPN not like case when @Mode='N' then 'V%'
                             else ''
                        end
group by MFGDate, CustomerPN),


-------------------------TempB--------------------
TempB as ( 
select MFGDate 
          ,CustomerPN
         ,'Qty'=sum(Qty)
from SSRS_Output_300mm with(nolock)  -- 300mm
where MFGDate between @StartDate and @EndDate
and PsiPN like case when @Mode='R' then '___________[A-LO-Z]%'
                    when @Mode='T' then '___________[MN]%'
                    else '%'
               end
and CustomerPN like case when @Mode='Y' then 'V%'
                         else '%'
                    end
and CustomerPN not like case when @Mode='N' then 'V%'
                             else ''
                        end
group by MFGDate, CustomerPN

union all
select 'MFGDate'=cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
       ,'CustomerPN'='Rework'
       ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between convert(char(8), @StartDate , 112) 
and convert(char(8), @EndDate, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0
and MFG_LOTNO like case when @Mode='R' then '____[A-LO-Z]%'
                        when @Mode='T' then '____[MN]%'
                        else '%'
                    end
and MFG_LOTNO like case when @Mode='Y' then '[2T]%'
                        else '%'
                   end
and MFG_LOTNO not like case when @Mode='N' then '[2T]%'
                            else ''
                       end
group by cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)

),

-------------------------TempD--------------------
TempD as (
select 'MFGDate' = cast(dbo.RealDateToMfgDate(MFG_Date) as Smalldatetime)
         , 'CustomerPN' = FG_Customer
         , 'Qty'=sum(Qty)
from Fab3_SSRS_Output_300mm_Time with(nolock)
where cast(dbo.RealDateToMfgDate(MFG_Date) as Smalldatetime) between @StartDate and @EndDate
and LotNo like case when @Mode='R' then '____[A-LO-Z]%'
                    when @Mode='T' then '____[MN]%'
                    else '%'
               end
and FG_Customer like case when @Mode='Y' then 'V%'
                          else '%'
                     end
and FG_Customer not like case when @Mode='N' then 'V%'
                              else ''
                         end
group by dbo.RealDateToMfgDate(MFG_Date), FG_Customer
),

-------------------------TempC--------------------
TempC as (
select x.RN
          ,x.KDMAT
          ,x.SalePrice
from (
   select 'RN'=row_number() over (partition by 
                          case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                               when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                               else KDMAT
                           end 
                               order by AUDAT desc)
              ,'KDMAT'=case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                            when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                            else KDMAT
                       end 
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                else NETPR*KURSK
                           end
   from sap_sd_so_v
   where NETPR>0
   and VKORG='1100'
   ) x
where x.RN=1)


select 'Inch'='200mm'
          ,a.MFGDate
          ,a.CustomerPN
          ,a.Qty
         ,'SalePrice'=isnull(case when c.KDMAT like '01-12-0002%' or c.KDMAT like 'C021-0008X%' then 150
                                  when c.KDMAT like 'V471100%' then 500
                                  else c.SalePrice
                             end, 150)
         ,'Revenue'=a.Qty*isnull(case when c.KDMAT like '01-12-0002%' or c.KDMAT like 'C021-0008X%' then 150
                                      when c.KDMAT like 'V471100%' then 500
                                      else c.SalePrice
                                 end, 150)
from TempA a left join TempC c
on a.CustomerPN=c.KDMAT
union all
select 'Inch'='300mm'
          ,b.MFGDate
          ,b.CustomerPN
          ,b.Qty
         ,'SalePrice'=isnull(c.SalePrice, 300)
         ,'Revenue'=b.Qty*isnull(c.SalePrice, 300)
from TempB b left join TempC c
on b.CustomerPN=c.KDMAT
union all
select 'Inch'='Fab3'
          ,b.MFGDate
          ,b.CustomerPN collate Chinese_Taiwan_Stroke_CI_AS
          ,b.Qty
         ,'SalePrice'=isnull(c.SalePrice, 300)
         ,'Revenue'=b.Qty*isnull(c.SalePrice, 300)
from TempD b left join TempC c
on b.CustomerPN=c.KDMAT collate Chinese_Taiwan_Stroke_CI_AS


/*
執行時間為:20230731 10:31
產生結果如下 
Inch	MFGDate	                CustomerPN	Qty	SalePrice	Revenue
--------------------------------------------------------------------------
200mm	2023-07-03 00:00:00.000	W0853013P	25	184.4400000	4611.000000
200mm	2023-07-21 00:00:00.000	W0813006P	25	186.7800000	4669.500000
200mm	2023-07-14 00:00:00.000	01-14-0003	100	188.0000000	18800.000000
200mm	2023-07-01 00:00:00.000	W0853007P	25	233.4750000	5836.875000
200mm	2023-07-15 00:00:00.000	01-14-0018	25	188.0000000	4700.000000
200mm	2023-07-17 00:00:00.000	V420021	    375	148.4190000	55657.125000
200mm	2023-07-08 00:00:00.000	N/A	        38	150.0000000	5700.000000
200mm	2023-07-16 00:00:00.000	W0853000P	100	184.4400000	18444.000000
200mm	2023-07-21 00:00:00.000	W6P0TI0199A	75	266.5520000	19991.400000
200mm	2023-07-09 00:00:00.000	1990000003	350	150.0000000	52500.000000
200mm	2023-07-22 00:00:00.000	V450000	    111	173.8800000	19300.680000
200mm	2023-07-10 00:00:00.000	W0823002P	25	182.7600000	4569.000000
200mm	2023-07-23 00:00:00.000	01-14-0004	75	188.0000000	14100.000000
200mm	2023-07-27 00:00:00.000	V450000	    315	173.8800000	54772.200000
200mm	2023-07-16 00:00:00.000	01-14-0006	250	188.0000000	47000.000000
200mm	2023-07-11 00:00:00.000	W0813005P	75	186.7800000	14008.500000
200mm	2023-07-08 00:00:00.000	01706012	800	200.7850000	160628.000000
200mm	2023-07-06 00:00:00.000	V460000	    125	173.8800000	21735.000000
*/