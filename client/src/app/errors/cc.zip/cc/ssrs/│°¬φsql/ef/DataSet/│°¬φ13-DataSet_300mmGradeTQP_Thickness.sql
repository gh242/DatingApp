USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,ProcessThickness
          ,'Percentage'=1.0000*sum(case when WaferGrade like 'Grade[TQP]' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[CBDUXHILYMS]'
group by dbo.RealDateToMfgDate(CollectionTime), ProcessThickness
)

-- 19nm Non-Copper
select a.MFGDate, 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), 'Line'='Non-Copper', 'Percentage'=isnull(b.Percentage, 0)
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate

GO


/*
產生結果如下  20230718 執行時間，為20230718 15:52
MFGDate	                ProcessThickness	Line	    Percentage
-------------------------------------------------------------------------
2023-07-11 00:00:00	    A	                Non-Copper	0.687943262411347
2023-06-30 00:00:00	    S	                Non-Copper	0.752427184466019
2023-07-11 00:00:00	    S	                Non-Copper	0.897025171624713
2023-06-29 00:00:00	    S	                Non-Copper	0.931034482758620
2023-07-08 00:00:00	    S	                Non-Copper	0.920245398773006
2023-07-01 00:00:00	    S	                Non-Copper	0.929577464788732
2023-07-12 00:00:00	    S	                Non-Copper	0.911392405063291
2023-07-05 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-02 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-03 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-09 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-06 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-07 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-04 00:00:00	    X	                Non-Copper	0.000000000000000
2023-07-10 00:00:00	    X	                Non-Copper	0.000000000000000
2023-06-28 00:00:00	    X	                Non-Copper	0.000000000000000
*/