/* Outside*/ SELECT 'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock), [EDC].[dbo].[View_PackingImageFN] B WITH (nolock)
WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
                   A.FG_MFGDate > '20150101' AND A.FG_MFGDate <> '20201213' AND 
                   A.FG_MFGDate <> '20201214' /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
                    A.FG_Valid = 'Y' /* 1234567890123456789012345678901234567*/ AND A.FG_BarCode1 = substring(B.Barcode, 1, 1) AND 
                   A.FG_BarCode2 = substring(B.Barcode, 3, 8) AND A.FG_BarCode3 = substring(B.Barcode, 12, 10) AND 
                   A.FG_BarCode4 = substring(B.Barcode, 23, 10) AND A.FG_BarCode5 = substring(B.Barcode, 33, 2) AND 
                   A.FG_BarCode6 = substring(B.Barcode, 36, 2)
/* Inside*/ UNION ALL
SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock), [EDC].[dbo].[View_PackingImageFN] B WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND A.FG_MFGDate > '20150101' AND 
                   A.FG_MFGDate <> '20201213' AND 
                   A.FG_MFGDate <> '20201214' /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
                    A.FG_Valid = 'Y' AND A.FG_BarCode1 = substring(B.Barcode, 1, 1) AND A.FG_BarCode2 = substring(B.Barcode, 3, 8) AND 
                   A.FG_BarCode3 = substring(B.Barcode, 12, 10) AND A.FG_BarCode4 = substring(B.Barcode, 23, 10) AND 
                   A.FG_BarCode5 = substring(B.Barcode, 33, 2) AND A.FG_BarCode6 = substring(B.Barcode, 36, 2)
/* Outside  20201213 virus crash*/ UNION ALL
SELECT  'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
                   (A.FG_MFGDate = '20201213' OR
                   A.FG_MFGDate = '20201214') 
                   /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
                    A.FG_Valid = 'Y'
/* Inside*/ UNION ALL
SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND (A.FG_MFGDate = '20201213' OR
                   A.FG_MFGDate = '20201214') 
                   /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
                    A.FG_Valid = 'Y'
/* Outside		 */ UNION ALL
SELECT  'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode_His] A WITH (nolock)
WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
                   A.FG_MFGDate > '20150101'
/* Inside*/ UNION ALL
SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode_His] A WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND A.FG_MFGDate > '20150101'


