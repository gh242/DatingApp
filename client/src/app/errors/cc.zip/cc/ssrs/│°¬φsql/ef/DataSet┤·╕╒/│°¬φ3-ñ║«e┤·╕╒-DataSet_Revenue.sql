USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230717';
DECLARE @Mode VARCHAR(2);
SET @Mode = 'A';

--報表3-內容測試-DataSet_Revenue
--報表77-內容測試-DataSet_Revenue 相同

with TempB as (
select 'MFGDate' = dbo.RealDateToMfgDate(MFG_Date)
         , 'CustomerPN' = FG_Customer
         , 'Qty'=sum(Qty)
--         , LotNo
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date between case when day(@YYYYMMDD)=1 then Dateadd(m, -1,@YYYYMMDD) -- 減一個月
                                                       else @YYYYMMDD-day(@YYYYMMDD)+1 -- 減30天, 加1天
                                                       --SELECT DAY('2015-04-30 01:01:01.1234567');  
                                                       end
and @YYYYMMDD-1
and LotNo like case when @Mode='R' then '____[A-LO-Z]%'
                    when @Mode='T' then '____[MN]%'
                    else '%'
               end
and FG_Customer like case when @Mode='Y' then 'V%'
                          else '%'
                     end
and FG_Customer not like case when @Mode='N' then 'V%'
                              else ''
                          end
group by dbo.RealDateToMfgDate(MFG_Date), FG_Customer
--,LotNo

-- /*
-- -- 產生結果如下  20230717 執行時間，為20230717 15:40
-- MFGDate                     CustomerPN      Qty
-- ------------------------------------------------
-- 2023-07-08 00:00:00.000	    02-14-0003	    25
-- 2023-07-12 00:00:00.000	    02-14-0003	    25
-- 2023-06-30 00:00:00.000	    02-14-0004	    25
-- 2023-07-08 00:00:00.000	    02-14-0004	    75
-- 2023-07-09 00:00:00.000	    02-14-0004	    125
-- 2023-07-12 00:00:00.000	    02-14-0004	    125
-- 2023-07-09 00:00:00.000	    02-14-0005	    25
-- 2023-07-09 00:00:00.000	    02-14-0006	    25
-- 2023-07-10 00:00:00.000	    02-14-0016	    325
-- 2023-07-11 00:00:00.000	    02-14-0016	    225
-- 2023-07-12 00:00:00.000	    02-14-0016	    50
-- 2023-07-11 00:00:00.000	    02-14-0017	    25
-- 2023-07-10 00:00:00.000	    02-14-0018	    50
-- 2023-07-12 00:00:00.000	    02-24-0001	    25
-- 2023-06-30 00:00:00.000	    180-EALX8	    50
-- 2023-07-01 00:00:00.000	    180-EALX8	    25
-- 2023-07-06 00:00:00.000	    180-EALX8	    50
-- 2023-07-08 00:00:00.000	    180-EALX8	    25
-- */
),

/*
--可程式性\函數\純量值函數
 --[dbo].[RealDateToMfgDate]

		Case IsDate(@RealDate)     --SELECT convert(varchar, getdate(), 111) - yyyy/mm/dd
	  		When 1 Then Cast(Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) As DateTime)
			Else Null
		End
*/


TempC as (
select x.RN
         , x.KDMAT
         , x.SalePrice
from (
   select 'RN'=row_number() over (partition by 
                          case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                               when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                               else KDMAT
                           end 
                                                          order by AUDAT desc)
              ,'KDMAT'=case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                            when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1) 
                            -- 取KDMAT，遇到空格就只取前面的，如'KDMAT KK', 只需取'KDMAT'
                            else KDMAT
                        end 
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                else NETPR*KURSK
                            end

    --select auart_text -- for test
    -- select *
   from sap_sd_so_v   
   where NETPR>0      -- ??
   and VKORG='1100'   -- ?? 
   --group by auart_text--
    -- and KDMAT like '199900000000018%(G)%' -- for test
    -- and KDMAT like '199900000000020%' -- for test
    -- and KDMAT like '_% _%' -- for test
   ) x
where x.RN=1
)
---- select * from TempC

/*
AUART_TEXT
--------------------
樣品申請單(收費)
不良品需求申請單(收費)
銷售合約
折讓申請單
客戶服務單
寄銷耗用訂單
客訴單
銷退(有金額)申請單
借項申請單
報價單
標準銷售訂單
*/

/*  加上 where x.RN=1
RN  KDMAT           SalePrice
-----------------------------------
1	 	            208.0000000
1	(FOR	        512.2800000
1	(LASER	        688.8660000
1	01-12-0001	    481.3120000
1	01-12-0002	    487.2000000
1	01-12-0002S	    590.4500000
1	01-14-00	    177.0000000
1	01-14-0003	    188.0000000
1	01-14-0004	    188.0000000
1	01-14-0004S2	173.0000000
1	01-14-0005	    188.0000000
1	01-14-0005A1	174.0000000
1	01-14-0006	    188.0000000
1	01-14-0008	    188.0000000
1	01-14-0009	    175.0000000
1	01-14-0013	    188.0000000
1	01-14-0014S	    177.0000000
1	01-14-0015	    188.0000000
1	01-14-0016	    188.0000000
1	01-14-0017	    188.0000000
1	01-14-0018	    188.0000000
1	01-14-0019	    188.0000000
1	01-14-0019S	    177.0000000
1	01-14-0020	    188.0000000
1	01-14-0020S	    177.0000000
1	01-14-0021	    188.0000000
1	01-14-0021A3_I	174.0000000
1	01-14-0021S	    177.0000000
1	01-14-0022S	    55.0000000
1	01-14-0024S	    188.0000000
...
*/


-- select * from sap_sd_so_v

/*
33891筆
RN      KDMAT   SalePrice
---------------------------
1	 	        208.0000000
2	 	        208.0000000
3	 	        470.0850000
4	 	        384.6150000
5	 	        484.3300000
6	 	        384.6150000
7	 	        500.9400000
8	 	        409.8600000
9	 	        516.1200000
10	 	        409.8600000
11	 	        220.0000000
12	 	        188.0000000
13	 	        540.0000000
...
*/

select b.MFGDate
          ,b.CustomerPN
          ,b.Qty
         ,'SalePrice'=isnull(c.SalePrice, 300) -- 以指定的取代值來取代 NULL。 ISNULL ( check_expression , replacement_value )
         ,'Revenue'=b.Qty*isnull(c.SalePrice, 300)
         , 'Grade'=case when isnull(c.SalePrice, 300)<350 then 'Low'
                        when isnull(c.SalePrice, 300)>=350 and isnull(c.SalePrice, 300)<450 then 'Normal'
                        when isnull(c.SalePrice, 300)>=450 and isnull(c.SalePrice, 300)<550 then 'P'
                        when isnull(c.SalePrice, 300)>=550 and isnull(c.SalePrice, 300)<650 then 'Q'
                        when isnull(c.SalePrice, 300)>=650 and isnull(c.SalePrice, 300)<850 then 'T'
                        when isnull(c.SalePrice, 300)>=850 and isnull(c.SalePrice, 300)<1000 then 'U'
                        when isnull(c.SalePrice, 300)>=1000  then 'Test'
                        else 'Others'
                        end
from TempB b left join TempC c
on b.CustomerPN = c.KDMAT Collate Chinese_Taiwan_Stroke_CI_AS
-- CustomerPN(SSRS_Output_300mm_Time 上) = KDMAT(sap_sd_so_v 上)



/*
MFG_Date                FG_Customer     Qty     SalePrice       Revenue        Grade
-------------------------------------------------------------------------------------
2023-06-30 00:00:00.000	02-14-0004	    25	    510.0000000	    12750.0000000	P
2023-06-30 00:00:00.000	02-14-0025	    100	    330.0000000	    33000.0000000	Low
2023-06-30 00:00:00.000	02-14-0026	    50	    330.0000000	    16500.0000000	Low
2023-06-30 00:00:00.000	02-14-0027	    50	    510.0000000	    25500.0000000	P
2023-06-30 00:00:00.000	02-14-0028	    150     300.0000000	    45000.0000000	Low
2023-06-30 00:00:00.000	02-24-0001	    50	    505.0000000	    25250.0000000	P
2023-06-30 00:00:00.000	180-EALX8	    50	    569.6790000	    28483.9500000	Q
2023-07-01 00:00:00.000	180-EALX8	    25	    569.6790000	    14241.9750000	Q
2023-07-01 00:00:00.000	180-EDR38	    25	    420.2550000	    10506.3750000	Normal
2023-07-01 00:00:00.000	180-ELR18	    100	    569.6790000	    56967.9000000	Q
2023-06-30 00:00:00.000	180-ELT08	    100	    569.6790000	    56967.9000000	Q
2023-07-02 00:00:00.000	6C-29-0005	    250	    547.8880000	    136972.0000000	P
2023-06-30 00:00:00.000	V65000013A	    125	    434.8400000	    54355.0000000	Normal
...
*/