USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230717';
DECLARE @TargetOutput200mm int;
SET @TargetOutput200mm = 2560;

with TempA as (
select Print_Date
         ,Qty
from SSRS_Output_200mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
union all
select 'Print_Date'=DateAdd(n, 1760, @YYYYMMDD)
          ,'QTY'=-1*MANU_QTY
from [RCS_200mm].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'
and MANU_FROM_LOTNO not like '[A-Z]___[QWV]%'
AND MANU_FMLB='M'
and MANU_QTY>0
/*
select 'Print_Date'=DateAdd(n, 1760, @YYYYMMDD)
          ,'Qty'=-1*MFG_MOVE
from [RCS_200mm].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_LOTNO not like 'P[BC]__S_%'
and MFG_MOVE>0
and MFG_LOTNO not like '[A-Z]___[QWV]%'
*/
),

TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),

tempC as (
select 'N'=(N-440)/120*@TargetOutput200mm/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)

select x.Interval
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,TargetQty
from (
select 'Interval'=DateAdd(n, 440+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=@TargetOutput200mm/12 --213
from TempA a
where ( (a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 560, @YYYYMMDD)) or
               a.Print_Date<DateAdd(n, 440, @YYYYMMDD) or
               a.Print_Date>=DateAdd(n, 1880, @YYYYMMDD)
            )
union all
select 'Interval'=b.Interval
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=b.N
from TempA a, tempC b
where (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<b.Interval) -- mi?
group by b.Interval, b.N
) x



--產生結果如下  20230717 執行時間，為20230717 13:45
--Interval              Qty   TargetQty
---------------------------------------
-- 2023-07-17 09:20:00	50	   213
-- 2023-07-17 11:20:00	325	426
-- 2023-07-17 13:20:00	675	640
-- 2023-07-17 15:20:00	775	853
-- 2023-07-17 17:20:00	NULL	1066
-- 2023-07-17 19:20:00	NULL	1280
-- 2023-07-17 21:20:00	NULL	1493
-- 2023-07-17 23:20:00	NULL	1706
-- 2023-07-18 01:20:00	NULL	1920
-- 2023-07-18 03:20:00	NULL	2133
-- 2023-07-18 05:20:00	NULL	2346
-- 2023-07-18 07:20:00	NULL	2560


-----------以下已註解掉
/*
with TempA as (
select Print_Date
         ,Qty
from SSRS_Output_200mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
union all
select 'Print_Date'=DateAdd(n, 1760, @YYYYMMDD)
          ,'QTY'=-1*MANU_QTY
from [RCS_200mm].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'
and MANU_FROM_LOTNO not like '[A-Z]___[QWV]%'
AND MANU_FMLB='M'
and MANU_QTY>0
/*
select 'Print_Date'=DateAdd(n, 1760, @YYYYMMDD)
          ,'Qty'=-1*MFG_MOVE
from [RCS_200mm].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0
and MFG_LOTNO not like '[A-Z]___[QWV]%'
*/
)

select x.Interval
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,TargetQty
from (
select 'Interval'=DateAdd(n, 440+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=@TargetOutput200mm/12
from TempA a
where ( (a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 560, @YYYYMMDD)) or
               a.Print_Date<DateAdd(n, 440, @YYYYMMDD) or
               a.Print_Date>=DateAdd(n, 1880, @YYYYMMDD)
            )

union all
select 'Interval'=DateAdd(n, 560+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=2*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 680, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 680+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=3*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 800, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 800+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=4*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 920, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 920+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=5*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1040, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1040+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=6*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1160, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1160+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=7*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1280, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1280+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=8*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1400, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1400+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=9*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1520, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1520+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=10*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1640, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1640+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=11*@TargetOutput200mm/12
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1760, @YYYYMMDD)

union all
select 'Interval'=DateAdd(n, 1760+120, @YYYYMMDD)
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=@TargetOutput200mm
from TempA a
where a.Print_Date>=DateAdd(n, 440, @YYYYMMDD) and a.Print_Date<DateAdd(n, 1880, @YYYYMMDD)
) x
*/

