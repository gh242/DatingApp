USE [WarInfo]
GO

/****** Object:  View [dbo].[SSRS_Output_300mm_Time]    Script Date: 2023/7/24 上午 10:56:10 ******/
-- SET ANSI_NULLS ON
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO

-- ALTER VIEW [dbo].[SSRS_Output_300mm_Time]
-- as

/*  2020-08-25 mark
		-- Outside
		select 'Category'='Outside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,A.Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,A.Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and A.FG_MFGDate>'20150101'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'


		-- Jasont requet 2019/7/30
		-- Outside		 
		 union all
		 select 'Category'='Outside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and A.FG_MFGDate>'20150101'
2020-08-25 mark */


/* 371521筆 */
----------------------1.Outside---A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'-----------------------------------------------------------------------
		-- Outside
		select 'Category'='Outside'
				--  20200813 -> 2020-08-13
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock),  [EDC].[dbo].[View_PackingImageFN] B  with(nolock) 
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  -- 5-20171006-TY33E171SE-2PH9E10F0A  -25
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)

----------------------2.Inside---A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'-----------------------------------------------------------------------
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock) , [EDC].[dbo].[View_PackingImageFN] B  with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)

----------------------3.Outside---(A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')-----------------------------------------------------------------------
		-- Outside  20201213 virus crash
union all
		select 'Category'='Outside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
----------------------4.Inside---(A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')-----------------------------------------------------------------------
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'

----------------------5.Outside---FG_MFGDate>'20150101'-----------------------------------------------------------------------
		-- Jasont requet 2019/7/30
		-- Outside		 
		 union all
		 select 'Category'='Outside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
----------------------6.Inside---FG_MFGDate>'20150101'-----------------------------------------------------------------------
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and A.FG_MFGDate>'20150101'





GO

/*
執行時間為:20230725 16:48
產生結果如下
--371521筆 
Category	MFG_Date				MFGDate		FG_Customer	LotNo		Qty		Print_Date
-------------------------------------------------------------------------------------------------------
Outside		2022-09-03 00:00:00.000	20220903	V650021B	25M841		25		2022-09-03 20:33:25.000
Outside		2022-09-03 00:00:00.000	20220903	V650004P	26M8J1		25		2022-09-04 05:10:35.000
Outside		2022-09-03 00:00:00.000	20220903	V650000A	2AM8E1		25		2022-09-04 06:50:34.000
Outside		2022-09-04 00:00:00.000	20220904	V650000P	2AM8E1		25		2022-09-04 20:23:04.000
Outside		2021-08-01 00:00:00.000	20210801	02-14-0025	6ML7E1		25		2021-08-01 14:19:26.000
Outside		2021-08-01 00:00:00.000	20210801	02-14-0025	6ML7E1		25		2021-08-01 20:16:41.000
Outside		2021-08-01 00:00:00.000	20210801	V650003O	2SL7C1		25		2021-08-01 22:15:34.000
Outside		2021-08-01 00:00:00.000	20210801	V650000A	2SL7E1		25		2021-08-01 18:24:56.000
Outside		2021-08-01 00:00:00.000	20210801	V650000P	2SL7E1		25		2021-08-01 20:50:34.000
Outside		2021-07-31 00:00:00.000	20210731	V650000D	2TL7E1		25		2021-08-01 06:24:52.000
Outside		2021-08-04 00:00:00.000	20210804	V650004A	2SL7J1		25		2021-08-04 12:40:03.000
Outside		2021-08-03 00:00:00.000	20210803	V65000013A	21L2H1		25		2021-08-04 01:57:39.000
Outside		2021-08-04 00:00:00.000	20210804	V650006F	26L7H1		25		2021-08-04 08:50:30.000
Outside		2021-08-04 00:00:00.000	20210804				9VL7I4		25		2021-08-04 19:50:24.000
Outside		2021-08-04 00:00:00.000	20210804	V650006F	26L7H1		25		2021-08-04 12:45:24.000
Outside		2021-08-04 00:00:00.000	20210804	V650004N	26L7J1		25		2021-08-04 17:08:06.000
Outside		2021-08-05 00:00:00.000	20210805	V650000A	2SL7E1		25		2021-08-05 17:41:37.000
Outside		2021-08-05 00:00:00.000	20210805	V650003A3	21L7C1		25		2021-08-05 17:46:13.000
Outside		2021-08-05 00:00:00.000	20210805	V650003N	21L7C1		25		2021-08-05 10:40:39.000
Outside		2021-08-18 00:00:00.000	20210818	V650000P	26L8E1		25		2021-08-18 11:57:27.000
Outside		2021-08-18 00:00:00.000	20210818	V650003A	28L8C1		25		2021-08-18 22:53:04.000
Outside		2021-08-18 00:00:00.000	20210818	V650004A	21JCJ1		25		2021-08-18 19:51:45.000
Outside		2021-08-18 00:00:00.000	20210818	V650007F	2BL8J1		25		2021-08-18 10:53:54.000
Outside		2021-08-18 00:00:00.000	20210818	V650003A	28L8C1		25		2021-08-18 23:13:27.000
Outside		2021-08-21 00:00:00.000	20210821	V650003A2	26L8L1		25		2021-08-22 03:44:03.000
Outside		2021-08-22 00:00:00.000	20210822	V650000A	26L8E1		25		2021-08-22 18:20:02.000
Outside		2021-08-22 00:00:00.000	20210822	V650000Q	2SL8E1		25		2021-08-22 23:32:23.000
Outside		2021-08-22 00:00:00.000	20210822	V650003A	28L8C1		25		2021-08-22 20:15:45.000
Outside		2021-08-22 00:00:00.000	20210822	V650006D	28L8C1		25		2021-08-22 23:20:31.000
*/

