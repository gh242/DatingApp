USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;


with TempA as ( --
select 'Print_Date'=cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Non-Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                              else 0
                              end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                               else 0
                               end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=680
and (MANU_FROM_LOTNO like '[1-9]___[EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

union all
select 'Print_Date'=cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                              else 0
                              end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                               else 0
                               end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=680
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0
)


select x.Interval
         ,x.Line
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,'Loss'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Loss
                             else null 
                             end 
         ,'TargetQty'=x.TargetQty/2
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
          ,'TargetQty'=1*@Stripper*@TargetOutput300mm/12
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD) 
            )
group by a.Line

union all
select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=2*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD)  and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=3*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=4*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=5*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=6*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=7*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=8*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=9*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=10*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=11*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=12*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
group by a.Line
) x


GO