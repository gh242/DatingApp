USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

--報表24-DataSet_300mmYieldPolish1B
--報表23-DataSet_300mmYieldPolish4F

--與 報表23-內容測試-DataSet_300mmYield4F Dataset 相似
--只是報表圖 呈現不一樣
--報表23 呈現 Groups(Polisher), 報表19 呈現 Groups(PreCleaner+FinalCleanSide)


with TempA as (
-- Copper
select 'Line'='Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName like 'TENCOR_1[123457]' -- 1B 是TENCOR_1幾
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD)  --07:20
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1) -- 隔日07:20
and LotID like '[1-9]___[BCDHLUYIS]%' -- 第1碼是1到9，第5碼是 BCDHLUYIS 其中1碼
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher

/*
執行時間為:20230719 15:10
產生結果如下 
Line	Polisher	Pass	Mech	Total
-----------------------------------------
Copper	25	        255	    0	    285
Copper	17	        107	    0	    122
Copper	11	        41	    0	    47
Copper	12	        311	    1	    382
Copper	24	        266	    5	    295
Copper	27	        243	    1	    264
*/

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD)  --07:20
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1) -- 隔日07:20
and (LotID like '[1-9]%' or LotID like 'PS__M%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
--and LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like 'PS__M%-_[678ABCFH123459DEGIJKLMNOPQRSTUVW]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher
/*
執行時間為:20230719 15:12
產生結果如下 
Line	    Polisher	Pass	Mech	Total
---------------------------------------------
Non-Copper	30	        36	    22	    80
Non-Copper	26	        146	    72	    278
Non-Copper	16	        38	    10	    57
Non-Copper	31	        66	    17	    102
Non-Copper	23	        172	    79	    293
Non-Copper	20	        276	    83	    379
Non-Copper	27	        10	    2	    12
Non-Copper	-23	        38	    1	    90
Non-Copper	21	        173	    64	    277
Non-Copper	22	        234	    63	    335
Non-Copper	29	        81	    42	    169
Non-Copper	32	        41	    22	    72
Non-Copper	18	        360	    4	    400
Non-Copper	19	        282	    0	    345
Non-Copper	28	        161	    58	    271
*/

)

select a.*
          ,'Yield'=1.0000*a.Pass/a.Total
from TempA a


GO

/*
執行時間為:20230719 15:08
產生結果如下 
Line	    Polisher	Pass	Mech	Total	Yield
-----------------------------------------------------------------
Copper	    17	        107	    0	    122	    0.877049180327868
Copper	    12	        311	    1	    382	    0.814136125654450
Copper	    24	        266	    5	    295	    0.901694915254237
Copper	    27	        243	    1	    264	    0.920454545454545
Copper	    25	        255	    0	    285	    0.894736842105263
Copper	    11	        41	    0	    47	    0.872340425531914
Non-Copper	29	        81	    42	    169	    0.479289940828402
Non-Copper	23	        172	    79	    293	    0.587030716723549
Non-Copper	32	        41	    22	    72	    0.569444444444444
Non-Copper	19	        282	    0	    345	    0.817391304347826
Non-Copper	28	        161	    58	    271	    0.594095940959409
Non-Copper	31	        66	    17	    102	    0.647058823529411
Non-Copper	26	        146	    72	    278	    0.525179856115107
Non-Copper	21	        173	    64	    277	    0.624548736462093
Non-Copper	22	        234	    63	    335	    0.698507462686567
Non-Copper	20	        276	    83	    379	    0.728232189973614
Non-Copper	27	        10	    2	    12	    0.833333333333333
Non-Copper	18	        360	    4	    400	    0.900000000000000
Non-Copper	16	        38	    10	    57	    0.666666666666666
Non-Copper	-23	        38	    1	    90	    0.422222222222222
Non-Copper	30	        36	    22	    80	    0.450000000000000
*/