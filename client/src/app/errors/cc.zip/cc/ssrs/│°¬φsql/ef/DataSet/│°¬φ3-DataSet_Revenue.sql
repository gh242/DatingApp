USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
DECLARE @Mode VARCHAR(2);
SET @Mode = 'A';


with TempB as (
select 'MFGDate' = dbo.RealDateToMfgDate(MFG_Date)
         , 'CustomerPN' = FG_Customer
         , 'Qty'=sum(Qty)
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date between case when day(@YYYYMMDD)=1 then Dateadd(m, -1,@YYYYMMDD)
                                                       else @YYYYMMDD-day(@YYYYMMDD)+1
                                                       end
                               and @YYYYMMDD-1
and LotNo like case when @Mode='R' then '____[A-LO-Z]%'
                                  when @Mode='T' then '____[MN]%'
                                               else '%'
                                               end
and FG_Customer like case when @Mode='Y' then 'V%'
                                               else '%'
                                               end
and FG_Customer not like case when @Mode='N' then 'V%'
                                                      else ''
                                                      end
group by dbo.RealDateToMfgDate(MFG_Date), FG_Customer
),


TempC as (
select x.RN
         , x.KDMAT
         , x.SalePrice
from (
   select 'RN'=row_number() over (partition by 
                          case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                                  when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                   else KDMAT
                                   end 
                                                          order by AUDAT desc)
              ,'KDMAT'=case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                                        when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                       else KDMAT
                                       end 
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                        else NETPR*KURSK
                                        end
   from sap_sd_so_v
   where NETPR>0
   and VKORG='1100'
   ) x
where x.RN=1)


select b.MFGDate
          ,b.CustomerPN
          ,b.Qty
         ,'SalePrice'=isnull(c.SalePrice, 300)
         ,'Revenue'=b.Qty*isnull(c.SalePrice, 300)
         , 'Grade'=case when isnull(c.SalePrice, 300)<350 then 'Low'
                                   when isnull(c.SalePrice, 300)>=350 and isnull(c.SalePrice, 300)<450 then 'Normal'
                                   when isnull(c.SalePrice, 300)>=450 and isnull(c.SalePrice, 300)<550 then 'P'
                                   when isnull(c.SalePrice, 300)>=550 and isnull(c.SalePrice, 300)<650 then 'Q'
                                   when isnull(c.SalePrice, 300)>=650 and isnull(c.SalePrice, 300)<850 then 'T'
                                   when isnull(c.SalePrice, 300)>=850 and isnull(c.SalePrice, 300)<1000 then 'U'
                                   when isnull(c.SalePrice, 300)>=1000  then 'Test'
                                   else 'Others'
                                   end
from TempB b left join TempC c
on b.CustomerPN = c.KDMAT Collate Chinese_Taiwan_Stroke_CI_AS


/*
MFG_Date                FG_Customer Qty   SalePrice   Revenue        Grade
--------------------------------------------------------------------------
2023-06-30 00:00:00.000	02-14-0004	25	   510.0000000	12750.0000000	P
2023-06-30 00:00:00.000	02-14-0025	100	330.0000000	33000.0000000	Low
2023-06-30 00:00:00.000	02-14-0026	50	   330.0000000	16500.0000000	Low
2023-06-30 00:00:00.000	02-14-0027	50	   510.0000000	25500.0000000	P
2023-06-30 00:00:00.000	02-14-0028	150	300.0000000	45000.0000000	Low
2023-06-30 00:00:00.000	02-24-0001	50	   505.0000000	25250.0000000	P
2023-06-30 00:00:00.000	180-EALX8	50	   569.6790000	28483.9500000	Q
2023-07-01 00:00:00.000	180-EALX8	25	   569.6790000	14241.9750000	Q
2023-07-01 00:00:00.000	180-EDR38	25	   420.2550000	10506.3750000	Normal
2023-07-01 00:00:00.000	180-ELR18	100	569.6790000	56967.9000000	Q
2023-06-30 00:00:00.000	180-ELT08	100	569.6790000	56967.9000000	Q
2023-07-02 00:00:00.000	6C-29-0005	250	547.8880000	136972.0000000	P
2023-06-30 00:00:00.000	V65000013A	125	434.8400000	54355.0000000	Normal
*/