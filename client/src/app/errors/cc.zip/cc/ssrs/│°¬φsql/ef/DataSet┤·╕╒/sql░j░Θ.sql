DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;

/*
with
TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
)
select * from TempB

select DateAdd(mi, 1880, '20230704') -- 2023-07-05 7:20
select DateAdd(mi, 440+120, '20230704') -- 9:20
select DateAdd(mi, 440, '20230704') -- 7:20
select DateAdd(mi, 120, '20230704') -- 2:00
select DateAdd(mi, 0, '20230704') --0:00

select getdate()
*/


with
TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),
tempC as (
select 'N'=(N-440)/120*12800/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)
select * from tempc

/*
2133	2023-07-04 11:20:00.000
3200	2023-07-04 13:20:00.000
4266	2023-07-04 15:20:00.000
5333	2023-07-04 17:20:00.000
6400	2023-07-04 19:20:00.000
7466	2023-07-04 21:20:00.000
8533	2023-07-04 23:20:00.000
9600	2023-07-05 01:20:00.000
10666	2023-07-05 03:20:00.000
11733	2023-07-05 05:20:00.000
12800	2023-07-05 07:20:00.000
*/