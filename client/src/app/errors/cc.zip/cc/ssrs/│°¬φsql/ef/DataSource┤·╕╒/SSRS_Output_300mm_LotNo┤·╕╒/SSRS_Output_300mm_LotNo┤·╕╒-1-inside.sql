		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
               ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImageFN] B  with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)