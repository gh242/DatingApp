USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
-- DECLARE @Mode VARCHAR(2);
-- SET @Mode = 'A';


select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'HighT'=sum(Qty)
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
and CustomerPN like 'V65%[T]'
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
union all
select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'HighT'=0
          ,'HighQ'=sum(Qty)
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
and CustomerPN like 'V65%[Q]'
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
union all
select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=sum(Qty)
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
and ( CustomerPN like 'V65%P' or
          CustomerPN like 'V65%P2' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-ECLR8' or 
          CustomerPN='180-ECLT8' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-EALX8' or
          CustomerPN='180-ELR18' or
          CustomerPN='180-ELT08' 
        )
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
union all
select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=sum(Qty)
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
and CustomerPN not like 'V65%[PQT]'
and CustomerPN not like 'V65%P2'
and CustomerPN not like 'V650000[DF]%'
and CustomerPN not like 'V65000[67][DF]%'
and CustomerPN not like 'V6500[12][12][DF]%'
and CustomerPN<>'V65000013D'
and CustomerPN<>'V600001F'
and CustomerPN not like '02-14-0018'
and CustomerPN not like '02-14-002[1568]'
and CustomerPN not like '02-14-003[034]'
--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
and CustomerPN<>'180-ECLX8'     
and CustomerPN<>'180-ECLR8'
and CustomerPN<>'180-ECDR8'
and CustomerPN<>'180-ECDT8'
and CustomerPN<>'180-ECLT8'
and CustomerPN<>'180-ECLX8'
and CustomerPN<>'180-EALX8'
and CustomerPN<>'180-EDR38'
and CustomerPN<>'180-EDT38'
and CustomerPN<>'180-ELR18'
and CustomerPN<>'180-ELT08' 
and LotNo not like 'PSD2MZ_F[TX]%]'
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
union all
select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=sum(Qty)
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
and ( CustomerPN like 'V650000[DF]%' or
         CustomerPN like 'V65000[67][DF]%' or
         CustomerPN like 'V6500[12][12][DF]%' or 
         CustomerPN='V65000013D' or 
         CustomerPN='V600001F' or 
         CustomerPN like '02-14-0018' or 
         CustomerPN like '02-14-002[1568]' or 
         CustomerPN like '02-14-003[034]' or
         CustomerPN='180-ECDR8' or
         CustomerPN='180-ECDT8' or
         CustomerPN='180-EDR38' or
         CustomerPN='180-EDT38' or
         LotNo like 'PSD2MZ_F[TX]%]'
        )
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)

union all
select 'LotNo'=substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=-1*sum(MFG_MOVE)
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0
group by substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)

GO


/*
LotNo	HighT	HighQ	HighP	Normal	Low
-------------------------------------------
2A_E	0	    550	    0	    0	    0
22_E	0	    0	    100	    0	    0
26_C	0	    0	    550	    0	    0
2H_4	0	    0	    150	    0	    0
2A_E	0	    0	    225	    0	    0
26_C	0	    0	    0	    800	    0
2H_4	0	    0	    0	    50	    0
26_R	0	    0	    0	    500	    0
2S_4	0	    0	    0	    425	    0
26_J	0	    0	    0	    3500    0
2Y_C	0	    0	    0	    150	    0
21_C	0	    0	    0	    400	    0
28_4	0	    0	    0	    50	    0
2A_E	0	    0	    0	    300	    0
22_E	0	    0	    0	    25	    0
24_U	0	    0	    0	    900	    0
2H_C	0	    0	    0	    2000    0
2H_J	0	    0	    0	    200	    0
21_C	0	    0	    0	    0	    150
22_E	0	    0	    0	    0	    25
26_C	0	    0	    0	    0	    1025
26_J	0	    0	    0	    0	    1050
26_R	0	    0	    0	    0	    125
28_4	0	    0	    0	    0	    25
2A_E	0	    0	    0	    0	    100
2H_4	0	    0	    0	    0	    25
2H_C	0	    0	    0	    0	    875
2H_J	0	    0	    0	    0	    25
2S_4	0	    0	    0	    0	    75
2Y_C	0	    0	    0	    0	    125
26_C	0	    0	    0	    -575	0
26_J	0	    0	    0	    -25	    0
*/