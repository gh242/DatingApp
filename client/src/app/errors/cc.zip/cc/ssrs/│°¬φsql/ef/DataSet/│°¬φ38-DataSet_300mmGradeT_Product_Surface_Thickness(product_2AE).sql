USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Product
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime), Product , ProcessThickness
)

-- 19nm Non-Copper
select a.MFGDate, 'Line'='Non-Copper', Product='21E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='21E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='22E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='22E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='26E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='26E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='2AE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2AE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')union all
select a.MFGDate, 'Line'='Non-Copper', Product='2BE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2BE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='2SE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2SE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')

GO