USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

-- 報表35-內容測試-DataSet_300mm555
-- 與 報表 40(815),45(700),50(680) 很像，MANU_FROM_EQUID 不同

with TempA as ( 
--Non-Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Non-Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=555
and (MANU_FROM_LOTNO like '[1-9]___[EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0
/*
執行時間為:20230721 10:45
產生結果如下 
Print_Date	            Line	        Qty	    Loss
----------------------------------------------------
2023-07-11 09:45:22.000	Non-Copper	    0	    1
2023-07-11 09:45:22.000	Non-Copper	    0	    5
2023-07-11 12:27:16.000	Non-Copper	    0	    5
2023-07-11 12:27:16.000	Non-Copper	    0	    55
2023-07-11 12:27:52.000	Non-Copper	    0	    1
2023-07-11 12:27:52.000	Non-Copper	    0	    4
2023-07-11 14:40:33.000	Non-Copper	    0	    1
2023-07-11 14:40:33.000	Non-Copper	    0	    10
2023-07-11 14:40:33.000	Non-Copper	    0	    61
2023-07-11 16:18:45.000	Non-Copper	    0	    3
2023-07-11 16:18:45.000	Non-Copper	    0	    6
2023-07-11 16:18:45.000	Non-Copper	    0	    25
2023-07-11 16:18:45.000	Non-Copper	    0	    12
2023-07-11 18:28:40.000	Non-Copper	    0	    5
2023-07-11 18:28:40.000	Non-Copper	    0	    55
2023-07-11 18:28:40.000	Non-Copper	    0	    12
2023-07-11 09:45:13.000	Non-Copper	    110	    0
2023-07-11 09:45:22.000	Non-Copper	    237	    0
2023-07-11 12:26:50.000	Non-Copper	    50	    0
2023-07-11 12:27:04.000	Non-Copper	    306	    0
2023-07-11 12:27:16.000	Non-Copper	    54	    0
2023-07-11 12:27:37.000	Non-Copper	    36	    0
2023-07-11 12:27:45.000	Non-Copper	    128	    0
2023-07-11 12:27:52.000	Non-Copper	    60	    0
2023-07-11 14:40:17.000	Non-Copper	    421	    0
2023-07-11 14:40:24.000	Non-Copper	    231	    0
2023-07-11 16:18:15.000	Non-Copper	    285	    0
2023-07-11 16:18:30.000	Non-Copper	    33	    0
2023-07-11 16:19:47.000	Non-Copper	    50	    0
2023-07-11 18:28:34.000	Non-Copper	    267	    0
2023-07-11 18:28:40.000	Non-Copper	    188	    0
2023-07-12 06:12:05.000	Non-Copper	    0	    2
2023-07-12 06:12:05.000	Non-Copper	    0	    11
2023-07-12 06:12:05.000	Non-Copper	    0	    3
2023-07-12 06:16:29.000	Non-Copper	    0	    100
2023-07-12 06:33:55.000	Non-Copper	    0	    1
2023-07-12 06:11:45.000	Non-Copper	    100	    0
2023-07-12 06:11:54.000	Non-Copper	    574	    0
2023-07-12 06:12:05.000	Non-Copper	    108	    0
2023-07-12 06:12:33.000	Non-Copper	    21	    0
2023-07-12 06:16:11.000	Non-Copper	    300	    0
2023-07-12 06:16:29.000	Non-Copper	    182	    0
2023-07-12 06:33:45.000	Non-Copper	    289	    0
2023-07-12 06:33:55.000	Non-Copper	    60	    0
*/
union all
-- -- Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=555
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

/*
執行時間為:20230721 10:47
產生結果如下 
Print_Date	            Line	        Qty	    Loss
----------------------------------------------------
2023-07-11 10:39:33.000	Copper	        0	    23
2023-07-11 15:27:53.000	Copper	        0	    6
2023-07-11 15:27:53.000	Copper	        0	    1
2023-07-11 15:27:53.000	Copper	        0	    30
2023-07-11 15:27:53.000	Copper	        0	    244
2023-07-11 15:27:53.000	Copper	        0	    4
2023-07-11 15:30:34.000	Copper	        0	    7
2023-07-11 18:24:01.000	Copper	        0	    1
2023-07-11 18:24:01.000	Copper	        0	    99
2023-07-11 18:34:02.000	Copper	        0	    9
2023-07-11 18:34:02.000	Copper	        0	    50
2023-07-11 18:34:02.000	Copper	        0	    125
2023-07-11 18:43:57.000	Copper	        0	    8
2023-07-11 18:43:57.000	Copper	        0	    2
2023-07-11 18:43:57.000	Copper	        0	    5
2023-07-11 18:43:57.000	Copper	        0	    19
2023-07-11 18:43:57.000	Copper	        0	    11
2023-07-11 10:39:15.000	Copper	        116	    0
2023-07-11 10:39:24.000	Copper	        311	    0
2023-07-11 10:39:33.000	Copper	        125	    0
2023-07-11 10:39:44.000	Copper	        18	    0
2023-07-11 15:27:37.000	Copper	        300	    0
2023-07-11 15:27:45.000	Copper	        900	    0
2023-07-11 15:27:53.000	Copper	        470	    0
2023-07-11 15:28:26.000	Copper	        117	    0
2023-07-11 18:23:44.000	Copper	        131	    0
2023-07-11 18:23:53.000	Copper	        570	    0
2023-07-11 18:24:13.000	Copper	        99	    0
2023-07-11 18:31:41.000	Copper	        575	    0
2023-07-11 18:33:36.000	Copper	        775	    0
2023-07-11 18:33:51.000	Copper	        375	    0
2023-07-11 18:34:02.000	Copper	        310	    0
2023-07-11 18:43:32.000	Copper	        184	    0
2023-07-11 18:43:46.000	Copper	        205	    0
2023-07-11 18:43:57.000	Copper	        97	    0
2023-07-11 19:05:59.000	Copper	        129	    0
2023-07-12 03:32:55.000	Copper	        0	    3
2023-07-12 03:32:55.000	Copper	        0	    6
2023-07-12 03:32:55.000	Copper	        0	    50
2023-07-12 04:59:19.000	Copper	        0	    5
2023-07-12 04:59:19.000	Copper	        0	    9
2023-07-12 04:59:19.000	Copper	        0	    13
2023-07-12 06:37:42.000	Copper	        0	    1
2023-07-12 06:38:40.000	Copper	        0	    5
2023-07-12 06:38:40.000	Copper	        0	    107
2023-07-12 06:39:44.000	Copper	        0	    5
2023-07-12 06:42:35.000	Copper	        0	    2
2023-07-12 06:42:35.000	Copper	        0	    2
2023-07-12 06:42:35.000	Copper	        0	    4
2023-07-12 03:32:23.000	Copper	        1619	0
2023-07-12 03:32:42.000	Copper	        450	    0
2023-07-12 03:32:55.000	Copper	        100	    0
2023-07-12 03:33:30.000	Copper	        84	    0
2023-07-12 04:58:49.000	Copper	        925	    0
2023-07-12 04:59:08.000	Copper	        375	    0
2023-07-12 04:59:19.000	Copper	        136	    0
2023-07-12 04:59:42.000	Copper	        76	    0
2023-07-12 06:37:31.000	Copper	        197	    0
2023-07-12 06:37:42.000	Copper	        45	    0
2023-07-12 06:38:01.000	Copper	        7	    0
2023-07-12 06:38:15.000	Copper	        800	    0
2023-07-12 06:38:26.000	Copper	        24	    0
2023-07-12 06:38:40.000	Copper	        256	    0
2023-07-12 06:39:08.000	Copper	        150	    0
2023-07-12 06:39:19.000	Copper	        975	    0
2023-07-12 06:39:29.000	Copper	        37	    0
2023-07-12 06:39:44.000	Copper	        250	    0
2023-07-12 06:42:24.000	Copper	        550	    0
2023-07-12 06:42:35.000	Copper	        40	    0
2023-07-12 06:43:00.000	Copper	        2	    0
*/

)


select x.Interval
         ,x.Line
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,'Loss'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Loss
                             else null 
                             end 
         ,'TargetQty'=x.TargetQty/2
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
          ,'TargetQty'=1*@Stripper*@TargetOutput300mm/12   --1*1.05*12800/12
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD) 
            )
group by a.Line

union all
select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=2*@Stripper*@TargetOutput300mm/12   --2*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD)  and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
group by a.Line

/*
執行時間為:20230721 11:10
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
*/
union all
select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=3*@Stripper*@TargetOutput300mm/12   --3*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 11:15
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
*/
union all
select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=4*@Stripper*@TargetOutput300mm/12   --4*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:09
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
*/

union all
select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=5*@Stripper*@TargetOutput300mm/12   --5*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:10
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
2023-07-11 17:20:00	Copper	     2357	315	5600
2023-07-11 17:20:00	Non-Copper	2001	189	5600
*/

union all
select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=6*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:11
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
2023-07-11 17:20:00	Copper	     2357	315	5600
2023-07-11 17:20:00	Non-Copper	2001	189	5600
2023-07-11 19:20:00	Copper	     5807	644	6720
2023-07-11 19:20:00	Non-Copper	2456	261	6720
*/

union all
select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=7*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:11
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
2023-07-11 17:20:00	Copper	     2357	315	5600
2023-07-11 17:20:00	Non-Copper	2001	189	5600
2023-07-11 19:20:00	Copper	     5807	644	6720
2023-07-11 19:20:00	Non-Copper	2456	261	6720
2023-07-11 21:20:00	Copper	     5807	644	7840
2023-07-11 21:20:00	Non-Copper	2456	261	7840
*/

union all
select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=8*@Stripper*@TargetOutput300mm/12   --8*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:11
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
2023-07-11 17:20:00	Copper	     2357	315	5600
2023-07-11 17:20:00	Non-Copper	2001	189	5600
2023-07-11 19:20:00	Copper	     5807	644	6720
2023-07-11 19:20:00	Non-Copper	2456	261	6720
2023-07-11 21:20:00	Copper	     5807	644	7840
2023-07-11 21:20:00	Non-Copper	2456	261	7840
2023-07-11 23:20:00	Copper	     5807	644	8960
2023-07-11 23:20:00	Non-Copper	2456	261	8960
*/

union all
select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=9*@Stripper*@TargetOutput300mm/12   --9*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
group by a.Line
/*
執行時間為:20230721 13:12
產生結果如下 
Interval	          Line	          Qty	Loss	TargetQty
------------------------------------------------------
2023-07-11 11:20:00	Copper	     570	23	2240
2023-07-11 11:20:00	Non-Copper	347	6	2240
2023-07-11 13:20:00	Copper	     570	23	3360
2023-07-11 13:20:00	Non-Copper	981	71	3360
2023-07-11 15:20:00	Copper	     570	23	4480
2023-07-11 15:20:00	Non-Copper	1633	143	4480
2023-07-11 17:20:00	Copper	     2357	315	5600
2023-07-11 17:20:00	Non-Copper	2001	189	5600
2023-07-11 19:20:00	Copper	     5807	644	6720
2023-07-11 19:20:00	Non-Copper	2456	261	6720
2023-07-11 21:20:00	Copper	     5807	644	7840
2023-07-11 21:20:00	Non-Copper	2456	261	7840
2023-07-11 23:20:00	Copper	     5807	644	8960
2023-07-11 23:20:00	Non-Copper	2456	261	8960
2023-07-12 01:20:00	Copper	     5807	644	10080
2023-07-12 01:20:00	Non-Copper	2456	261	10080
*/


union all
select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=10*@Stripper*@TargetOutput300mm/12   --10*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=11*@Stripper*@TargetOutput300mm/12   --11*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=12*@Stripper*@TargetOutput300mm/12   --12*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
group by a.Line
) x


GO


/*
執行時間為:20230721 10:56
產生結果如下 
Interval	            Line	      Qty	    Loss	TargetQty
-----------------------------------------------------------------
2023-07-11 11:20:00	    Copper	        570	    23	    1120
2023-07-11 11:20:00	    Non-Copper	    347	    6	    1120
2023-07-11 13:20:00	    Copper	        570	    23	    1680
2023-07-11 13:20:00	    Non-Copper	    981	    71	    1680
2023-07-11 15:20:00	    Copper	        570	    23	    2240
2023-07-11 15:20:00	    Non-Copper	    1633	143	    2240
2023-07-11 17:20:00	    Copper	        2357	315	    2800
2023-07-11 17:20:00	    Non-Copper	    2001	189	    2800
2023-07-11 19:20:00	    Copper	        5807	644	    3360
2023-07-11 19:20:00	    Non-Copper	    2456	261	    3360
2023-07-11 21:20:00	    Copper	        5807	644	    3920
2023-07-11 21:20:00	    Non-Copper	    2456	261	    3920
2023-07-11 23:20:00	    Copper	        5807	644	    4480
2023-07-11 23:20:00	    Non-Copper	    2456	261	    4480
2023-07-12 01:20:00	    Copper	        5807	644	    5040
2023-07-12 01:20:00	    Non-Copper	    2456	261	    5040
2023-07-12 03:20:00	    Copper	        5807	644	    5600
2023-07-12 03:20:00	    Non-Copper	    2456	261	    5600
2023-07-12 05:20:00	    Copper	        9572	730	    6160
2023-07-12 05:20:00	    Non-Copper	    2456	261	    6160
2023-07-12 07:20:00	    Copper	        12905	856	    6720
2023-07-12 07:20:00	    Non-Copper	    4090	378	    6720
*/