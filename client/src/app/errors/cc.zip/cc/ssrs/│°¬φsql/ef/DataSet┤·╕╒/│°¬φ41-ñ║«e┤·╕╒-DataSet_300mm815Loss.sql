USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

--  報表36-DataSet_300mm555Loss 
--  與報表 41(815Loss), 46(700Loss), 51(680Loss) 相似

--Non-Copper
select 'Line'='Non-Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1) --取125碼
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=815
and (a.MANU_FROM_LOTNO like '____[EGJKFMNPX]%' or a.MANU_FROM_LOTNO like '6___X%')
and a.MANU_FROM_LOTNO not like '9V__E%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)

union all
--Copper
select 'Line'='Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=815
and (a.MANU_FROM_LOTNO like '____[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and a.MANU_FROM_LOTNO not like '6___X%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)


GO

/*
執行時間為:20230725 9:57
產生結果如下 
Line	    LotNo	DESCRIPTION	       Qty
--------------------------------------------
Non-Copper	24_F	Re Polish(重拋)	    29
Non-Copper	2H_F	Re Polish(重拋)	    21
Non-Copper	2Y_F	Re Polish(重拋)	    36
Non-Copper	6A_X	Re Polish(重拋)	    13
Non-Copper	21_J	Reclean(重洗)	    22
Non-Copper	2A_E	Reclean(重洗)	    31
Non-Copper	2Y_E	Reclean(重洗)	    19
Non-Copper	95_M	Reclean(重洗)	    99
Non-Copper	21_J	Remeasuring	        4
Non-Copper	2A_E	Remeasuring	        114
Non-Copper	95_M	Remeasuring	        95
Non-Copper	9V_M	Remeasuring	        12
Copper	    2H_C	Haze(剔退)	        3
Copper	    6A_C	ID Reject	        1
Copper	    24_U	Re Polish(重拋)	    39
Copper	    6A_C	Re Polish(重拋)	    25
Copper	    52_C	Reclean(重洗)	    24
Copper	    6A_C	Reclean(重洗)	    67
Copper	    24_U	Remeasuring         4
Copper	    26_C	Remeasuring         104
Copper	    6A_C	Remeasuring         4
Copper	    24_U	Return sort(退Sort)	1
Copper	    6A_C	Return sort(退Sort)	1
*/