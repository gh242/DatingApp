USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230717';

DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;

with TempA as (
select Print_Date
         ,'HighT'=Qty
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer like 'V65%[T]'
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=Qty
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer like 'V65%[Q]'
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=Qty
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and ( FG_Customer like 'V65%P' or
          FG_Customer like 'V65%P2' or
          FG_Customer='180-ECLX8' or
          FG_Customer='180-ECLR8' or 
          FG_Customer='180-ECLT8' or
          FG_Customer='180-ECLX8' or
          FG_Customer='180-EALX8' or
          FG_Customer='180-ELR18' or
          FG_Customer='180-ELT08' 
        )
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=Qty
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer not like 'V65%[PQT]'
and FG_Customer not like 'V65%P2'
and FG_Customer not like 'V650000[DF]%'
and FG_Customer not like 'V65000[67][DF]%'
and FG_Customer not like 'V6500[12][12][DF]%'
and FG_Customer<>'V65000013D'
and FG_Customer<>'V600001F'
and FG_Customer not like '02-14-0018'
and FG_Customer not like '02-14-002[1568]'
and FG_Customer not like '02-14-003[034]'
--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
and FG_Customer<>'180-ECLX8'     
and FG_Customer<>'180-ECLR8'
and FG_Customer<>'180-ECDR8'
and FG_Customer<>'180-ECDT8'
and FG_Customer<>'180-ECLT8'
and FG_Customer<>'180-ECLX8'
and FG_Customer<>'180-EALX8'
and FG_Customer<>'180-EDR38'
and FG_Customer<>'180-EDT38'
and FG_Customer<>'180-ELR18'
and FG_Customer<>'180-ELT08' 
and LotNo not like 'PSD2MZ_F[TX]%]'
union all
select Print_Date
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=Qty
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and ( FG_Customer like 'V650000[DF]%' or 
         FG_Customer like 'V65000[67][DF]%' or
         FG_Customer like 'V6500[12][12][DF]%' or
         FG_Customer='V65000013D' or
         FG_Customer='V600001F' or
         FG_Customer like '02-14-0018' or 
         FG_Customer like '02-14-002[1568]' or 
         FG_Customer like '02-14-003[034]' or
         FG_Customer='180-ECDR8' or
         FG_Customer='180-ECDT8' or
         FG_Customer='180-EDR38' or
         FG_Customer='180-EDT38' or
         LotNo like 'PSD2MZ_F[TX]%]')
union all
select 'Print_Date'=DateAdd(mi, 1760, @YYYYMMDD)
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
          ,'Normal'=-1*MANU_QTY   
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'  
AND MANU_FMLB='M'
and MANU_QTY>0
),

TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),

tempC as (
select 'N'=(N-440)/120*@TargetOutput300mm/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)


--select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
--          ,'HighT'=sum(a.HighT) 
--          ,'HighQ'=sum(a.HighQ) 
--          ,'HighP'=sum(a.HighP) 
--          ,'Normal'=sum(a.Normal)
--          ,'Low'=sum(a.Low)
--          ,'TargetQty'=@TargetOutput300mm/12
--from TempA a
--where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
--               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
--               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD)
--            )
--union all
--select 'Interval'=b.Interval
--          ,'HighT'=sum(a.HighT) 
--          ,'HighQ'=sum(a.HighQ) 
--          ,'HighP'=sum(a.HighP) 
--          ,'Normal'=sum(a.Normal)
--          ,'Low'=sum(a.Low)
--          ,'TargetQty'=b.N
--from TempA a, tempC b
--where (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<b.Interval)
--group by b.Interval, b.N

/*
���͵��G�p�U
���͵��G�p�U  20230704 ����ɶ��A��20230717 11:30
Interval			    HightT HightQ HigthP Normal Low TargetQty
---------------------------------------------------------------
2023-07-17 09:20:00	0	    0	    150		500	  325	  1066
2023-07-17 11:20:00	0	    0	    275		975	  525	  2133
2023-07-17 13:20:00	NULL	NULL	NULL	NULL	NULL	3200
2023-07-17 15:20:00	NULL	NULL	NULL	NULL	NULL	4266
2023-07-17 17:20:00	NULL	NULL	NULL	NULL	NULL	5333
2023-07-17 19:20:00	NULL	NULL	NULL	NULL	NULL	6400
2023-07-17 21:20:00	NULL	NULL	NULL	NULL	NULL	7466
2023-07-17 23:20:00	NULL	NULL	NULL	NULL	NULL	8533
2023-07-18 01:20:00	NULL	NULL	NULL	NULL	NULL	9600
2023-07-18 03:20:00	NULL	NULL	NULL	NULL	NULL	10666
2023-07-18 05:20:00	NULL	NULL	NULL	NULL	NULL	11733
2023-07-18 07:20:00	NULL	NULL	NULL	NULL	NULL	12800
*/



--select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
--          ,'HighT'=sum(a.HighT) 
--          ,'HighQ'=sum(a.HighQ) 
--          ,'HighP'=sum(a.HighP) 
--          ,'Normal'=sum(a.Normal)
--          ,'Low'=sum(a.Low)
--          ,'TargetQty'=@TargetOutput300mm/12
--from TempA a
--where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
--               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
--               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD)
--            )

-- Interval			    HightT HightQ HigthP Normal Low TargetQty
-----------------------------------------------------------------
--2023-07-17 09:20:00	0		0		300	 1000	525	1066



select 'Interval'=b.Interval
          ,'HighT'=sum(a.HighT) 
          ,'HighQ'=sum(a.HighQ) 
          ,'HighP'=sum(a.HighP) 
          ,'Normal'=sum(a.Normal)
          ,'Low'=sum(a.Low)
          ,'TargetQty'=b.N
from TempA a, tempC b
where (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<b.Interval)
group by b.Interval, b.N
/*
���͵��G�p�U  20230704 ����ɶ��A��20230717 11:30
Interval			    HightT HightQ HigthP Normal   Low   TargetQty
---------------------------------------------------------------------
2023-07-04 11:20:00	    0	    100	    75	  1800	  500	2133
2023-07-04 13:20:00	    0	    250	    275	  2575	  800	3200
2023-07-04 15:20:00	    0	    300	    325	  3350	  1125	4266
2023-07-04 17:20:00	    0	    325	    375	  4375	  1450	5333
2023-07-04 19:20:00	    0	    350	    525	  5175	  1775	6400
2023-07-04 21:20:00	    0	    425	    625	  5725	  1950	7466
2023-07-04 23:20:00	    0	    425	    725	  6350	  2225	8533
2023-07-05 01:20:00	    0	    475	    825	  7075	  2450	9600
2023-07-05 03:20:00	    0	    500	    875	  7675	  2750	10666
2023-07-05 05:20:00	    0	    500	    950	  8400	  3225	11733
2023-07-05 07:20:00	    0	    550	    1025  8550	  3575	12800
*/

/*
���͵��G�p�U  20230717 ����ɶ��A��20230717 11:30
Interval			      HightT HightQ HigthP Normal Low TargetQty
---------------------------------------------------------------
2023-07-17 11:20:00	0	    0	     300	  1075	  550	2133
2023-07-17 13:20:00	0	    0	     300	  1075	  550	3200
2023-07-17 15:20:00	0	    0	     300	  1075	  550	4266
2023-07-17 17:20:00	0	    0	     300	  1075	  550	5333
2023-07-17 19:20:00	0	    0	     300	  1075	  550	6400
2023-07-17 21:20:00	0	    0	     300	  1075	  550	7466
2023-07-17 23:20:00	0	    0	     300	  1075	  550	8533
2023-07-18 01:20:00	0	    0	     300	  1075	  550	9600
2023-07-18 03:20:00	0	    0	     300	  1075	  550	10666
2023-07-18 05:20:00	0	    0	     300	  1075	  550	11733
2023-07-18 07:20:00	0	    0	     300	  1075	  550	12800
*/

--select 
--'N'=b.N,
--'Interval'=b.Interval
--          ,'HighT'=sum(a.HighT) 
--          ,'HighQ'=sum(a.HighQ) 
--          ,'HighP'=sum(a.HighP) 
--          ,'Normal'=sum(a.Normal)
--          ,'Low'=sum(a.Low)
--          ,'TargetQty'=b.N
--from TempA a, tempC b
--group by b.Interval, b.N

--select * from TempA
--select * from TempB
--select * from tempC

/*
--TempA
Print_Data			    HightT HightQ HigthP Normal Low
-------------------------------------------------------
2023-07-04 19:42:10.000	0	    25	    0	    0	0
2023-07-04 13:01:33.000	0	    25	    0	    0	0
2023-07-04 08:49:59.000	0	    25	    0	    0	0
2023-07-04 11:58:14.000	0	    25	    0	    0	0
2023-07-04 12:12:19.000	0	    25	    0	    0	0
2023-07-04 11:41:57.000	0	    25	    0	    0	0
2023-07-04 07:38:34.000	0	    25	    0	    0	0
2023-07-05 01:01:56.000	0	    25	    0	    0	0
2023-07-04 09:09:53.000	0	    25	    0	    0	0
2023-07-05 06:05:25.000	0	    25	    0	    0	0
2023-07-05 00:42:47.000	0	    25	    0	    0	0
2023-07-04 14:41:51.000	0	    25	    0	    0	0
2023-07-05 05:45:31.000	0	    25	    0	    0	0
2023-07-04 08:18:08.000	0	    25	    0	    0	0
2023-07-04 18:52:35.000	0	    25	    0	    0	0
2023-07-05 02:38:15.000	0	    25	    0	    0	0
2023-07-04 20:02:50.000	0	    25	    0	    0	0
2023-07-04 20:53:56.000	0	    25	    0	    0	0
2023-07-04 12:41:37.000	0	    25	    0	    0	0
2023-07-04 14:26:55.000	0	    25	    0	    0	0
2023-07-04 16:10:50.000	0	    25	    0	    0	0
2023-07-04 12:26:24.000	0	    25	    0	    0	0
2023-07-04 14:50:56.000	0	    0	    25	    0	0
2023-07-04 07:42:14.000	0	    0	    25	    0	0
2023-07-04 17:59:06.000	0	    0	    25	    0	0
2023-07-04 23:39:07.000	0	    0	    25	    0	0
2023-07-04 21:54:07.000	0	    0	    25	    0	0
2023-07-04 21:00:30.000	0	    0	    25	    0	0
2023-07-05 06:34:42.000	0	    0	    25	    0	0
2023-07-05 03:42:01.000	0	    0	    25	    0	0
2023-07-05 06:53:50.000	0	    0	    25	    0	0
2023-07-04 11:35:52.000	0	    0	    25	    0	0
2023-07-04 22:13:03.000	0	    0	    25	    0	0
2023-07-04 15:41:46.000	0	    0	    25	    0	0
2023-07-04 18:59:06.000	0	    0	    25	    0	0
2023-07-04 18:45:15.000	0	    0	    25	    0	0
2023-07-04 20:30:38.000	0	    0	    25	    0	0
2023-07-04 07:35:24.000	0	    0	    25	    0	0
2023-07-04 11:33:44.000	0	    0	    25	    0	0
2023-07-04 07:26:38.000	0	    0	    25	    0	0
2023-07-04 19:53:53.000	0	    0	    25	    0	0
2023-07-04 12:57:13.000	0	    0	    25	    0	0
2023-07-04 12:32:44.000	0	    0	    25	    0	0
2023-07-05 06:00:14.000	0	    0	    25	    0	0
*/

/*
--TempB
N
---
680
800
920
1040
1160
1280
1400
1520
1640
1760
1880
*/

/*
--TempC
N       Interval
--------------------------
2133	2023-07-04 11:20:00
3200	2023-07-04 13:20:00
4266	2023-07-04 15:20:00
5333	2023-07-04 17:20:00
6400	2023-07-04 19:20:00
7466	2023-07-04 21:20:00
8533	2023-07-04 23:20:00
9600	2023-07-05 01:20:00
10666	2023-07-05 03:20:00
11733	2023-07-05 05:20:00
12800	2023-07-05 07:20:00
*/

