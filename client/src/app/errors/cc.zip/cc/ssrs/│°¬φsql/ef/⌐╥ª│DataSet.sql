select

報表1
    Data source:  WarInfo
    Dataset:      DataSet_300mmTodayAccumulate
    資料表:        SSRS_Output_300mm_Time
                  [RCS_NEW].[dbo].[FN_MANUFACTURE]

報表2
    Data source: WarInfo
    Dataset:     DataSet_200mmTodayAccumulate
    資料表:       SSRS_Output_200mm_Time
                 [RCS_200mm].[dbo].[FN_MANUFACTURE]

報表3
    Data source: WarInfo
    Dataset:     DataSet_Revenue
    資料表:       SSRS_Output_300mm_Time
                 sap_sd_so_v

報表4
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT
    資料表:       EDA_Tencorlog
                  StationName='TENCOR_17'

報表5
    Data source: WarInfo
    Dataset:     DataSet_300mmParticleBoxPolit19nm
    資料表:       EDA_Tencorlog

報表6 Oracle
    Data source: MESDB_Redaim
    Dataset:     DataSet_EquipmentStatus
    資料表:       EQPGROUP_MFG
                 TBLEMSEQUIPMENTSTATE
                 TBLEQPEQUIPMENTBASIS
                 TBLEMSEQUIPMENTSTATELOG

報表7
    Data source: WarInfo
    Dataset:     DataSet_300mmTodayLotNo
    資料表:       SSRS_Output_300mm_LotNo
                 [RCS_NEW].[dbo].[FN_MFG_WORK]

報表8
    Data source: WarInfo
    Dataset:     DataSet_300mmCustomerAccumulate
    資料表:       SSRS_Output_300mm_LotNo
                 [RCS_NEW].[dbo].[FN_MFG_WORK]

報表9
    Data source: WarInfo
    Dataset:     DataSet_300mmCustomerAccumulate
    資料表:       SSRS_Output_300mm_LotNo
                 [RCS_NEW].[dbo].[FN_MFG_WORK]

報表10
    Data source: WarInfo
    Dataset:     DataSet_200mmTodayLotNo
    資料表:       SSRS_Output_200mm_LotNo
                 [RCS_200mm].[dbo].[FN_MFG_WORK]

報表11
    Data source: WarInfo
    Dataset:     DataSet_300mmEquipmentYield19nm
    資料表:       EDA_Tencorlog

報表12 與報表11一樣
    Data source: WarInfo
    Dataset:     DataSet_300mmEquipmentYield19nm
    資料表:       EDA_Tencorlog

報表13
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeTQP_Thickness
    資料表:       EDA_Tencorlog

報表14
    Data source: WarInfo
    Dataset:     DataSet_300mmAccumulateTsmcPN
    資料表:       SSRS_Output_300mm_LotNo
                 [RCS_NEW].[dbo].[FN_MFG_WORK]

報表15
    Data source: WarInfo
    Dataset:     DataSet_200mmLotNoAccumulate
    資料表:       SSRS_Output_200mm_LotNo
                 [RCS_200mm].[dbo].[FN_MFG_WORK]

報表16
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeQ
    資料表:       EDA_Tencorlog

報表17
    Data source: WarInfo
    Dataset:     DataSet_300mmParticleBoxPolit26nm
    資料表:       EDA_Tencorlog

報表18
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT_Surface
    資料表:       EDA_Tencorlog

報表19
    Data source: WarInfo
    Dataset:     DataSet_300mmYield4F
    資料表:       EDA_Tencorlog

報表20
    Data source: WarInfo
    Dataset:     DataSet_300mmYield1B
    資料表:       EDA_Tencorlog

報表21
    Data source: WarInfo
    Dataset:     DataSet_300mmEquipmentYield26nm
    資料表:       EDA_Tencorlog

報表22
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT_Surface
    資料表:       EDA_Tencorlog

報表23
    Data source: WarInfo
    Dataset:     DataSet_300mmYieldPolish4F
    資料表:       EDA_Tencorlog

報表24
    Data source: WarInfo
    Dataset:     DataSet_300mmYieldPolish1B
    資料表:       EDA_Tencorlog

報表25
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeQ_Thickness
    資料表:       EDA_Tencorlog

報表26
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeQ_Thickness
    資料表:       EDA_Tencorlog

報表27
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT_SurfaceAndThickness
    資料表:       EDA_Tencorlog

報表28
    Data source: WarInfo
    Dataset:     DataSet_300mmYieldEbara
    資料表:       EDA_Tencorlog

報表29
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeP
    資料表:       EDA_Tencorlog

報表30
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeP
    資料表:       EDA_Tencorlog

報表31
    Data source: WarInfo
    Dataset:     DataSet_300mmPolish
    資料表:       EDA_Tencorlog

報表32
    Data source: WarInfo
    Dataset:     DataSet_300mmPolishAll
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]

報表33
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeP
    資料表:       EDA_Tencorlog

報表34
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT_SurfaceAndThickness
    資料表:       EDA_Tencorlog

報表35
    Data source: WarInfo
    Dataset:     DataSet_300mm555
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]

報表36
    Data source: WarInfo
    Dataset:     DataSet_300mm555Loss
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]
                  [RCS_NEW].[dbo].[FN_CODE_DEFINITION]

報表37
    Data source: WarInfo
    Dataset:     DataSet_300mmParticleBoxPolit32nm
    資料表:       EDA_Tencorlog

報表38,39,43,44,48,49
    Data source: WarInfo
    Dataset:     DataSet_300mmGradeT_Product_Surface_Thickness
    資料表:       EDA_Tencorlog

報表40
    Data source: WarInfo
    Dataset:     DataSet_300mm815
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]

報表41
    Data source: WarInfo
    Dataset:     DataSet_300mm815Loss
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]
                  [RCS_NEW].[dbo].[FN_CODE_DEFINITION]

報表42
    Data source: WarInfo
    Dataset:     DataSet_300mmPolisherParticleBoxpolit
    資料表:       EDA_Tencorlog

報表45
    Data source: WarInfo
    Dataset:     DataSet_300mm700
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]
                  [RCS_NEW].[dbo].[FN_CODE_DEFINITION]

報表46
    Data source: WarInfo
    Dataset:     DataSet_300mm700Loss
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]
                  [RCS_NEW].[dbo].[FN_CODE_DEFINITION]

報表47 52
    Data source: WarInfo
    Dataset:     DataSet_300mmCleanerParticleBoxPolit
    資料表:       EDA_Tencorlog

報表50
    Data source: WarInfo
    Dataset:     DataSet_300mm680
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]

報表51
    Data source: WarInfo
    Dataset:     DataSet_300mm680Loss
    資料表:       [RCS_NEW].[dbo].[FN_MANUFACTURE]
                  [RCS_NEW].[dbo].[FN_CODE_DEFINITION]

報表53 54 55
    Data source: RCS_New
    Dataset:     DataSet_300mmAfterCMPWIP
    資料表:       FN_WIP_2HOUR
                 

報表56 60 64 68 72 76
    Data source: RCS_New
    Dataset:     DataSet_300mmDailyWIP
    資料表:       FN_WIP_2HOUR

報表57 58 59  61 62 63  65 66 67  69 70 71  73 74 75
    Data source: RCS_New
    Dataset:     DataSet_300mmWIP
    資料表:       FN_WIP_2HOUR

報表77
    Data source: WarInfo
    Dataset:     DataSet_Revenue
    資料表:       SSRS_Output_300mm_Time
                  sap_sd_so_v


--報表57-DataSet_300mmWIP(WIP_LINE_Non_Copper_633_670)
--報表58-DataSet_300mmWIP(WIP_LINE_Copper_633_670)
--報表59-DataSet_300mmWIP(633_670)

--報表61-DataSet_300mmWIP(WIP_LINE_Non_Copper_680)
--報表62-DataSet_300mmWIP(WIP_LINE_Copper_680)
--報表63-DataSet_300mmWIP(680)

--報表65-DataSet_300mmWIP(WIP_LINE_Non_Copper_755)
--報表66-DataSet_300mmWIP(WIP_LINE_Copper_755)
--報表67-DataSet_300mmWIP(755)

--報表69-DataSet_300mmWIP(WIP_LINE_Non_Copper_810_811)
--報表70-DataSet_300mmWIP(WIP_LINE_Copper_810_811)
--報表71-DataSet_300mmWIP(810_811)

--報表73-DataSet_300mmWIP(WIP_LINE_Non_Copper_815)
--報表74-DataSet_300mmWIP(WIP_LINE_Copper_815)
--報表75-DataSet_300mmWIP(815)
                

