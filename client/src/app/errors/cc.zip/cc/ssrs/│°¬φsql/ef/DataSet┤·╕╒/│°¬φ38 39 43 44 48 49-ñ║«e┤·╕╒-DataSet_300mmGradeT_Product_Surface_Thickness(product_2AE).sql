USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230724';


-- 報表38-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_2AE)
-- 報表39-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_21E)
-- 報表43-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_2BE)
-- 報表44-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_22E)
-- 報表48-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_2SE)
-- 報表49-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_26E)

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Product
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime), Product , ProcessThickness
/*
執行時間為:20230725 9:47
產生結果如下 
Line	MFGDate	Product	ProcessThickness	Qty	Percentage
-------------------------------------------------------------------
Non-Copper	2023-07-08 00:00:00.000	22E	S	292	0.597137014314928
Non-Copper	2023-07-01 00:00:00.000	22E	S	280	0.563380281690140
Non-Copper	2023-06-30 00:00:00.000	2AE	S	240	0.404040404040404
Non-Copper	2023-07-11 00:00:00.000	2AE	S	242	0.553775743707093
Non-Copper	2023-06-30 00:00:00.000	22E	S	21	0.875000000000000
Non-Copper	2023-06-29 00:00:00.000	2AE	S	14	0.482758620689655
Non-Copper	2023-07-11 00:00:00.000	2AE	A	45	0.319148936170212
Non-Copper	2023-07-12 00:00:00.000	2AE	S	30	0.379746835443037
*/
)

-- 19nm Non-Copper
select a.MFGDate, 'Line'='Non-Copper', Product='21E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='21E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='22E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='22E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='26E', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='26E'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='2AE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2AE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')union all
select a.MFGDate, 'Line'='Non-Copper', Product='2BE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2BE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate, 'Line'='Non-Copper', Product='2SE', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Product='2SE'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')

GO

/*
執行時間為:20230725 9:50
產生結果如下 
MFGDate	            Line	    Product	ProcessThickness	Qty	    Percentage
------------------------------------------------------------------------------
2023-07-24 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-22 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-12 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	21E	    X	                NULL	NULL
2023-07-24 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-22 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-12 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	22E	    X	                NULL	NULL
2023-07-22 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-12 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-24 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	26E	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	2AE	    A	                45	    0.319148936170212
2023-07-11 00:00:00	Non-Copper	2AE	    S	                242	    0.553775743707093
2023-07-12 00:00:00	Non-Copper	2AE	    S	                30	    0.379746835443037
2023-07-22 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-24 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	2AE	    X	                NULL	NULL
2023-07-24 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-22 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-12 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	2BE	    X	                NULL	NULL
2023-07-24 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-23 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-22 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-21 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-20 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-19 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-18 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-17 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-16 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-15 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-14 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-13 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-12 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	2SE	    X	                NULL	NULL
*/