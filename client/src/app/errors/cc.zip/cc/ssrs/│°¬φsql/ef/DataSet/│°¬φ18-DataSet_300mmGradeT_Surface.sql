USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

/*
-- Copper
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime)
),
*/

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime), Process
)

-- 19nm Non-Copper
select a.MFGDate, 'Line'='Non-Copper', 'nm'='19nm', 'Process'=isnull(b.Process, 'NA'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate

/*
-- 26nm Copper
union all
select a.MFGDate, 'Line'='Copper', 'nm'='26nm', b.Qty, b.Percentage
from TempDay a left join tempC b
                         on a.MFGDate=b.MFGDate
*/

GO



/*
產生結果如下 執行時間，為20230719 09:13
MFGDate	            Line	    nm	    Process	Qty	    Percentage
-------------------------------------------------------------------------
2023-07-08 00:00:00	Non-Copper	19nm	GA	    292	    0.597137014314928
2023-07-01 00:00:00	Non-Copper	19nm	GA	    280	    0.563380281690140
2023-07-12 00:00:00	Non-Copper	19nm	GA	    19	    0.404255319148936
2023-06-30 00:00:00	Non-Copper	19nm	GA	    261	    0.422330097087378
2023-07-12 00:00:00	Non-Copper	19nm	GP	    11	    0.343750000000000
2023-06-29 00:00:00	Non-Copper	19nm	GA	    14	    0.482758620689655
2023-07-11 00:00:00	Non-Copper	19nm	GA	    287	    0.496539792387543
2023-07-05 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-02 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-03 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-09 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-06 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-07 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-04 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-07-10 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
2023-06-28 00:00:00	Non-Copper	19nm	NA	    NULL	NULL
*/