USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

--報表42-內容測試-DataSet_300mmPolisherParticleBoxpolit(GradeP GradeA)
--報表37-內容測試-DataSet_300mmParticleBoxPolit32nm(GradeP)
--報表17-內容測試-DataSet_300mmParticleBoxPolit26nm(GradeQ)
--報表5-內容測試-DataSet_300mmParticleBoxPolit19nm(GradeT)

--報表47-DataSet_300mmCleanerParticleBoxPolit
--報表52-DataSet_300mmCleanerParticleBoxPolit

with TempA as (
-- Copper
select 'Line'='Copper'
          ,'Polisher'=Polisher
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 70 and 88 )
and WaferGrade='GradeA'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
/*
Line	      Polisher	ParticleCount1
-------------------------------------
Copper	2	      19
Copper	2	      22
Copper	14	      21
Copper	14	      15
Copper	14	      23
Copper	14	      6
Copper	14	      10
Copper	14	      14
Copper	14	      24
Copper	14	      13
Copper	14	      10
Copper	14	      18
Copper	14	      33
Copper	14	      5
Copper	6	      32
Copper	6	      6
Copper	6	      24
Copper	6	      9
Copper	6	      20
...
2142筆
*/
),

-- Non-Copper
TempB as (
select 'Line'='Non-Copper'
          ,'Polisher'=Polisher
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 70 and 88 )
and WaferGrade='GradeA'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
/*
Line	      Polisher	ParticleCount1
-------------------------------------
Non-Copper	26	      18
Non-Copper	26	      19
Non-Copper	26	      17
Non-Copper	26	      28
Non-Copper	26	      35
Non-Copper	28	      30
Non-Copper	28	      14
Non-Copper	28	      8
Non-Copper	28	      16
Non-Copper	28	      38
Non-Copper	28	      22
Non-Copper	28	      17
Non-Copper	28	      17
Non-Copper	28	      15
Non-Copper	26	      29
Non-Copper	26	      34
Non-Copper	26	      35
Non-Copper	26	      20
Non-Copper	26	      35
Non-Copper	22	      19
Non-Copper	22	      7
Non-Copper	22	      8
Non-Copper	22	      5
Non-Copper	22	      11
Non-Copper	22	      9
...
1203筆
*/
),

TempC as (
-- Copper
select 'Line'='Copper'
          ,'Polisher'=Polisher
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
/*
Line	      Polisher	ParticleCount1
-------------------------------------
Copper	12	      73
Copper	12	      109
Copper	12	      61
Copper	12	      86
Copper	12	      139
Copper	12	      41
Copper	12	      47
Copper	12	      27
Copper	12	      100
Copper	12	      125
Copper	12	      63
Copper	17	      90
Copper	17	      106
Copper	17	      120
...
1134筆
*/
),

-- -- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'Polisher'=Polisher
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
/*
Line	      Polisher	ParticleCount1
-------------------------------------
Non-Copper	20	      16
Non-Copper	27	      60
Non-Copper	27	      86
Non-Copper	27	      57
Non-Copper	27	      65
Non-Copper	20	      69
Non-Copper	20	      23
Non-Copper	20	      29
Non-Copper	20	      26
Non-Copper	20	      21
Non-Copper	20	      17
...
327筆
*/

)


select distinct 'Line'='Copper', 'nm'='88nm', Polisher
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher))
from tempA with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='88nm', Polisher
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher))
from tempB with(nolock)

union all
select distinct 'Line'='Copper', 'nm'='32nm', Polisher
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher))
from tempC with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='32nm', Polisher
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher))
from tempD with(nolock)
GO


/*
執行時間為:20230725 10:12
產生結果如下 
Line	      nm	Polisher	Box_Max	Box_Min	Box_Avg	Box_75	Box_50	Box_25
--------------------------------------------------------------------------------------------------------------
Copper	88nm	1	      70	      1	      23	      31	      22	      11.75
Copper	88nm	14	      67	      3	      27	      37.25	      24	      15.75
Copper	88nm	3	      77	      4	      24	      31	      20	      14
Copper	88nm	7	      60	      0	      18	      25	      17	      11
Copper	88nm	8	      65	      0	      22	      31	      20	      12
Copper	88nm	15	      54	      38	      44	      48.75	      43.5	      39.5
Copper	88nm	4	      72	      6	      26	      34	      25	      17
Copper	88nm	13	      69	      3	      25	      36.5	      21	      14
Copper	88nm	2	      58	      2	      20	      27	      18	      10.5
Copper	88nm	10	      61	      61	      61	      61	      61	      61
Copper	88nm	17	      67	      2	      20	      25.25	      19	      13.75
Copper	88nm	6	      74	      1	      22	      31	      20.5	      12
Copper	88nm	11	      70	      3	      24	      34	      24.5	      13.75
Non-Copper	88nm	23	      66	      2	      16	      21	      14	      8.25
Non-Copper	88nm	16	      60	      2	      14	      17.75	      11	      8
Non-Copper	88nm	31	      56	      0	      16	      21.75	      11.5	      6
Non-Copper	88nm	21	      46	      0	      17	      23	      16	      10
Non-Copper	88nm	29	      53	      5	      20	      29	      18	      11.5
Non-Copper	88nm	22	      64	      1	      17	      23	      14	      8
Non-Copper	88nm	28	      50	      4	      19	      26	      17	      11
Non-Copper	88nm	20	      59	      7	      18	      20	      15	      12
Non-Copper	88nm	32	      70	      3	      21	      27	      16	      9
Non-Copper	88nm	26	      55	      0	      19	      25	      17	      12
Non-Copper	88nm	30	      55	      1	      17	      20.5	      13.5	      8
Copper	32nm	12	      194	      27	      83	      104.75      73	      54
Copper	32nm	25	      183	      8	      38	      43	      31.5	      24
Copper	32nm	11	      141	      36	      78	      89.5	      76	      61
Copper	32nm	17	      194	      46	      113	      135	      117	      90
Copper	32nm	24	      181	      6	      36	      41	      25	      17
Copper	32nm	27	      178	      7	      39	      43	      30	      23
Non-Copper	32nm	-23	      144	      6	      59	      84	      44	      28
Non-Copper	32nm	19	      151	      34	      67	      66.25	      53.5	      48
Non-Copper	32nm	20	      177	      9	      45	      55	      36	      27
Non-Copper	32nm	27	      86	      38	      61	      64.25	      60.5	      59
Non-Copper	32nm	18	      155	      14	      39	      44	      31	      25
*/