select 'TargetOutputA'=sum(TargetQty300mm)
from [WarInfo].[dbo].[TargetOutput] with(nolock)
where convert(char(6), TargetDate, 112)=convert(char(6), @EndDate, 112)