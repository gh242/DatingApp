USE [WarInfo]
GO

DECLARE @EndDate SMALLDATETIME;
SET @EndDate = '20230726';
DECLARE @DistanceDaily int;
SET @DistanceDaily = 31;


with TempA as (
select x.MFGDATE, x.CustomerPN, 'Qty'=sum(x.Qty)
from (
select 
-- *
         MFGDate
         ,CustomerPN
         ,'Qty'=sum(Qty)
from SSRS_Output_300mm with(nolock)
where MFGDate between cast(convert(char(7), @EndDate, 120)+'-01' as datetime) and @EndDate
group by MFGDate, CustomerPN
/*
執行時間為:20230727 16:10
產生結果如下 
MFGDate	               CustomerPN	Qty
---------------------------------------
2023-07-22 00:00:00.000	02-14-0003	25
2023-07-10 00:00:00.000	02-14-0026	75
2023-07-13 00:00:00.000	02-14-0026	50
2023-07-14 00:00:00.000	02-14-0027	50
2023-07-26 00:00:00.000	02-14-0028	75
2023-07-26 00:00:00.000	180-ECLX8	75
2023-07-15 00:00:00.000	180-ECR78	50
2023-07-18 00:00:00.000	180-ECR78	175
2023-07-23 00:00:00.000	180-ECT68	25
2023-07-10 00:00:00.000	180-ECX88	50
2023-07-20 00:00:00.000	180-EDR38	50
...
793筆
*/

/*
union all
select 'MFGDate'=cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
       ,'CustomerPN'='Rework'
       ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between convert(char(6), @EndDate, 112)+'-01' and convert(char(8), @EndDate, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
group by cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
*/

) x
group by x.MFGDATE, x.CustomerPN
),

TempC as (
select x.RN
         ,'KDMAT'=case when x.KDMAT like '_% _%' then left(x.KDMAT, charindex(' ', x.KDMAT)-1)
                                   else x.KDMAT
                                   end
         ,x.SalePrice
from (
   select 'RN'=row_number() over (partition by case when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                   else KDMAT
                                   end
                                                          order by AUDAT desc)
              ,KDMAT
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                        else NETPR*KURSK
                                        end
   from sap_sd_so_v
   where NETPR>0
   and VKORG='1100'
   ) x
where x.RN=1)


select a.MFGDate
         ,'Revenue'=sum(a.Qty*isnull(c.SalePrice, 300))
from TempA a left join TempC c
on a.CustomerPN=c.KDMAT
group by a.MFGDate
order by a.MFGDate desc

/*
執行時間為:20230727 15:50
產生結果如下 
MFGDate	               Revenue
---------------------------------------
2023-07-26 00:00:00.000	4196022.9540000
2023-07-25 00:00:00.000	3190441.7000000
2023-07-24 00:00:00.000	3313320.9750000
2023-07-23 00:00:00.000	4103107.8750000
2023-07-22 00:00:00.000	3306182.4750000
2023-07-21 00:00:00.000	3619458.5000000
2023-07-20 00:00:00.000	4077564.5750000
2023-07-19 00:00:00.000	4063037.3750000
2023-07-18 00:00:00.000	4954010.2500000
2023-07-17 00:00:00.000	4893945.5250000
2023-07-16 00:00:00.000	5430076.2750000
2023-07-15 00:00:00.000	5568020.3750000
2023-07-14 00:00:00.000	5133378.3000000
2023-07-13 00:00:00.000	4687729.0250000
2023-07-12 00:00:00.000	5402632.0250000
2023-07-11 00:00:00.000	5904518.5000000
2023-07-10 00:00:00.000	5571885.1000000
2023-07-09 00:00:00.000	5438729.4000000
2023-07-08 00:00:00.000	5561443.1250000
2023-07-07 00:00:00.000	5401883.2500000
2023-07-06 00:00:00.000	5626418.5000000
2023-07-05 00:00:00.000	5530005.0000000
2023-07-04 00:00:00.000	6066586.8750000
2023-07-03 00:00:00.000	5778108.8750000
2023-07-02 00:00:00.000	5083095.0000000
2023-07-01 00:00:00.000	5469943.1000000

*/