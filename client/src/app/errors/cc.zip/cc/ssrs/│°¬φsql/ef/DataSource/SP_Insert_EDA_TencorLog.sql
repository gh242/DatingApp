USE [WarInfo]
GO

/****** Object:  StoredProcedure [dbo].[SP_Insert_EDA_TencorLog]    Script Date: 2023/7/26 上午 09:25:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
















ALTER PROCEDURE [dbo].[SP_Insert_EDA_TencorLog] 
@DateBegin char(19),
@DateEnd  char (19)
AS
BEGIN
	set transaction Isolation Level Read Uncommitted 
	set nocount on

	declare @First as char(1), @StationNameTemp char(9), @CollectionTimeTemp Datetime
	declare @ID varchar(38), @StationName char(9), @CollectionTime Datetime, @LotID varchar(40), @RecipeName varchar(17)
	declare @ParticleSize1 integer, @ParticleSize2 integer, @Process char(2), @ProcessThickness char(1)
	declare @PolishShift char(1), @Polisher char(1), @PolishNo smallint
	declare @PreCleaner char(1), @PreCleanNo smallint, @PreCleanSide char(1)
	declare @FinalCleaner char(1), @FinalCleanNo smallint, @FinalCleanSide char(1), @FinalCleaner2 char(1), @FinalCleanNo2 smallint, @FinalCleanSide2 char(1)
	declare @SpendTime datetime, @Text Varchar(1024)


declare @LotIDtemp varchar(1024)


 	set @SpendTime = GetDate()

	select 'ID'=newID(), * into #TempA
		 from  [WarInfo].[dbo].[EDA_TencorLog] with(nolock)
		where 1<>1

	insert into #TempA
		select newID()
		           ,a.[STATION_NAME]
				   ,'MFGDate'=dbo.RealDateToMfgDate10(a.[COLLECTION_TIME])
				   ,a.[COLLECTION_TIME]
                   ,a.[Lot_ID]
                   ,'WaferGrade'=case when a.[WAFERGRADE] like 'GRADE%' then 'Grade'+substring(a.[WAFERGRADE], 6, 1)
			                          when a.[WAFERGRADE] like 'REJECT%' or a.[WAFERGRADE] like 'OVERLOAD%' then 'Reject'
			                          when a.[WAFERGRADE] like 'REPLOISH%' then 'Reploish'
				                      else upper(left(a.[WAFERGRADE], 1))+right(lower(a.[WAFERGRADE]), len(a.[WAFERGRADE])-1)
						              end
				  ,'WaferGradeOriginal'=a.[WAFERGRADE]
                   ,a.[PPExecName]
	               ,a.[KlarfName]
				   ,'Product'=left(a.[Lot_ID], 2)+substring(a.[Lot_ID], 5, 1)
				   ,'Result'=case when a.[WAFERGRADE]='PASS' or a.[WAFERGRADE] like 'GRADE[ABCDEFGNOPQST]%' then '1'
				                  else '0'
								  end
				   ,a.[HazeAverage]
	               ,a.[Flaw_Counts_0]
	               ,a.[Flaw_Counts_1]
				   ,a.[Flaw_Counts_19]
                   ,a.[Flaw_Counts_21]
                   ,a.[Flaw_Counts_20]
                   ,a.[Flaw_Counts_22]
                   ,'RPW350_LotID'=case when len(a.[RPW350_LotID])>40  then
										case when a.[RPW350_LotID] like '_______-20______-%' then right(a.[RPW350_LotID], len(a.[RPW350_LotID])-8)
									         else left(a.[RPW350_LotID], 40)
											 end
				                       else a.[RPW350_LotID]
									   end
	               ,a.[T7ID]
                   ,a.[Thickness_Center]
                   ,a.[TTV]
                   ,a.[BowBf]
                   ,a.[WarpBf]
                   ,a.[Resistivity]
                   ,a.[PN_Type]
                   ,a.[Class]
                   ,a.[LastPolish_Thickness_Center_Variation]
                   ,a.[LastPolish_TTV_Variation]
                   ,a.[LastPolish_WarpBf_Variation]
                   ,a.[Thickness_Center_Variation]
                   ,a.[TTV_Variation]
                   ,a.[WarpBf_Variation]
                   ,null, null, null, null ,null, null, null, null ,null, null, null, null, null, null, null, null, null, null, null, null
			from [EDC].[dbo].[EDC_VIEW_810_Map_T7ID_FN] a with(nolock)
			where a.COLLECTION_TIME between @DateBegin and @DateEnd
			    and (a.Lot_ID like '[2-9]%' or Lot_ID like 'PS_2%')
			    and (a.Lot_ID like '__________-____-__[0-9][0-9]-_[0-9][0-9]%' or 
				     a.Lot_ID like '__________-_____-__[0-9][0-9]-_[0-9][0-9]%' or 
				     a.Lot_ID like '__________-____-__[0-9][0-9]_-_[0-9][0-9]%' or 
				     a.Lot_ID like '__________-__[0-9][0-9]-H___%' or 
					 a.Lot_ID like '__________-__[0-9][0-9]_-H___%' or 
					 a.Lot_ID like '______-%-P-%' or
					 -- Grinding
					 a.Lot_ID like '_______G___-____-__[0-9][0-9]-_[0-9][0-9]%' or 
				     a.Lot_ID like '_______G___-_____-__[0-9][0-9]-_[0-9][0-9]%' or 
				     a.Lot_ID like '_______G___-____-__[0-9][0-9]_-_[0-9][0-9]%' 
					)   --or Lot_ID like '______-P-%[ND]-[0-9]%')
				and a.Lot_ID not like '5-________-__________-[1-9]_________-__'
			    --and len(Lot_ID)>=24
				and not exists (select 1 from [WarInfo].[dbo].[EDA_TencorLog] b with(nolock)
									where a.[STATION_NAME]=b.[StationName]
									  and a.[COLLECTION_TIME]=b.[CollectionTime]
						   )


	set @First='Y'

	declare CursorTencor cursor for
		select ID, StationName, CollectionTime, LotID, RecipeName 
			from #TempA
			order by StationName, CollectionTime

	open CursorTencor
			fetch next from CursorTencor into @ID, @StationName, @CollectionTime, @LotID, @RecipeName
			while @@fetch_status = 0 
				begin
				    -- delete duplicate
					if @First='N' and @StationNameTemp=@StationName and @CollectionTimeTemp=@CollectionTime
						delete from #TempA where ID=@ID
					else
						begin
						   -- Grinding
							if (@LotID like '_______G___-____-__[0-9][0-9]-_[0-9][0-9]%' or 
				                @LotID like '_______G___-_____-__[0-9][0-9]-_[0-9][0-9]%' or 
				                @LotID like '_______G___-____-__[0-9][0-9]_-_[0-9][0-9]%'
							   )
								set @LotID=Left(@LotID, 10)+right(@LotID, len(@LotID)-11) 
                            
							-- Ebara : S->更換SC1 spong , P->更換SC2 spong , F->更換pad , D->當run 發生當機

                            --  '__________-____-__[0-9][0-9][FR]-_[0-9][0-9]%'  S50 : F->更換精拋 pad , R->更換粗拋 pad , X->首件
							if @LotID like '__________-____-__[0-9][0-9]_-_[0-9][0-9]%'
								set @LotID=Left(@LotID, 20)+right(@LotID, len(@LotID)-21)
							if @LotID like '__________-_____-__[0-9][0-9]-_[0-9][0-9]%'
								set @LotID=Left(@LotID, 15)+right(@LotID, len(@LotID)-16)
							if @LotID like '__________-__[0-9][0-9]_-H___%'
								set @LotID=Left(@LotID, 15)+right(@LotID, len(@LotID)-16)

--if @StationName='TENCOR_17'  exec [master].[dbo].[SpMySyslog] '1', @LotID
							If @First='Y' set @First='N'
		     				--particle size1
							set @ParticleSize1=null
							select top 1 @ParticleSize1=cast(DisplayName as numeric(5,4))*1000 
								from [EDC].[dbo].[EDC_Map_Recipe]
								where StationName=@StationName
								and Recipe=@RecipeName
								and BeginTime<=@CollectionTime
								and Seq=110
								order by BeginTime desc
		     				--particle size1
							set @ParticleSize2=null
							select top 1 @ParticleSize2=cast(DisplayName as numeric(5,4))*1000 
								from [EDC].[dbo].[EDC_Map_Recipe]
								where StationName=@StationName
								and Recipe=@RecipeName
								and BeginTime<=@CollectionTime
								and Seq=120
								order by BeginTime desc
			--select @Text =cast(@ParticleSize as varchar(10))
			--exec [master].[dbo].[SpMySyslog] '1', @Text

							-- 計算ParticleSize/Shift/polish/PreClean/FinalClean
							-- 2SJ4E44DAA-T04L-VF12-D02F19  for S50 R/F and Pre-clean
							-- 26J4J21DAA-3J1L-VK22-M02    for EBARA
							--set @i=charindex('-', @@LotID); -- 找第1個 dash
							set @Process=substring(@LotID, 8, 2) 
							set @ProcessThickness=substring(@LotID, 10, 1) 
							if substring(@LotID, 12, 1)  in ('1', '2', '3', '4', '5', '6', '7', '8', '9') -- EBARA
								begin
										set @PreCleaner=substring(@LotID, 12, 1) 
										--set @PolishShift=substring(@LotID, 13, 1)    2022-01-03
										If substring(@LotID, 14, 1) in ('1', '2', '3', '4', '5', '6', '7', '8', '9')
												set @PreCleanNo=substring(@LotID, 14, 1)					-- ???
										else
												set @PreCleanNo=ascii(substring(@LotID, 14, 1))-ascii('A')+10	-- ???
										set @PreCleanSide=substring(@LotID, 15, 1)
										set @PolishShift=substring(@LotID, 17, 1) 
										set @Polisher=substring(@LotID, 18, 1) 
										set @PolishNo=case when IsNumeric(substring(@LotID, 19, 2))=1 then substring(@LotID, 19, 2) 
																			 else null
																			 end

										if @LotID like '__________-____-__[0-9][0-9]-T[0-9][0-9]_-_[0-9][0-9]%'
												begin
													set @FinalCleaner=substring(@LotID, 27, 1) 
													set @FinalCleanNo=case when IsNumeric(substring(@LotID, 28, 2))=1 then substring(@LotID, 28, 2)
																								  else null
																								  end
													if @FinalCleaner='H'
														begin
															set @FinalCleanSide=substring(@LotID, 30, 1)
															if substring(@LotID, 31, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 31, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 32, 2))=1 then substring(@LotID, 32, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																		set @FinalCleanSide2=substring(@LotID, 34, 1)
																	else
																		set @FinalCleanSide2=' '
																end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																	set @FinalCleanSide2=' '
																end
														end
													else
														begin
															set @FinalCleanSide=' '
															if substring(@LotID, 30, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 30, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 31, 2))=1 then substring(@LotID, 31, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																			set @FinalCleanSide2=substring(@LotID, 33, 1)
																		else
																			set @FinalCleanSide2=' '
																	end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																	set @FinalCleanSide2=' '
																end
														end
												end
										else
												begin
													set @FinalCleaner=substring(@LotID, 22, 1) 
													set @FinalCleanNo=case when IsNumeric(substring(@LotID, 23, 2))=1 then substring(@LotID, 23, 2)
																								  else null
																								  end
													if @FinalCleaner='H'
														begin
															if substring(@LotID, 26, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 26, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 27, 2))=1 then substring(@LotID, 27, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																		set @FinalCleanSide2=substring(@LotID, 29, 1)
																	else
																		set @FinalCleanSide2=null
																end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																end
														end
													else
														begin
															set @FinalCleanSide=' '
															if substring(@LotID, 25, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 25, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 26, 2))=1 then substring(@LotID, 26, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																			set @FinalCleanSide2=substring(@LotID, 28, 1)
																	else
																			set @FinalCleanSide2=' '
																end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																	set @FinalCleanSide2=' '
																end
														end
												end
								end
							else   --Non-Ebara
								if @LotID like '__________-____-H___%'
										begin
											set @PreCleaner=substring(@LotID, 17, 1)
											if @PreCleaner='K'
												begin
													set @PreCleanNo=case when IsNumeric(substring(@LotID, 18, 3))=1 then substring(@LotID, 18, 3)
																							   else null
																							   end
													set @PreCleanSide=' '
												end
											else
												begin
													set @PreCleanNo=case when IsNumeric(substring(@LotID, 18, 2))=1 then substring(@LotID, 18, 2)
																							   else null
																							   end
													set @PreCleanSide=substring(@LotID, 20, 1)
												end
											set @PolishShift=substring(@LotID, 12, 1) 
											set @Polisher=substring(@LotID, 13, 1) 
											set @PolishNo=case when IsNumeric(substring(@LotID, 14, 2))=1 then substring(@LotID, 14, 2)
																				  else null
																				  end
											if @LotID like '__________-____-H___-___%'
												begin
														set @FinalCleaner=substring(@LotID, 22, 1) 
														set @FinalCleanNo=case when IsNumeric(substring(@LotID, 23, 2))=1 then substring(@LotID, 23, 2)
																									  else null
																									  end
														if @FinalCleaner='H'
																set @FinalCleanSide=substring(@LotID, 25, 1)
														else
																set @FinalCleanSide=' '
														set @FinalCleaner2=null
														set @FinalCleanNo2=null
														set @FinalCleanSide2=' '
												end
											else
												begin
													set @FinalCleaner=null
													set @FinalCleanNo=null
													set @FinalCleanSide=' '
													set @FinalCleaner2=null
													set @FinalCleanNo2=null
													set @FinalCleanSide2=' '
												end
										end
								else
										begin
											set @PreCleaner=substring(@LotID, 12, 1) 
											if @PreCleaner='K'
												begin
													set @PreCleanNo=case when IsNumeric(substring(@LotID, 13, 3))=1 then substring(@LotID, 13, 3)
																							  else null
																							  end
													set @PreCleanSide=' '
												end
											else
												begin
													set @PreCleanNo=case when IsNumeric(substring(@LotID, 13, 2))=1 then substring(@LotID, 13, 2)
																							  else null
																							  end
													set @PreCleanSide=substring(@LotID, 15, 1)
												end								 
											set @PolishShift=substring(@LotID, 17, 1) 
											set @Polisher=substring(@LotID, 18, 1) 
											set @PolishNo=case when IsNumeric(substring(@LotID, 19, 2))=1 then substring(@LotID, 19, 2)
																				 else null
																				 end
											if @LotID like '__________-____-__[0-9][0-9]-T[0-9][0-9]_-_[0-9][0-9]%'
												begin
													set @FinalCleaner=substring(@LotID, 27, 1) 
													set @FinalCleanNo=case when IsNumeric(substring(@LotID, 28, 2))=1 then substring(@LotID, 28, 2)
																								  else null
																								  end
													if @FinalCleaner='H'
														begin
															set @FinalCleanSide=substring(@LotID, 30, 1)
															if substring(@LotID, 31, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 32, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 33, 2))=1 then substring(@LotID, 33, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																			set @FinalCleanSide2=substring(@LotID, 35, 1)
																	else
																			set @FinalCleanSide2=' '
																end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																	set @FinalCleanSide2=' '
																end
														end
													else
														begin
															set @FinalCleanSide=' '
															if substring(@LotID, 30, 1) in ('S', 'D', 'B', 'G', 'F', 'M', 'H')
																begin
																	set @FinalCleaner2=substring(@LotID, 30, 1) 
																	set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 31, 2))=1 then substring(@LotID, 31, 2)
																													else null
																													end
																	if @FinalCleaner2='H'
																			set @FinalCleanSide2=substring(@LotID, 33, 1)
																	else
																			set @FinalCleanSide2=' '
																end
															else
																begin
																	set @FinalCleaner2=null
																	set @FinalCleanNo2=null
																	set @FinalCleanSide2=' '
																end
														end
												end
											else
												--if substring(@LotID, 22, 1) not in ('A', 'C', 'D', 'B', 'G', 'F', 'M'
												if substring(@LotID, 22, 1) in ('A', 'C', 'D', 'B', 'G', 'F', 'M', 'H')
													begin
														set @FinalCleaner=substring(@LotID, 22, 1) 
														set @FinalCleanNo=case when IsNumeric(substring(@LotID, 23, 2))=1 then substring(@LotID, 23, 2)
																									  else null
																									  end
														if @FinalCleaner='H'
															begin
																set @FinalCleanSide=substring(@LotID, 25, 1)
																if substring(@LotID, 26, 1) in ('A', 'C', 'D', 'B', 'G', 'F', 'M', 'H')
																	begin
																		set @FinalCleaner2=substring(@LotID, 26, 1) 
																		set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 27, 2))=1 then substring(@LotID, 27, 2)
																													   else null
																													   end
																		if @FinalCleaner2='H'
																				set @FinalCleanSide2=substring(@LotID, 28, 1)
																		else
																				set @FinalCleanSide2=' '
																	end
																else
																	begin
																		set @FinalCleaner2=null
																		set @FinalCleanNo2=null
																		set @FinalCleanSide2=' '
																	end
															end
														else
															begin
																set @FinalCleanSide=' '
																if substring(@LotID, 25, 1) in ('A', 'C', 'D', 'B', 'G', 'F', 'M', 'H')
																	begin
																		set @FinalCleaner2=substring(@LotID, 25, 1) 
																		set @FinalCleanNo2=case when IsNumeric(substring(@LotID, 26, 2))=1 then substring(@LotID, 26, 2)
																													   else null
																													   end
																		if @FinalCleaner2='H'
																				set @FinalCleanSide2=substring(@LotID, 28, 1)
																		else
																				set @FinalCleanSide2=' '
																	end
																else
																	begin
																		set @FinalCleaner2=null
																		set @FinalCleanNo2=null
																		set @FinalCleanSide2=' '
																	end
															end
													end
												else
													begin
														set @FinalCleaner=null
														set @FinalCleanNo=null
														set @FinalCleanSide=' '
   														set @FinalCleaner2=null
														set @FinalCleanNo2=null
														set @FinalCleanSide2=' '
													end
										end

							update #TempA
								set ParticleSize1=@ParticleSize1
								     ,ParticleSize2=@ParticleSize2
									 ,Process=@Process
									 ,ProcessThickness=@ProcessThickness
									 ,PolishShift=@PolishShift
									 ,Polisher=case when @Polisher like '[1-9]' then @Polisher
									                            else ascii(@Polisher)-ascii('A')+10
																end
									 ,PolishNo=@PolishNo
									 ,PreCleaner=case when @PreCleaner='K' then 'PC2'
									                                 when @PreCleaner='A' then 'I-Clean'
																	 when @PreCleaner='T' then 'FC3'
																	 when @PreCleaner='S' then 'PC3'
    																 when @PreCleaner like '[1-9]' then 'Ebara'+@PreCleaner
																	 when @PreCleaner='H' then 'SCC1'  -- 20200916 added by FN
																	 else @PreCleaner
															         end
									 ,PreCleanNo=@PreCleanNo
									 ,PreCleanSide=@PreCleanSide
									 ,FinalCleaner=case when @FinalCleaner='A' then 'I-Clean'
																	   when @FinalCleaner='M' then 'ACM1'
																	   when @FinalCleaner='C' then 'SC1'
																	   when @FinalCleaner='D' then 'SC2'
																	   when @FinalCleaner='B' then 'Oasis'
																	   when @FinalCleaner='G' then 'GF1'
																	   when @FinalCleaner='F' then 'GF2'
																	   when @FinalCleaner='H' then 'SCC1'  -- 20200916 added by FN
									                                   else @FinalCleaner
															           end
									 ,FinalCleanNo=@FinalCleanNo
									 ,FinalCleanSide=@FinalCleanSide
									 ,FinalCleaner2=case when @FinalCleaner2='A' then 'I-Clean'
																	     when @FinalCleaner2='M' then 'ACM1'
																	     when @FinalCleaner2='C' then 'SC1'
																	     when @FinalCleaner2='D' then 'SC2'
																	     when @FinalCleaner2='B' then 'Oasis'
																	     when @FinalCleaner2='G' then 'GF1'
																	     when @FinalCleaner2='F' then 'GF2'
																		 when @FinalCleaner2='H' then 'SCC1'  -- 20200916 added by FN
									                                     else @FinalCleaner2
															             end
									 ,FinalCleanNo2=@FinalCleanNo2
									 ,FinalCleanSide2=@FinalCleanSide2
								 where StationName=@StationName 
									and CollectionTime=@CollectionTime
									--and LotID=@@LotID
							end

						--set @StationNameTemp=@StationName
						--set @CollectionTimeTemp=@CollectionTime

					fetch next from CursorTencor into @ID, @StationName, @CollectionTime, @LotID, @RecipeName
				end
	close CursorTencor
	deallocate CursorTencor

	--Begin Transaction	
/*
	delete from [WarInfo].[dbo].[EDA_TencorLog]
			where CollectionTime between @DateBegin and @DateEnd
			    and (LotID like '[2-9]%' or LotID like 'PS_2%')
			    and (LotID like '__________-____-__[0-9][0-9]-_[0-9][0-9]%' or 
					     LotID like '__________-_____-__[0-9][0-9]-_[0-9][0-9]%' or 
				         LotID like '__________-____-__[0-9][0-9]_-_[0-9][0-9]%' or 
				         LotID like '__________-__[0-9][0-9]-H___%' or
						 LotID like '__________-__[0-9][0-9]_-H___%' or 
						 LotID like '______-%-P-%' or
						 -- Grinding
						 LotID like '_______G___-____-__[0-9][0-9]-_[0-9][0-9]%' or 
				         LotID like '_______G___-_____-__[0-9][0-9]-_[0-9][0-9]%' or 
				         LotID like '_______G___-____-__[0-9][0-9]_-_[0-9][0-9]%' 
						) 
			    and LotID not like '5-________-__________-[1-9]_________-__'
*/

--select * from #TempA
	 insert into [WarInfo].[dbo].[EDA_TencorLog]
		select [StationName]
		          ,[MFGDate]
				  ,[CollectionTime]
				  ,[LotID]
				  ,[WaferGrade]
				  ,[WaferGradeOriginal]
				  ,[RecipeName]
				  ,[KlarfName]
				  ,[Product]
				  ,[Result]
				  ,[HazeAverage]
				  ,[ParticleCount1]
				  ,[ParticleCount2]
				  ,[AreaCount]
				  ,[TotalArea]
				  ,[ScratchCount]
				  ,[ScratchLength]
				  ,[RPW350_LotID]
				  ,[T7ID]
				  ,[ThicknessCenter]
				  ,[TTV]
				  ,[Bow]
				  ,[Warp]
				  ,[Resistivity]
				  ,[PNtype]
				  ,[Class]
				  ,[VariationLastPolishThicknessCenter]
				  ,[VariationLastPolishTTV]
				  ,[VariationLastPolishWarp]
				  ,[VariationThicknessCenter]
				  ,[VariationTTV]
				  ,[VariationWarp]
				  ,[ParticleSize1]
				  ,[ParticleSize2]
				  ,[Process]
				  ,[ProcessThickness]
				  ,[PolishShift]
				  ,[Polisher]
				  ,[PolishNo]
				  /*
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 1, 8)   -- Fine Recipe
             	  ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 17, 8) -- Rough Recipe
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 10, 6) -- Fine PAD used time
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 26, 6) -- Rough PAD used time
				  2020-12-13 marged by FN because Virus crash */
	              ,substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 1, 8)   -- Fine Recipe
             	  ,substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 17, 8) -- Rough Recipe
	              ,substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 10, 6) -- Fine PAD used time
	              ,substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 26, 6) -- Rough PAD used time

				  ,[PreCleaner]
				  ,[PreCleanNo]
				  ,[PreCleanSide]
				  ,[FinalCleaner]
				  ,[FinalCleanNo]
				  ,[FinalCleanSide]
				  ,[FinalCleaner2]
				  ,[FinalCleanNo2]
				  ,[FinalCleanSide2]
			from #TempA

	Drop Table #TempA


	-- for 成品Re-Sort used
	select 'ID'=newID(), * into #TempB
		from  [WarInfo].[dbo].[EDA_TencorLog] with(nolock)
		where 1<>1

	insert into #TempB
		select newID()
		           ,a.[STATION_NAME]
			       ,'MFGDate'=dbo.RealDateToMfgDate10(a.[COLLECTION_TIME])
				   ,a.[COLLECTION_TIME]
                   ,a.[Lot_ID]
                   ,'WaferGrade'=case when a.[WAFERGRADE] like 'GRADE%' then 'Grade'+substring(a.[WAFERGRADE], 6, 1)
			                          when a.[WAFERGRADE] like 'REJECT%' or a.[WAFERGRADE] like 'OVERLOAD%' then 'Reject'
			                          when a.[WAFERGRADE] like 'REPLOISH%' then 'Reploish'
				                      else upper(left(a.[WAFERGRADE], 1))+right(lower(a.[WAFERGRADE]), len(a.[WAFERGRADE])-1)
						              end
				  ,'WaferGradeOriginal'=a.[WAFERGRADE]
                   ,a.[PPExecName]
	               ,a.[KlarfName]
				   ,'Product'=substring(a.[Lot_ID], 23, 2)+substring(a.[Lot_ID], 27, 1)
				   ,'Result'=case when a.[WAFERGRADE]='PASS' or a.[WAFERGRADE] like 'GRADE[ABCDEFGNOPQST]%' then '1'
				                  else '0'
								  end
				   ,a.[HazeAverage]
	               ,a.[Flaw_Counts_0]
	               ,a.[Flaw_Counts_1]
				   ,a.[Flaw_Counts_19]
                   ,a.[Flaw_Counts_21]
                   ,a.[Flaw_Counts_20]
                   ,a.[Flaw_Counts_22]
                   ,'RPW350_LotID'=case when len(a.[RPW350_LotID])>40  then
											case when a.[RPW350_LotID] like '_______-20______-%' then right(a.[RPW350_LotID], len(a.[RPW350_LotID])-8)
												 else left(a.[RPW350_LotID], 40)
												 end
				                        else a.[RPW350_LotID]
										end
	               ,a.[T7ID]
                   ,a.[Thickness_Center]
                   ,a.[TTV]
                   ,a.[BowBf]
                   ,a.[WarpBf]
                   ,a.[Resistivity]
                   ,a.[PN_Type]
                   ,a.[Class]
                   ,a.[LastPolish_Thickness_Center_Variation]
                   ,a.[LastPolish_TTV_Variation]
                   ,a.[LastPolish_WarpBf_Variation]
                   ,a.[Thickness_Center_Variation]
                   ,a.[TTV_Variation]
                   ,a.[WarpBf_Variation]
                   ,null, null, null, null ,null, null, null, null ,null, null, null, null, null, null, null, null, null, null, null, null
			from [EDC].[dbo].[EDC_VIEW_810_Map_T7ID_FN] a with(nolock)
			where a.COLLECTION_TIME between @DateBegin and @DateEnd
			    and a.Lot_ID like '5-________-__________-[1-9]_________-__'
				and not exists (select 1 from [WarInfo].[dbo].[EDA_TencorLog] b with(nolock)
									where a.[STATION_NAME]=b.[StationName]
									  and a.[COLLECTION_TIME]=b.[CollectionTime])

	set @First='Y'
							set @Process=null
							set @ProcessThickness=null
							set @Polisher=null
							set @PolishNo=null
							set @PolishShift=null
							set @PreCleaner=null
							set @PreCleanNo=null
							set @PreCleanSide=' '
							set @FinalCleaner=null
							set @FinalCleanNo=null
							set @FinalCleanSide=' '
							set @FinalCleaner2=null
							set @FinalCleanNo2=null
							set @FinalCleanSide2=' '

	declare CursorTencor cursor for
		select ID, StationName, CollectionTime, LotID, RecipeName 
			from #TempB
			order by StationName, CollectionTime

	open CursorTencor
			fetch next from CursorTencor into @ID, @StationName, @CollectionTime, @LotID, @RecipeName
			while @@fetch_status = 0 
				begin
				    -- delete duplicate
					if @First='N' and @StationNameTemp=@StationName and @CollectionTimeTemp=@CollectionTime
						delete from #TempA where ID=@ID
					else
						begin
							If @First='Y' set @First='N'
		     				--particle size1
							set @ParticleSize1=null
							select top 1 @ParticleSize1=cast(DisplayName as numeric(5,4))*1000 
								from [EDC].[dbo].[EDC_Map_Recipe]
								where StationName=@StationName
								and Recipe=@RecipeName
								and BeginTime<=@CollectionTime
								and Seq=110
								order by BeginTime desc
		     				--particle size1
							set @ParticleSize2=null
							select top 1 @ParticleSize2=cast(DisplayName as numeric(5,4))*1000 
								from [EDC].[dbo].[EDC_Map_Recipe]
								where StationName=@StationName
								and Recipe=@RecipeName
								and BeginTime<=@CollectionTime
								and Seq=120
								order by BeginTime desc
			--select @Text =cast(@ParticleSize as varchar(10))
			--exec [master].[dbo].[SpMySyslog] '1', @Text

							update #TempB
								set ParticleSize1=@ParticleSize1
								     ,ParticleSize2=@ParticleSize2
									 ,Process=@Process
									 ,ProcessThickness=@ProcessThickness
									 ,PolishShift=@PolishShift
									 ,Polisher=@Polisher
									 ,PolishNo=@PolishNo
									 ,PreCleaner=@PreCleaner
									 ,PreCleanNo=@PreCleanNo
									 ,PreCleanSide=@PreCleanSide
									 ,FinalCleaner=@FinalCleaner
									 ,FinalCleanNo=@FinalCleanNo
									 ,FinalCleanSide=@FinalCleanSide
									 ,FinalCleaner2=@FinalCleaner2
									 ,FinalCleanNo2=@FinalCleanNo2
									 ,FinalCleanSide2=@FinalCleanSide2
								 where StationName=@StationName 
									and CollectionTime=@CollectionTime
									--and LotID=@@LotID
							end

					fetch next from CursorTencor into @ID, @StationName, @CollectionTime, @LotID, @RecipeName
				end
	close CursorTencor
	deallocate CursorTencor

	--Begin Transaction	
/*
	delete from [WarInfo].[dbo].[EDA_TencorLog]
			where CollectionTime between @DateBegin and @DateEnd
			and LotID like '5-________-__________-[1-9]_________-__'
*/

--select * from ##TempB
	 insert into [WarInfo].[dbo].[EDA_TencorLog]
		select [StationName]
		          ,[MFGDate]
				  ,[CollectionTime]
				  ,[LotID]
				  ,[WaferGrade]
				  ,[WaferGradeOriginal]
				  ,[RecipeName]
				  ,[KlarfName]
				  ,[Product]
				  ,[Result]
				  ,[HazeAverage]
				  ,[ParticleCount1]
				  ,[ParticleCount2]
				  ,[AreaCount]
				  ,[TotalArea]
				  ,[ScratchCount]
				  ,[ScratchLength]
				  ,[RPW350_LotID]
				  ,[T7ID]
				  ,[ThicknessCenter]
				  ,[TTV]
				  ,[Bow]
				  ,[Warp]
				  ,[Resistivity]
				  ,[PNtype]
				  ,[Class]
				  ,[VariationLastPolishThicknessCenter]
				  ,[VariationLastPolishTTV]
				  ,[VariationLastPolishWarp]
				  ,[VariationThicknessCenter]
				  ,[VariationTTV]
				  ,[VariationWarp]
				  ,[ParticleSize1]
				  ,[ParticleSize2]
				  ,[Process]
				  ,[ProcessThickness]
				  ,[PolishShift]
				  ,[Polisher]
				  ,[PolishNo]
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 1, 8)   -- Fine Recipe
             	  ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 17, 8) -- Rough Recipe
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 10, 6) -- Fine PAD used time
	              ,null	--substring([WarInfo].[dbo].[DefectPro_PolisherInfo](CollectionTime, cast(Polisher as varchar), PolishNo), 26, 6) -- Rough PAD used time
				  ,[PreCleaner]
				  ,[PreCleanNo]
				  ,[PreCleanSide]
				  ,[FinalCleaner]
				  ,[FinalCleanNo]
				  ,[FinalCleanSide]
				  ,[FinalCleaner2]
				  ,[FinalCleanNo2]
				  ,[FinalCleanSide2]
			from #TempB

	Drop Table #TempB



	--Commit Transaction

	select @Text = 'Elsape=' + Cast(DateDiff(second, @SpendTime, GeTDate()) As Varchar) + ' Seconds => Execute Stored Procedure(SP_Insert_EDA_TENCOR_LOG)'
	exec [master].[dbo].[SpMySyslog] '6', @Text


END














GO


