USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

--  報表36-DataSet_300mm555Loss 
--  與報表 41(815Loss), 46(700Loss), 51(680Loss) 相似

select 'Line'='Non-Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=680
and (a.MANU_FROM_LOTNO like '____[EGJKFMNPX]%' or a.MANU_FROM_LOTNO like '6___X%')
and a.MANU_FROM_LOTNO not like '9V__E%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)

union all
select 'Line'='Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=680
and (a.MANU_FROM_LOTNO like '____[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and a.MANU_FROM_LOTNO not like '6___X%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)


GO

/*
執行時間為:20230721 13:56
產生結果如下 
Line	    LotNo	DESCRIPTION	       Qty
-----------------------------------------
Non-Copper	2Y_E	Chip(缺角)	        2
Non-Copper	95_M	Chip(缺角)	        3
Non-Copper	21_J	DPNG(背拋不全)	    1
Non-Copper	2Y_E	DPNG(背拋不全)	    7
Non-Copper	95_M	DPNG(背拋不全)	    1
Non-Copper	2A_E	PNG(正拋不全)	    11
Non-Copper	2Y_E	PNG(正拋不全)	    2
Non-Copper	2A_E	正面Scratch(刮傷)	1
Non-Copper	2Y_E	正面Scratch(刮傷)	1
Non-Copper	95_M	正面Scratch(刮傷)	2
Non-Copper	2Y_E	背面Film(薄膜殘存)	4
Non-Copper	95_M	背面Film(薄膜殘存)	1
Non-Copper	2Y_E	背面Scratch(刮傷)	3
Copper	    24_U	Broken(破片)	    2
Copper	    2U_S	Broken(破片)	    1
Copper	    24_U	Chip(缺角)	        5
Copper	    26_C	Chip(缺角)	        1
Copper	    2U_S	Chip(缺角)	        3
Copper	    52_C	Chip(缺角)	        1
Copper	    6A_C	Chip(缺角)	        1
Copper	    26_C	PNG(正拋不全)	    1
Copper	    2U_S	PNG(正拋不全)	    2
Copper	    52_C	PNG(正拋不全)	    2
Copper	    26_C	正面Film(薄膜殘存)	2
Copper	    24_U	正面Scratch(刮傷)	1
Copper	    26_C	正面邊緣高低差	    2
Copper	    2U_S	正面邊緣高低差	    1
Copper	    26_C	背面PIT(小白點)	    1
Copper	    2U_S	背面PIT(小白點)	    2
Copper	    26_C	背面Scratch(刮傷)	3
Copper	    2U_S	背面Scratch(刮傷)	2
Copper	    24_U	背面Stain(污跡)	    1
Copper	    26_C	背面Stain(污跡)	    2
Copper	    52_C	背面Stain(污跡)	    6
*/