select

declare @StartTime datetime
declare @EndTime datetime
declare @StartTime2 datetime
declare @EndTime2 datetime
        --SELECT convert(varchar, getdate(), 111) - yyyy/mm/dd
set @StartTime=cast(convert(char(10), getdate(), 111)+' 07:20:00' as datetime)
set @EndTime=cast(convert(char(10), getdate()+1, 111)+' 07:19:59' as datetime)
exec [WarInfo].[dbo].[SP_Insert_EDA_TencorLog] @StartTime, @EndTime


set @StartTime2=[dbo].[RealDateToMfgDate](getdate())
set @EndTime2=[dbo].[RealDateToMfgDate](getdate())
exec [WarInfo].[dbo].[Sp_Insert_BI_300mm_Output_Daily] @StartTime2, @EndTime2
