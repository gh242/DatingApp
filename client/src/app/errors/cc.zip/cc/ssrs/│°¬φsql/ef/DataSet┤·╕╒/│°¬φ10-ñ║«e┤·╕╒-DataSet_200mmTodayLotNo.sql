USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230718';

-- select *
-- from SSRS_Output_200mm_LotNo with(nolock)
-- where MFGDate=@YYYYMMDD
/*
Category	MFGDate	                MFGShift	Customer	PsiPN	              CustomerPN	LotNo	  Qty
-------------------------------------------------------------------------------------------------
Outside	  2023-07-18 00:00:00.000	D	        VIC	       3WSVIC8RELKE001   	N/A	        VIN6I3	175
Outside	  2023-07-18 00:00:00.000	D	        TSC	       3WSTSC8RELKX001   	V450002	    T8N6K1	23
Outside	  2023-07-18 00:00:00.000	D	        VIC	       3WSVIC8RELKE001   	N/A	        VIMAE1	100
Outside	  2023-07-18 00:00:00.000	D	        UMC	       3WSUMC8RELKU001   	W0823000P	  UMN5U1	100
Outside	  2023-07-18 00:00:00.000	D	        TSC	       3WSTSC8RELKX001   	V460002	    T6N5I1	450
Outside	  2023-07-18 00:00:00.000	D	        TSC	       3WSTSC8RELKX001   	V450001	    T6N5V1	100
*/


select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
      ,'Qty'=sum(Qty)
from SSRS_Output_200mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)

/*
產生結果如下  20230718 執行時間，為20230718 15:15
LotNo	Qty
----------
VI_I	175
UM_U	100
T8_K	23
T6_V	100
T6_I	450
VI_E	100
*/

union all
select 'LotNo'=substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)
      ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_200mm].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_LOTNO not like '[A-Z]___[QWV]%'
and MFG_LOTNO not like 'P[BC]__S_%'
and MFG_MOVE>0
group by substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)

/*
產生結果如下  20230718 執行時間，為20230718 15:17
LotNo	Qty
----------

*/


GO

/*
產生結果如下  20230718 執行時間，為20230718 15:13
LotNo	Qty
----------
UM_U	100
T8_K	23
VI_I	175
T6_I	450
VI_E	100
T6_V	100
*/