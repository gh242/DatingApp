USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';

select 'LotNo'=substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)
          ,'Qty'=sum(Qty)
from SSRS_Output_200mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
group by substring(LotNo, 1, 2)+'_'+substring(LotNo, 5, 1)

union all
select 'LotNo'=substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)
          ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_200mm].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_LOTNO not like '[A-Z]___[QWV]%'
and MFG_LOTNO not like 'P[BC]__S_%'
and MFG_MOVE>0
group by substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)

GO

/*
產生結果如下  20230718 執行時間，為20230718 15:13
LotNo	Qty
-----------
UM_U	100
T8_K	23
VI_I	175
T6_I	450
VI_E	100
T6_V	100
*/