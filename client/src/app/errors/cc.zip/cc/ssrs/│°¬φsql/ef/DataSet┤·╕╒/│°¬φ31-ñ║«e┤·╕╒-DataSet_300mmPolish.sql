USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Polish FLOAT;
SET @Polish = 0.935;

--報表31-內容測試-DataSet_300mmPolish
--與報表32很像

with TempA as (
select 'Print_Date'=case when cast(left(MANU_REALDATE, 4)
                           +'-'+substring(MANU_REALDATE, 5, 2)
                           +'-'+right(MANU_REALDATE, 2)
                           +' '+left(MANU_ENDTIME, 2)
                           +':'+substring(MANU_ENDTIME, 3, 2)
                           +':'+right(MANU_ENDTIME, 2) as DateTime)
                           >=DateAdd(mi, 1880, @YYYYMMDD) -- 加31小時20分
                         then DateAdd(mi, 1879, @YYYYMMDD)
                    else cast(left(MANU_REALDATE, 4)
                           +'-'+substring(MANU_REALDATE, 5, 2)
                           +'-'+right(MANU_REALDATE, 2)
                           +' '+left(MANU_ENDTIME, 2)
                           +':'+substring(MANU_ENDTIME, 3, 2)
                           +':'+right(MANU_ENDTIME, 2) as DateTime)
                    end
          ,'Line'='Non-Copper'
          ,'Qty'=MANU_QTY
-- select *
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
--and (MANU_FROM_EQUID=662 or MANU_FROM_EQUID=663)
and MANU_FROM_EQUID=660
and Not (MANU_FROM_LOTNO like '2___[BCDLUHIYS]%' or
         MANU_FROM_LOTNO like 'PS__M%-[125678ABCDEFH]%' or
         MANU_FROM_LOTNO like '4___%' or
         MANU_FROM_LOTNO like '5___C%' or
         MANU_FROM_LOTNO like '6___[BC]%' or
         MANU_FROM_LOTNO like '7___C%' or
         MANU_FROM_LOTNO like '9___%')
and MANU_FMLB='M'
and MANU_QTY>0

/*
執行時間為:20230720 15:09
產生結果如下 
Print_Date	            Line	      Qty
--------------------------------------
2023-07-11 07:36:35.000	Non-Copper	12
2023-07-11 07:40:13.000	Non-Copper	12
2023-07-11 07:41:27.000	Non-Copper	12
2023-07-11 07:44:31.000	Non-Copper	12
2023-07-11 07:45:05.000	Non-Copper	12
2023-07-11 07:49:17.000	Non-Copper	12
2023-07-11 07:50:25.000	Non-Copper	12
2023-07-11 07:49:39.000	Non-Copper	10
2023-07-11 07:50:22.000	Non-Copper	12
2023-07-11 07:53:59.000	Non-Copper	12
2023-07-11 07:50:54.000	Non-Copper	12
2023-07-11 07:54:36.000	Non-Copper	12
2023-07-11 07:51:10.000	Non-Copper	12
2023-07-11 07:54:06.000	Non-Copper	12
2023-07-11 07:59:27.000	Non-Copper	12
2023-07-11 08:03:13.000	Non-Copper	12
2023-07-11 08:08:47.000	Non-Copper	4
2023-07-11 08:09:09.000	Non-Copper	8
2023-07-11 08:08:10.000	Non-Copper	9
2023-07-11 08:08:26.000	Non-Copper	3
2023-07-11 08:09:43.000	Non-Copper	9
2023-07-11 08:09:56.000	Non-Copper	3
2023-07-11 08:12:47.000	Non-Copper	12
2023-07-11 08:17:56.000	Non-Copper	12
2023-07-11 08:19:06.000	Non-Copper	12
...
*/

union all
select 'Print_Date'=case when cast(left(MANU_REALDATE, 4)
                                +'-'+substring(MANU_REALDATE, 5, 2)
                                +'-'+right(MANU_REALDATE, 2)
                                +' '+left(MANU_ENDTIME, 2)
                                +':'+substring(MANU_ENDTIME, 3, 2)
                                +':'+right(MANU_ENDTIME, 2) as DateTime)>=DateAdd(mi, 1880, @YYYYMMDD) then DateAdd(mi, 1879, @YYYYMMDD)
                         else cast(left(MANU_REALDATE, 4)
                                +'-'+substring(MANU_REALDATE, 5, 2)
                                +'-'+right(MANU_REALDATE, 2)
                                +' '+left(MANU_ENDTIME, 2)
                                +':'+substring(MANU_ENDTIME, 3, 2)
                                +':'+right(MANU_ENDTIME, 2) as DateTime)
                     end
          ,'Line'='Copper'
          ,'Qty'=MANU_QTY
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
--and (MANU_FROM_EQUID=662 or MANU_FROM_EQUID=663)
and MANU_FROM_EQUID=660
and (MANU_FROM_LOTNO like '2___[BCDLUHIYS]%' or 
         MANU_FROM_LOTNO like 'PS__M%-[125678ABCDEFH]%' or
         MANU_FROM_LOTNO like '4___%' or
         MANU_FROM_LOTNO like '5___C%' or
         MANU_FROM_LOTNO like '6___[BC]%' or
         MANU_FROM_LOTNO like '7___C%' or
         MANU_FROM_LOTNO like '9___%')
and MANU_FMLB='M'
and MANU_QTY>0
/*
執行時間為:20230720 15:35
產生結果如下
select TOP(20) 
Print_Date	               Line	   Qty
---------------------------------------
2023-07-11 07:36:39.000	   Copper	12
2023-07-11 07:35:52.000	   Copper	12
2023-07-11 07:55:50.000	   Copper	12
2023-07-11 08:00:54.000	   Copper	12
2023-07-11 08:01:05.000	   Copper	12
2023-07-11 08:01:27.000	   Copper	12
2023-07-11 08:04:40.000	   Copper	12
2023-07-11 08:05:10.000	   Copper	12
2023-07-11 08:05:20.000	   Copper	12
2023-07-11 08:16:34.000	   Copper	12
2023-07-11 08:16:46.000	   Copper	12
2023-07-11 08:17:02.000	   Copper	12
2023-07-11 08:17:43.000	   Copper	12
2023-07-11 08:17:54.000	   Copper	12
2023-07-11 08:18:02.000	   Copper	12
2023-07-11 08:19:10.000	   Copper	12
2023-07-11 08:19:17.000	   Copper	12
2023-07-11 08:19:46.000	   Copper	12
2023-07-11 08:19:57.000	   Copper	12
2023-07-11 08:21:22.000	   Copper	12
*/

/*
union all
select 'Print_Date'=case when cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)>=DateAdd(mi, 1880, @YYYYMMDD) then DateAdd(mi, 1879, @YYYYMMDD)
                                          else cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)
                                          end
          ,'Line'='1B(Non-Copper)'
          ,'Qty'=MANU_QTY
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
--and (MANU_FROM_EQUID=662 or MANU_FROM_EQUID=663)
and MANU_FROM_EQUID=660
and (MANU_FROM_LOTNO like '[1-9]___[23456789EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%' or MANU_FROM_LOTNO like 'PS__M%-_[123459DEGIJKLMN]%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO like '%-%-[345]%'
and MANU_FMLB='M'
and MANU_QTY>0

union all
select 'Print_Date'=case when cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)>=DateAdd(mi, 1880, @YYYYMMDD) then DateAdd(mi, 1879, @YYYYMMDD)
                                          else cast(left(MANU_REALDATE, 4)+'-'+substring(MANU_REALDATE, 5, 2)+'-'+right(MANU_REALDATE, 2)+' '+left(MANU_ENDTIME, 2)+':'+substring(MANU_ENDTIME, 3, 2)+':'+right(MANU_ENDTIME, 2) as DateTime)
                                          end
          ,'Line'='1B(Copper)'
          ,'Qty'=MANU_QTY
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
--and (MANU_FROM_EQUID=662 or MANU_FROM_EQUID=663)
and MANU_FROM_EQUID=660
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%' or MANU_FROM_LOTNO like 'PS__M%-_[678ABCFH]%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO like '%-%-[345]%'
and MANU_FMLB='M'
and MANU_QTY>0
*/
)


select x.Interval
         ,x.Line
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,x.TargetQty
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD) -- 20230711 09:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'TargetQty'=@TargetOutput300mm/12/@Polish
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD)
            )
group by a.Line

union all
select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD)  -- 20230711 11:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=2*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) -- 20230711 13:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=3*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD)  -- 20230711 15:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=4*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) -- 20230711 17:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=5*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) -- 20230711 19:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=6*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) -- 20230711 21:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=7*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) -- 20230711 23:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=8*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) -- 20230712 01:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=9*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) -- 20230712 03:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=10*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) -- 20230712 05:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=11*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) -- 20230712 07:20:00
          ,a.Line
          ,'Qty'=sum(a.Qty)
         ,'TargetQty'=12*@TargetOutput300mm/12/@Polish
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
group by a.Line
) x


GO

/*
執行時間為:20230720 15:45
產生結果如下
Interval	            Line	    Qty	    TargetQty
------------------------------------------------------------
2023-07-11 09:20:00	    Copper	    552	    1140.10695187166
2023-07-11 09:20:00	    Non-Copper	378	    1140.10695187166
2023-07-11 11:20:00	    Copper	    1224	2281.28342245989
2023-07-11 11:20:00	    Non-Copper	474	    2281.28342245989
2023-07-11 13:20:00	    Copper	    1827	3422.45989304813
2023-07-11 13:20:00	    Non-Copper	488	    3422.45989304813
2023-07-11 15:20:00	    Copper	    2510	4562.56684491979
2023-07-11 15:20:00	    Non-Copper	596	    4562.56684491979
2023-07-11 17:20:00	    Copper	    3154	5703.74331550802
2023-07-11 17:20:00	    Non-Copper	847	    5703.74331550802
2023-07-11 19:20:00	    Copper	    3860	6844.91978609626
2023-07-11 19:20:00	    Non-Copper	1295	6844.91978609626
2023-07-11 21:20:00	    Copper	    4977	7985.02673796791
2023-07-11 21:20:00	    Non-Copper	1813	7985.02673796791
2023-07-11 23:20:00	    Copper	    5793	9126.20320855615
2023-07-11 23:20:00	    Non-Copper	2033	9126.20320855615
2023-07-12 01:20:00	    Copper	    6393	10267.3796791444
2023-07-12 01:20:00	    Non-Copper	2253	10267.3796791444
2023-07-12 03:20:00	    Copper	    7281	11407.486631016
2023-07-12 03:20:00	    Non-Copper	2731	11407.486631016
2023-07-12 05:20:00	    Copper	    8145	12548.6631016043
2023-07-12 05:20:00	    Non-Copper	2971	12548.6631016043
2023-07-12 07:20:00	    Copper	    8619	13689.8395721925
2023-07-12 07:20:00	    Non-Copper	3095	13689.8395721925
*/