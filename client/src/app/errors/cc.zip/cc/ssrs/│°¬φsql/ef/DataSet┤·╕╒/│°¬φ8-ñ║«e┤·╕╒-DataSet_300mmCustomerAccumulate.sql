USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230718';

/*
select * from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate=@YYYYMMDD
*/
/*
產生結果如下  20230718 執行時間，為20230718 14:26
26筆
Category	MFGDate	                    MFGShift	Customer	PsiPN	          CustomerPN	LotNo	Qty
------------------------------------------------------------------------------------------------------------
Outside	    2023-07-18  00:00:00.000	D	        INM	        3WSINMCRELKC002   180-ECR78	    52N1C1	75
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003A	    26N7C1	375
Outside	    2023-07-18  00:00:00.000	D	        PSC	        3WSPSCCRELKC001   02-14-0016	6AN7C1	25
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650021Q	    22N741	175
Outside	    2023-07-18  00:00:00.000	D	        INM	        3WSINMCRELKC002   180-ECLR8	    52N1C1	250
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V65000311D	24N7U1	50
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V65000313C	24N7U1	100
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V65000013A	26N7R1	225
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650006F	    26N7C1	125
Outside	    2023-07-18  00:00:00.000	D	        PSC	        3WSPSCCRELKC001   02-14-0021	6AN7C1	175
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650004A	    26N7J1	275
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650006F	    26N7R1	100
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V65000311DD	24N7U1	250
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003P	    2HN7C1	200
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650006D	    26N7C1	225
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650006F	    2HN7C1	50
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650021A	    22N741	25
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650021P	    22N741	75
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003A2	    26N7L1	50
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650004P	    26N7J1	100
Outside	    2023-07-18  00:00:00.000	D	        PSC	        3WSPSCCRELKC001   02-14-0018	6AN7C1	100
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003P	    26N7C1	25
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650007F	    26N7J1	150
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650006D	    2HN7C1	50
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003A	    2HN7C1	125
Outside	    2023-07-18  00:00:00.000	D	        TSC	        3WSTSCCRELKX001   V650003A1	    26N7C1	50
*/



select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                    else substring(LotNo, 1, 1)
               end
          ,'HighT'=sum(Qty)
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN like 'V65%[T]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
/*
產生結果如下  20230718 執行時間，為20230718 14:51
LotNo	HighT	HighQ	HighP	Normal	Low
-------------------------------------------
2	    275	    0	    0	    0	    0
*/

union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                    else substring(LotNo, 1, 1)
               end
          ,'HighT'=0
          ,'HighQ'=sum(Qty)
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN like 'V65%[Q]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
              else substring(LotNo, 1, 1)
         end

/*
產生結果如下  20230718 執行時間，為20230718 14:52
LotNo	HighT	HighQ	HighP	Normal	Low
-------------------------------------------
2	    0	    5475	0	    0	    0
*/

union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                    else substring(LotNo, 1, 1)
               end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=sum(Qty)
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and ( CustomerPN like 'V65%P' or
          CustomerPN like 'V65%P2' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-ECLR8' or 
          CustomerPN='180-ECLT8' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-EALX8' or
          CustomerPN='180-ELR18' or
          CustomerPN='180-ELT08' 
        )
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
              else substring(LotNo, 1, 1)
         end

/*
產生結果如下  20230718 執行時間，為20230718 14:53
LotNo	HighT	HighQ	HighP	Normal	Low
-------------------------------------------
5	    0	    0	    3050	0	    0
2	    0	    0	    20875	0	    0
*/


union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                    else substring(LotNo, 1, 1)
               end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=sum(Qty)
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN not like 'V65%[PQT]'
and CustomerPN not like 'V65%P2'
and CustomerPN not like 'V650000[DF]%'
and CustomerPN not like 'V65000[67][DF]%'
and CustomerPN not like 'V6500[12][12][DF]%'
and CustomerPN<>'V65000013D'
and CustomerPN<>'V600001F'
and CustomerPN not like '02-14-0018'
and CustomerPN not like '02-14-002[1568]'
and CustomerPN not like '02-14-003[034]'
--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
and CustomerPN<>'180-ECLX8'     
and CustomerPN<>'180-ECLR8'
and CustomerPN<>'180-ECDR8'
and CustomerPN<>'180-ECDT8'
and CustomerPN<>'180-ECLT8'
and CustomerPN<>'180-ECLX8'
and CustomerPN<>'180-EALX8'
and CustomerPN<>'180-EDR38'
and CustomerPN<>'180-EDT38'
and CustomerPN<>'180-ELR18'
and CustomerPN<>'180-ELT08' 
and LotNo not like 'PSD2MZ_F[TX]%]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
              else substring(LotNo, 1, 1)
         end
/*
產生結果如下  20230718 執行時間，為20230718 14:53
LotNo	HighT	HighQ	HighP	Normal	Low
-------------------------------------------
7	    0	    0	    0	    275	    0
9K	    0	    0	    0	    325	    0
P	    0	    0	    0	    25	    0
5	    0	    0	    0	    625	    0
95	    0	    0	    0	    1150	0
9V	    0	    0	    0	    150	    0
6	    0	    0	    0	    1525	0
9L	    0	    0	    0	    250	    0
2	    0	    0	    0	    122250	0
*/
union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                    else substring(LotNo, 1, 1)
               end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=sum(Qty)
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and ( CustomerPN like 'V650000[DF]%' or
         CustomerPN like 'V65000[67][DF]%' or 
        CustomerPN like 'V6500[12][12][DF]%' or
        CustomerPN='V65000013D' or
        CustomerPN='V600001F' or
         CustomerPN like '02-14-0018' or 
         CustomerPN like '02-14-002[1568]' or 
         CustomerPN like '02-14-003[034]' or
         CustomerPN='180-ECDR8' or
         CustomerPN='180-EDR38' or
         CustomerPN='180-EDT38' or
         LotNo like 'PSD2MZ_F[TX]%]')
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
              else substring(LotNo, 1, 1)
         end

/*
產生結果如下  20230718 執行時間，為20230718 14:58
LotNo	HighT	HighQ	HighP	Normal	Low
----------------------------------------------
6	    0	    0	    0	    0	    2800
5	    0	    0	    0	    0	    725
2	    0	    0	    0	    0	    62675
*/

union all
select 'LotNo'=case when MFG_LOTNO like '9%' then substring(MFG_LOTNO , 1, 2)
                    else substring(MFG_LOTNO , 1, 1)
               end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=-1*sum(MFG_MOVE)
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between left(convert(char(8), @YYYYMMDD, 112), 6)+'01'  and convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0
group by case when MFG_LOTNO like '9%' then substring(MFG_LOTNO , 1, 2)
              else substring(MFG_LOTNO , 1, 1)
         end

/*
產生結果如下  20230718 執行時間，為20230718 14:59
LotNo	HighT	HighQ	HighP	Normal	Low
----------------------------------------------
2	    0	    0	    0	    -3898	0
5	    0	    0	    0	    -2818	0
*/

GO


/*
產生結果如下  20230718 執行時間，為20230718 14:49
LotNo	HighT	HighQ	HighP	Normal	Low
--------------------------------------------
2	    275	    0	    0	    0	    0
2	    0	    2075	0	    0	    0
2	    0	    0	    3750	0	    0
5	    0	    0	    275	    0	    0
95	    0	    0	    0	    250	    0
6	    0	    0	    0	    125	    0
2	    0	    0	    0	    32800	0
5	    0	    0	    0	    0	    25
2	    0	    0	    0	    0	    13300
6	    0	    0	    0	    0	    300
2	    0	    0	    0	    -750	0
*/