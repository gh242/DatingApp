USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;
DECLARE @DailyNo int;
SET @DailyNo = 12;
DECLARE @Mode VARCHAR(5);
SET @Mode = 'All';


with TempB as (
select 'MFGDate' = dbo.RealDateToMfgDate(MFG_Date)
         , 'CustomerPN' = FG_Customer
         , 'Qty'=sum(Qty)
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date between case when day(@YYYYMMDD)=1 then Dateadd(m, -1,@YYYYMMDD)
                                                       else @YYYYMMDD-day(@YYYYMMDD)+1
                                                       end
                               and @YYYYMMDD-1
and LotNo like case when @Mode='R' then '____[A-LO-Z]%'
                                  when @Mode='T' then '____[MN]%'
                                               else '%'
                                               end
and FG_Customer like case when @Mode='Y' then 'V%'
                                               else '%'
                                               end
and FG_Customer not like case when @Mode='N' then 'V%'
                                                      else ''
                                                      end
group by dbo.RealDateToMfgDate(MFG_Date), FG_Customer
),


TempC as (
select x.RN
         , x.KDMAT
         , x.SalePrice
from (
   select 'RN'=row_number() over (partition by 
                          case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                                  when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                   else KDMAT
                                   end 
                                                          order by AUDAT desc)
              ,'KDMAT'=case when KDMAT like '199900000000018%(G)%' then '199900000000018(G)'
                                        when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                       else KDMAT
                                       end 
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                        else NETPR*KURSK
                                        end
   from sap_sd_so_v
   where NETPR>0
   and VKORG='1100'
   ) x
where x.RN=1)


select b.MFGDate
          ,b.CustomerPN
          ,b.Qty
         ,'SalePrice'=isnull(c.SalePrice, 300)
         ,'Revenue'=b.Qty*isnull(c.SalePrice, 300)
         , 'Grade'=case when isnull(c.SalePrice, 300)<350 then 'Low'
                                   when isnull(c.SalePrice, 300)>=350 and isnull(c.SalePrice, 300)<450 then 'Normal'
                                   when isnull(c.SalePrice, 300)>=450 and isnull(c.SalePrice, 300)<550 then 'P'
                                   when isnull(c.SalePrice, 300)>=550 and isnull(c.SalePrice, 300)<650 then 'Q'
                                   when isnull(c.SalePrice, 300)>=650 and isnull(c.SalePrice, 300)<850 then 'T'
                                   when isnull(c.SalePrice, 300)>=850 and isnull(c.SalePrice, 300)<1000 then 'U'
                                   when isnull(c.SalePrice, 300)>=1000  then 'Test'
                                   else 'Others'
                                   end
from TempB b left join TempC c
on b.CustomerPN = c.KDMAT Collate Chinese_Taiwan_Stroke_CI_AS

GO