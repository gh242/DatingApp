USE [EDC]
GO

/****** Object:  View [dbo].[View_PackingImageFN]    Script Date: 2023/7/24 下午 02:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO



ALTER view [dbo].[View_PackingImageFN](
	Barcode,
	ImageNo
) As 
	Select Barcode, Count(*) From PackingImage With(Nolock)
		Group By Barcode

GO
