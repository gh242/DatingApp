--DECLARE
    --stime DATE :=Cdate(Format(DateAdd("d", -1, today()), "yyyy-MM") & "-01 07:20:00");
    --stime DATE :=(to_char(SYSDATE-1,'yyyy-mm')||'-01 07:20:00'); -- 2023-07-01 07:20:00
     
    --stime VARCHAR2( 100 ) := '2023-07-01 07:20:00';
    --stime DATE  : = to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss');
    --stime DATE := sysdate;
    
--BEGIN

with
t1 as (select * from EQPGROUP_MFG
/*
產生結果如下  20230718 執行時間，為20230718 10:45
SEQUENCE, EQUIPMENTNO,  STATION,      EQUIPMENTNAME,  EEGROUP
-----------------------------------------------------------
1	      SPAW50-1	    12" Polish	  S50-1	         SPAW50
2	      SPAW50-2	    12" Polish	  S50-2	         SPAW50
3	      SPAW50-3	    12" Polish	  S50-3	         SPAW50
4	      SPAW50-4	    12" Polish	  S50-4	         SPAW50
5	      SPAW50-5	    12" Polish	  S50-5	         SPAW50
6	      SPAW50-6	    12" Polish	  S50-6	         SPAW50
*/
),

t2 as (select * from TBLEMSEQUIPMENTSTATE where EQUIPMENTSTATE not in ('1','21','22','23','31')
/*
產生結果如下  20230718 執行時間，為20230718 10:50
EQPSERIALNO,  EQUIPMENTNO,      EQUIPMENTSTATE, EQUIPMENTTYPE,      STARTTIME,      USERNO,   DESCRIPTION,                                      LOTSERIAL
--------------------------------------------------------------------------------------------------------------------------------------------
S23070003649	PRE_CLEAN-2	    5	              CLEAN	            18-7月 -23	    4759	  (1)CLEAN-18 : 借機 EQP State Change by User:4759	
S23050004519	12H2SO4-CU	    3	              ETCH	            22-5月 -23	    1063	  ADE7200-16 : 借機	
S23070003507	EP300	        0	              LAPPING	        17-7月 -23	    1063	  EP300-04 : 機台已復歸	
S23070002889	LAPPING_CLEAN	0	              LAPPING	        14-7月 -23	    0308	  EQP State Change by User:0308	
S23070002890	LAPPING_DRYER	0	              LAPPING	        14-7月 -23	    0308	  EQP State Change by User:0308	
S23070002891	LAPPING_EQP	    0	              LAPPING	        14-7月 -23	    0308	  EQP State Change by User:0308	
S23070003496	ADE9300	        2	              MEASUREMENT	    17-7月 -23	    4759	  ADE7200-01 : 機台當機	
S23030004333	MX301	        0	              MEASUREMENT	    19-3月 -23	    4668	  EQP State Change by User:4668	
S23070003640	RPW3083	        30	              MEASUREMENT	    18-7月 -23	    1004	  EQP State Change by User:1004	
*/
),

t3 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, 0 as RN from
    (
        select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, rank() over(partition by EQUIPMENTNO order by STARTTIME, EQPSERIALNO) as RN from TBLEMSEQUIPMENTSTATELOG
        where STARTTIME <= sysdate-1 and ENDTIME > sysdate-1 
/*
執行時間為:20230720 11:07
產生結果如下 
EQUIPMENTNO         EQUIPMENTSTATE STARTTIME    RN
---------------------------------------------------
12GD-1	            1	            26-6月 -23	1
ADE7200	            1	            19-7月 -23	1
BOX_CLEAN-6	        1	            09-7月 -23	1
EBARA-1L	        1	            17-7月 -23	1
EBARA-1R	        1	            18-7月 -23	1
EBARA-2L	        1	            19-7月 -23	1
EBARA-2R	        1	            18-7月 -23	1
EH202	            1	            19-7月 -23	1
EH204-1	            1	            08-7月 -23	1
EP300	            0	            17-7月 -23	1
FINAL_CLEAN-3	    5	            19-7月 -23	1
GD-2	            5	            19-7月 -23	1
GOLD_FINGER-1	    1	            19-7月 -23	1
GOLD_FINGER-1-C1	1	            19-7月 -23	1
OASIS	            1	            18-7月 -23	1
OASIS-T2	        1	            17-6月 -23	1
RPW3080-1	        0	            19-7月 -23	1
RPW3080-5	        0	            19-7月 -23	1
RPW3080-7	        0	            19-7月 -23	1
RPW3083	            1	            19-7月 -23	1
SCRUBBER-1	        1	            19-7月 -23	1
SCRUBBER-2	        1	            19-7月 -23	1
SP1	                2	            18-7月 -23	1
SPAW50-10	        1	            15-7月 -23	1
SPAW50-11	        1	            18-7月 -23	1
SPAW50-13	        1	            19-7月 -23	1
SPAW50-18	        1	            18-7月 -23	1
SPAW50-2	        1	            18-7月 -23	1
SPAW50-20	        1	            17-7月 -23	1
SPAW50-21	        1	            18-7月 -23	1
SPAW50-22	        1	            17-7月 -23	1
SPAW50-23	        1	            18-7月 -23	1
SPAW50-25	        1	            17-7月 -23	1
SPAW50-26	        1	            16-7月 -23	1
SPAW50-29	        1	            15-7月 -23	1
SPAW50-3	        1	            19-7月 -23	1
SPAW50-30	        1	            16-7月 -23	1
SPAW50-31	        1	            17-7月 -23	1
SPAW50-32	        13	            19-7月 -23	1
SPAW50-5	        1	            19-7月 -23	1
SPAW50-6	        1	            18-7月 -23	1
SPAW50-8	        24	            19-7月 -23	1
SPAW59-1	        1	            18-7月 -23	1
SPAW59-2	        3	            19-7月 -23	1
TSK-11	            1	            15-7月 -23	1
TSK-13	            1	            17-7月 -23	1
TSK-14	            3	            18-7月 -23	1
TSK-15	            3	            18-7月 -23	1
TSK-16	            1	            19-7月 -23	1
*/

    ) a
    where a.RN=1
    union 
    select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, 0 as RN from TBLEMSEQUIPMENTSTATE 
         where STARTTIME < sysdate-1 
    union    
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, rank() over(partition by a.EQUIPMENTNO order by a.STARTTIME, a.EQPSERIALNO) as RN from
    (
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATELOG
        union
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATE
    ) a
    where a.STARTTIME > sysdate-1 and a.STARTTIME <= sysdate
/*
產生結果如下  20230718 執行時間，為20230718 11:20
EQUIPMENTNO, EQUIPMENTSTATE,    STARTTIME, RN
---------------------------------------------
ACM CH-F	  1	                20-6月 -23	0
ACM CH-G	  1	                16-7月 -23	0
ACM CH-H	  1	                31-12月-22	0
ADE7200	      1	                16-7月 -23	0
ADE7200	      1	                17-7月 -23	4
ADE7200	      25	            17-7月 -23	1
ADE7200	      28	            17-7月 -23	3
ADE7200	      29	            17-7月 -23	2
ADE9300	      1	                17-7月 -23	2
ADE9300	      2	                17-7月 -23	0
ADE9300	      2	                17-7月 -23	4
*/

),
k4 as (select * from TBLEQPEQUIPMENTBASIS
/*
產生結果如下  20230718 執行時間，為20230718 11:29
EQUIPMENTNO, EQUIPMENTTYPE, CAPACITY, VENDORNO, MODELNO, DESCRIPTION, CREATOR, CREATEDATE, ISSUESTATE, ENGINEERGROUPNO, ASSETNO, EQUIPMENTCLASS, LOADPORT, AUTOFLAG, EACONTROLLER, EQPRECIPE, QCLISTNO
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SPAW50-1	  POLISH	        -1	      PSI		     SPAW50-1	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-2	  POLISH	        -1	      PSI		     SPAW50-2	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-3	  POLISH	        -1	      PSI		     SPAW50-3	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-4	  POLISH	        -1	      PSI		     SPAW50-4	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-5	  POLISH	        -1	      PSI		     SPAW50-5	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-6	  POLISH	        -1	      PSI		     SPAW50-6	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-7	  POLISH	        -1	      PSI		     SPAW50-7	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-8	  POLISH	        -1	      PSI		     SPAW50-8	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
TSK-4	      POLISH	        -1	      PSI		     TSK-4   	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-10	  POLISH	        -1	      PSI		     SPAW50-10	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-11	  POLISH	        -1	      PSI		     SPAW50-11	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	
SPAW50-12	  POLISH	        -1	      PSI		     SPAW50-12	  0600	    28-3月 -18	2	        E001			                          -1	   0	      N/A	       0	

*/

),

f3 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, case when a.STARTTIME < sysdate-1 then sysdate-1 else a.STARTTIME end STARTTIME, nvl(a1.STARTTIME,sysdate) ENDTIME
    from (select * from t3) a
    left join (select * from t3) a1 on a.EQUIPMENTNO=a1.EQUIPMENTNO and a.RN=a1.RN-1

/*
產生結果如下  20230718 執行時間，為20230718 11:30
EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME,   ENDTIME
----------------------------------------------------------
ADE9300	      1	              17-7月 -23	17-7月 -23
ADE9300	      2	              17-7月 -23	17-7月 -23
ADE9300	      2	              17-7月 -23	18-7月 -23
EBARA-1L	  28	          17-7月 -23	17-7月 -23
EBARA-1L	  24	          17-7月 -23	17-7月 -23
EBARA-1L	  1	              17-7月 -23	17-7月 -23
EBARA-1L	  2	              17-7月 -23	17-7月 -23
EBARA-1R	  28	          17-7月 -23	17-7月 -23
EBARA-1R	  13	          18-7月 -23	18-7月 -23
*/

),
 r3 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) YAT
from f3
where EQUIPMENTSTATE in ('0','1','21','22','23','31')
group by EQUIPMENTNO

/*
產生結果如下  20230718 執行時間，為20230718 13:01
EQUIPMENTNO,    YAT
---------------------
RPW308	        86403
RPW350-1	    86036
SP2-4	        84690
SPAW50-7	    77167
SCRUBBER-1-T2	86401
12H2SO4-2	    86401
ACM CH-H	    86401
EBARA-3R	    86401
*/

),
s3 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) YTT
from f3
group by EQUIPMENTNO
/*
產生結果如下  20230718 執行時間，為20230718 13:05
EQUIPMENTNO,    YTT
---------------------
RPW308	        86403
RPW350-1	    86405
SP2-4	        86405
SPAW50-7	    86415
SCRUBBER-1-T2	86401
12H2SO4-2	    86401
EBARA-3R	    86401
*/
)
,

t4 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, 0 as RN from
    (
        select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, rank() over(partition by EQUIPMENTNO order by STARTTIME, EQPSERIALNO) as RN from TBLEMSEQUIPMENTSTATELOG
        --where STARTTIME <= :stime and ENDTIME > :stime 
        where STARTTIME <= to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss') and ENDTIME > to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss')
    ) a
    where a.RN=1
    union 
    select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, 0 as RN from TBLEMSEQUIPMENTSTATE
        --  where STARTTIME < :stime
         where STARTTIME < to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss')
    union    
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, rank() over(partition by a.EQUIPMENTNO order by a.STARTTIME, a.EQPSERIALNO) as RN from
    (
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATELOG
        union
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATE
    ) a
    -- where a.STARTTIME > :stime and a.STARTTIME <= sysdate
    where a.STARTTIME > to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss') and a.STARTTIME <= sysdate

/*
產生結果如下  20230718 執行時間，為20230718 13:15
EQUIPMENTNO, EQUIPMENTSTATE,    STARTTIME, RN
----------------------------------------------
12DRYER	      1	                28-5月 -23	0
12DRYER-1	  1	                12-3月 -23	0
12DRYER-1	  1	                06-7月 -23	4
12DRYER-1	  1	                15-7月 -23	8
12DRYER-1	  2	                06-7月 -23	2
12DRYER-1	  2	                15-7月 -23	6
12DRYER-1	  24	            06-7月 -23	1
*/
)
,
f4 as (
    
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, case when a.STARTTIME < to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss') then to_date('2023-07-01 07:20:00','yyyy-MM-dd HH24:mi:ss') else a.STARTTIME end STARTTIME, nvl(a1.STARTTIME,sysdate) ENDTIME
    from (select * from t4) a
    left join (select * from t4) a1 on a.EQUIPMENTNO=a1.EQUIPMENTNO and a.RN=a1.RN-1

/*
產生結果如下  20230718 執行時間，為20230718 13:18
EQUIPMENTNO, EQUIPMENTSTATE,    STARTTIME,  ENDTIME
-----------------------------------------------------
12DRYER-1	 28	                06-7月 -23	06-7月 -23
12DRYER-1	 28	                15-7月 -23	15-7月 -23
12DRYER-1	 24	                06-7月 -23	06-7月 -23
12DRYER-1	 24	                15-7月 -23	15-7月 -23
12DRYER-1	 1	                01-7月 -23	06-7月 -23
12DRYER-1	 1	                06-7月 -23	15-7月 -23
12DRYER-1	 2	                06-7月 -23	06-7月 -23
12DRYER-1	 2	                15-7月 -23	15-7月 -23
12DRYER-2	 28	                07-7月 -23	07-7月 -23
*/
),
r4 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) MAT
from f4
where EQUIPMENTSTATE in ('0','1','21','22','23','31')
group by EQUIPMENTNO
/*
產生結果如下  20230718 執行時間，為20230718 13:18
EQUIPMENTNO,  MAT
------------------
12DRYER-1	  1485494
12GD-4	      1442338
ACM CH-D	  1489106
EBARA-3R	  1421297
RPW3065-2	  1487813
RPW308	      1447516
RPW350-1	  1473903
SCRUBBER-2	  1429934
SP2-4	      1445419
*/
),
s4 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) MTT
from f4
group by EQUIPMENTNO
/*
產生結果如下  20230718 執行時間，為20230718 13:36
EQUIPMENTNO,  MTT
-------------------
12DRYER-1	  1490388
12GD-4	      1490389
ACM CH-D	  1490384
EBARA-3R	  1490403
RPW3065-2	  1490384
RPW308	      1490405
RPW350-1	  1490416
*/
)

select t1.SEQUENCE, t1.EQUIPMENTNO, t1.STATION, t1.EQUIPMENTNAME,k4.DESCRIPTION, a.EQUIPMENTSTATE, b.STATENAME, t2.STARTTIME, r3.YAT, s3.YTT, r4.MAT, s4.MTT,
Case when a.EQUIPMENTSTATE in ('1','21','22','23','31') then '1'
when a.EQUIPMENTSTATE in ('0') then '0' else '2' end STATECOLOR
from TBLEMSEQUIPMENTSTATE a, TBLEQPSTATEBASIS b, t1
left join t2 on t1.EQUIPMENTNO = t2.EQUIPMENTNO
left join r3 on t1.EQUIPMENTNO = r3.EQUIPMENTNO
left join s3 on t1.EQUIPMENTNO = s3.EQUIPMENTNO
left join r4 on t1.EQUIPMENTNO = r4.EQUIPMENTNO
left join s4 on t1.EQUIPMENTNO = s4.EQUIPMENTNO
left join k4 on t1.EQUIPMENTNO = k4.EQUIPMENTNO
where a.EQUIPMENTNO = t1.EQUIPMENTNO and a.EQUIPMENTSTATE = b.EQUIPMENTSTATE
order by t1.SEQUENCE;


--END;



/*
SEQUENCE,   EQUIPMENTNO,        STATION,    EQUIPMENTNAME,  DESCRIPTION,                EQUIPMENTSTATE, STATENAME, STARTTIME,    YAT,   YTT,    MAT,    MTT,    STATECOLOR
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
1	        SPAW50-1	        12" Polish	S50-1	        SPAW50-1	                1	            UP		                86401	86401	1582014	1655853	1
2	        SPAW50-2	        12" Polish	S50-2	        SPAW50-2	                5	            PM	        20-7月 -23	77291	86403	1586905	1655868	2
3	        SPAW50-3	        12" Polish	S50-3	        SPAW50-3	                1	            UP		                84121	86407	1573828	1655880	1
4	        SPAW50-4	        12" Polish	S50-4	        SPAW50-4	                1	            UP		                86401	86401	1588149	1655866	1
5	        SPAW50-5	        12" Polish	S50-5	        SPAW50-5	                1	            UP		                84254	86405	1627451	1655830	1
6	        SPAW50-6	        12" Polish	S50-6	        SPAW50-6	                1	            UP		                73292	86405	1523079	1655973	1
7	        SPAW50-7	        12" Polish	S50-7	        SPAW50-7	                1	            UP		                86401	86401	1584128	1655864	1
8	        SPAW50-8	        12" Polish	S50-8	        SPAW50-8	                13	            MON	        20-7月 -23	55927	86417	1569108	1655886	2
10	        SPAW50-9-2	        12" Polish	S50-9-2	        SPAW50-9-2	                1	            UP		                86401	86401	1655806	1655806	1
11	        SPAW50-10	        12" Polish	S50-10	        SPAW50-10	                1	            UP		                85462	86403	1602704	1655858	1
12	        SPAW50-11	        12" Polish	S50-11	        SPAW50-11	                13	            MON	        20-7月 -23	82842	86402	1570231	1655859	2
13	        SPAW50-12	        12" Polish	S50-12	        SPAW50-12	                1	            UP		                86401	86401	1580945	1655856	1
14	        SPAW50-13	        12" Polish	S50-13	        SPAW50-13	                1	            UP		                84575	86403	1550920	1655857	1
15	        SPAW50-14	        12" Polish	S50-14	        SPAW50-14	                1	            UP		                86401	86401	1630233	1655822	1
16	        SPAW50-15	        12" Polish	S50-15	        SPAW50-15	                1	            UP		                86401	86401	1605310	1655858	1
17	        SPAW50-16	        12" Polish	S50-16	        SPAW50-16	                1	            UP		                86401	86401	1560404	1655846	1
18	        SPAW50-17	        12" Polish	S50-17	        SPAW50-17	                1	            UP		                86401	86401	1606631	1655846	1
19	        SPAW50-18	        12" Polish	S50-18	        SPAW50-18	                1	            UP		                74253	86405	1606579	1655838	1
20	        SPAW50-19	        12" Polish	S50-19	        SPAW50-19	                1	            UP		                86401	86401	1616658	1655850	1
21	        SPAW50-20	        12" Polish	S50-20	        SPAW50-20	                1	            UP		                83831	86403	1456052	1655839	1
22	        SPAW50-21	        12" Polish	S50-21	        SPAW50-21	                1	            UP		                83421	86403	1573521	1655833	1
23	        SPAW50-22	        12" Polish	S50-22	        SPAW50-22	                1	            UP		                83419	86403	1591254	1655841	1
24	        SPAW50-23	        12" Polish	S50-23	        SPAW50-23	                1	            UP		                79630	86405	1529220	1655852	1
25	        SPAW50-24	        12" Polish	S50-24	        SPAW50-24	                1	            UP		                86401	86401	1528751	1655859	1
26	        SPAW50-25	        12" Polish	S50-25	        SPAW50-25	                1	            UP		                84336	86403	1562548	1655842	1
27	        SPAW50-26	        12" Polish	S50-26	        SPAW50-26	                1	            UP		                84025	86403	1564264	1655837	1
28	        SPAW50-27	        12" Polish	S50-27	        SPAW50-27	                1	            UP		                86401	86401	1565127	1655845	1
29	        SPAW50-28	        12" Polish	S50-28	        SPAW50-28	                1	            UP		                86401	86401	1592665	1655835	1
30	        SPAW50-29	        12" Polish	S50-29	        SPAW50-29	                1	            UP		                75914	86409	1574974	1655841	1
31	        SPAW50-30	        12" Polish	S50-30	        SPAW50-30	                1	            UP		                82886	86403	1582262	1655845	1
32	        SPAW50-31	        12" Polish	S50-31	        SPAW50-31	                1	            UP		                81456	86406	1563273	1655850	1
33	        SPAW50-32	        12" Polish	S50-32	        SPAW50-32	                1	            UP		                84034	86403	1583599	1655833	1
34	        TSK-1	            12" Polish	TSK-1	        TSK-1	                    1	            UP		                86401	86401	1638915	1655823	1
35	        TSK-2	            12" Polish	TSK-2	        TSK-2	                    1	            UP		                86401	86401	1643597	1655821	1
36	        TSK-3	            12" Polish	TSK-3	        TSK-3	                    3	            OFF	        19-7月 -23	86401	        1546331	1655814	2
37	        TSK-4	            12" Polish	TSK-4	        TSK-4	                    1	            UP		                86401	86401	1623601	1655823	1
38	        TSK-5	            12" Polish	TSK-5	        TSK-5	                    3	            OFF	        19-7月 -23	86401	        1534004	1655824	2
39	        TSK-6	            12" Polish	TSK-6	        TSK-6	                    1	            UP		                86401	86401	1631426	1655839	1
40	        TSK-7	            12" Polish	TSK-7	        TSK-7	                    1	            UP		                86401	86401	1635453	1655821	1
41	        TSK-8	            12" Polish	TSK-8	        TSK-8	                    1	            UP		                86401	86401	1604519	1655829	1
42	        TSK-9	            12" Polish	TSK-9	        TSK-9	                    1	            UP		                86401	86401	1634211	1655826	1
43	        TSK-10	            12" Polish	TSK-10	        TSK-10	                    1	            UP		                86401	86401	1638267	1655814	1
44	        TSK-11	            12" Polish	TSK-11	        TSK-11	                    1	            UP		                81781	86403	1636506	1655823	1
45	        TSK-12	            12" Polish	TSK-12	        TSK-12	                    1	            UP		                86401	86401	1626907	1655814	1
46	        TSK-13	            12" Polish	TSK-13	        TSK-13	                    1	            UP		                77485	86405	1606667	1655817	1
47	        TSK-14	            12" Polish	TSK-14	        TSK-14	                    1	            UP		                10944	86407	1477267	1655823	1
48	        TSK-15	            12" Polish	TSK-15	        TSK-15	                    1	            UP		                12616	86405	1302137	1655841	1
49	        TSK-16	            12" Polish	TSK-16	        TSK-16	                    3	            OFF	        20-7月 -23	74099	86402	1620307	1655833	2
50	        TSK-17	            12" Polish	TSK-17	        TSK-17	                    1	            UP		                86401	86401	1624980	1655814	1
51	        EBARA-1R	        12" Polish	Ebara-1R	    EBARA-1R	                5	            PM	        20-7月 -23	77453	86407	1543699	1655910	2
52	        EBARA-1L	        12" Polish	Ebara-1L	    EBARA-1L	                5	            PM	        20-7月 -23	78777	86403	1537911	1655892	2
53	        EBARA-2R	        12" Polish	Ebara-2R	    EBARA-2R	                1	            UP		                85422	86405	1562216	1655881	1
54	        EBARA-2L	        12" Polish	Ebara-2L	    EBARA-2L	                1	            UP		                81053	86417	1463984	1656013	1
55	        EBARA-3R	        12" Polish	Ebara-3R	    EBARA-3R	                1	            UP		                86401	86401	1581067	1655833	1
56	        EBARA-3L	        12" Polish	Ebara-3L	    EBARA-3L	                1	            UP		                86401	86401	1583482	1655839	1
57	        EBARA-4R	        12" Polish	Ebara-4R	    EBARA-4R	                1	            UP		                86401	86401	1573428	1655835	1
58	        EBARA-4L	        12" Polish	Ebara-4L	    EBARA-4L	                1	            UP		                86401	86401	1620357	1655836	1
59	        EBARA-5R	        12" Polish	Ebara-5R	    EBARA-5R	                2	            DOWN	    15-5月 -23	        86401	1655806	        2
60	        EBARA-5L	        12" Polish	Ebara-5L	    EBARA-5L	                3	            OFF	        28-6月 -23	        86401	1655806	        2
61	        PRE_CLEAN-2	        12" Clean	PC-2	        PRE_CLEAN-2	                1	            UP		                86401	86401	1555589	1655838	1
62	        PRE_CLEAN-3	        12" Clean	PC-3	        PRE_CLEAN-3	                1	            UP		                86401	86401	1655806	1655806	1
63	        FINAL_CLEAN-3	    12" Clean	FC-3	        FINAL_CLEAN-3	            1	            UP		                65086	86403	1614675	1655826	1
64	        ACM	                12" Clean	ACM	            ACM	                        1	            UP		                86401	86401	1590332	1655848	1
65	        ACM CH-A	        12" Clean	ACM CH-A	    ACM CH-A	                1	            UP		                86401	86401	1655709	1655809	1
66	        ACM CH-B	        12" Clean	ACM CH-B	    ACM CH-B	                1	            UP		                86401	86401	1655806	1655806	1
67	        ACM CH-C	        12" Clean	ACM CH-C	    ACM CH-C	                1	            UP		                86401	86401	1655806	1655806	1
68	        ACM CH-D	        12" Clean	ACM CH-D	    ACM CH-D	                1	            UP		                86401	86401	1654655	1655810	1
69	        ACM CH-E	        12" Clean	ACM CH-E	    ACM CH-E	                1	            UP		                86401	86401	1655806	1655806	1
70	        ACM CH-F	        12" Clean	ACM CH-F	    ACM CH-F	                1	            UP		                86401	86401	1655806	1655806	1
71	        ACM CH-G	        12" Clean	ACM CH-G	    ACM CH-G	                1	            UP		                86401	86401	1654350	1655810	1
72	        ACM CH-H	        12" Clean	ACM CH-H	    ACM CH-H	                1	            UP		                86401	86401	1655806	1655806	1
73	        OASIS	            12" Clean	Oasis	        Oasis	                    1	            UP		                69716	86413	1618287	1655842	1
74	        OASIS-T1	        12" Clean	Oasis-T1	    Oasis(TANK1)	            1	            UP		                86401	86401	1655806	1655806	1
75	        OASIS-T2	        12" Clean	Oasis-T2	    Oasis(TANK2)	            1	            UP		                80190	86405	1649595	1655810	1
76	        SCRUBBER-1	        12" Clean	SC	            Scrubber-1	                1	            UP		                84626	86405	1645296	1655830	1
77	        SCRUBBER-1-T1	    12" Clean	SC-T1	        Scrubber-1(TANK1)	        1	            UP		                86401	86401	1655806	1655806	1
78	        SCRUBBER-1-T2	    12" Clean	SC-T2	        Scrubber-1(TANK2)	        1	            UP		                86401	86401	1655806	1655806	1
79	        SCRUBBER-2	        12" Clean	SD	            Scrubber-2	                1	            UP		                81431	86409	1589727	1655960	1
80	        SCRUBBER-2-T1	    12" Clean	SD-T1	        Scrubber-2(TANK1)	        1	            UP		                86401	86401	1655806	1655806	1
81	        SCRUBBER-2-T2	    12" Clean	SD-T2	        Scrubber-2(TANK2)	        1	            UP		                86401	86401	1655806	1655806	1
82	        SCRUBBER-2-T3	    12" Clean	SD-T3	        Scrubber-2(TANK3)	        1	            UP		                86401	86401	1655806	1655806	1
83	        SCRUBBER-2-T4	    12" Clean	SD-T4	        Scrubber-2(TANK4)	        1	            UP		                86401	86401	1655806	1655806	1
84	        I_CLEAN-T1	        12" Clean	IC-T1	        I_CLEAN-T1	                1	            UP		                86401	86401	1626462	1655826	1
85	        I_CLEAN-T2	        12" Clean	IC-T2	        I_CLEAN-T2	                1	            UP		                86401	86401	1626303	1655826	1
86	        GOLD_FINGER-1	    12" Clean	GF-1	        Gold Finger-1	            1	            UP		                84916	86405	1640573	1655842	1
87	        GOLD_FINGER-1-C1	12" Clean	GF-1-C1	        Gold Finger-1 (CHAMBER1)	2	            DOWN	    20-7月 -23	77940	86403	1633565	1655812	2
88	        GOLD_FINGER-1-C2	12" Clean	GF-1-C2	        Gold Finger-1 (CHAMBER2)	1	            UP		                86401	86401	1655806	1655806	1
89	        GOLD_FINGER-1-C3	12" Clean	GF-1-C3	        Gold Finger-1 (CHAMBER3)	1	            UP		                86401	86401	1655806	1655806	1
90	        GOLD_FINGER-1-C4	12" Clean	GF-1-C4	        Gold Finger-1 (CHAMBER4)	1	            UP		                86401	86401	1655806	1655806	1
91	        GOLD_FINGER-2	    12" Clean	GF-2	        Gold Finger-2	            2	            DOWN	    16-6月 -23		    86401		    1655806	2
92	        GOLD_FINGER-2-C1	12" Clean	GF-2-C1	        Gold Finger-2(CHAMBER1)	    1	            UP		                86401	86401	1655806	1655806	1
93	        GOLD_FINGER-2-C2	12" Clean	GF-2-C2	        Gold Finger-2(CHAMBER2)	    1	            UP		                86401	86401	1655806	1655806	1
94	        GOLD_FINGER-2-C3	12" Clean	GF-2-C3	        Gold Finger-2(CHAMBER3)	    1	            UP		                86401	86401	1655806	1655806	1
95	        GOLD_FINGER-2-C4	12" Clean	GF-2-C4	        Gold Finger-2(CHAMBER4)	    1	            UP		                86401	86401	1655806	1655806	1
96	        SCC-1	            12" Clean	SCC-1	        SCC-1	                    1	            UP		                86401	86401	1606964	1655846	1
98	        REFLEXION	        12" Clean	REFLEXION	    Reflexion	                30	            LEND	    04-1月 -23		    86401		    1655806	2
99	        RPW308	            E區	        308-1	        RPW308	                    0	            LOST	    19-7月 -23	86401	86401	1613067	1655833	0
100	        RPW3083	            E區	        308-3	        RPW3083	                    1	            UP		                75576	86409	1568703	1655845	1
101	        RPW3080-1	        E區	        3080-1	        RPW3080-1	                1	            UP		                86402	86402	1655808	1655808	1
102	        RPW3080-5	        E區	        3080-5	        RPW3080-5	                0	            LOST	    20-7月 -23	86403	86403	1650590	1655816	0
103	        BOX_CLEAN-3	        10K	        Box Clean3	    Box cleaner-3	            1	            UP		                86401	86401	1649432	1655810	1
104	        BOX_CLEAN-6	        10K	        Box Clean6	    Box cleaner-2	            28	            WAIT-MFG	20-7月 -23	75331	86404	1635785	1655813	2
105	        TBI-1	            4F Tencor	TBI-1	        TBI-1	                    1	            UP		                86401	86401	1637040	1655830	1
106	        TBI-2	            4F Tencor	TBI-2	        TBI-2	                    1	            UP		                86401	86401	1649463	1655814	1
107	        TBI-3	            4F Tencor	TBI-3	        TBI-3	                    1	            UP		                86401	86401	1655806	1655806	1
108	        TBI-4	            4F Tencor	TBI-4	        TBI-4	                    1	            UP		                86401	86401	1558316	1655830	1
109	        SP2-1	            4F Tencor	SP-2-1	        SP2-1	                    1	            UP		                86401	86401	1630730	1655830	1
110	        SP2-2	            4F Tencor	SP-2-2	        SP2-2	                    1	            UP		                86401	86401	1652912	1655814	1
111	        SP3	                4F Tencor	SP-3	        SP3	                        1	            UP		                86401	86401	1631789	1655818	1
112	        RPW350-1	        4F Tencor	350-1	        RPW350-1	                1	            UP		                86401	86401	1639452	1655842	1
113	        RPW350-2	        4F Tencor	350-2	        RPW350-2	                1	            UP		                86401	86401	1641323	1655817	1
114	        RPW350-3	        4F Tencor	350-3	        RPW350-3	                1	            UP		                86401	86401	1655806	1655806	1
115	        RPW350-4	        4F Tencor	350-4	        RPW350-4	                1	            UP		                86401	86401	1655806	1655806	1
116	        PACK-3	            4F Tencor	Pack3	        PACK-3	                    1	            UP		                86401	86401	1652273	1655810	1
117	        PACK-4	            4F Tencor	Pack4	        PACK-4	                    1	            UP		                86401	86401	1655806	1655806	1
118	        TBI-5	            1F Tencor	TBI-5	        TBI-5	                    1	            UP		                86401	86401	1650112	1655818	1
119	        SP3-2	            1F Tencor	SP-3-2	        SP3-2	                    1	            UP		                86401	86401	1654848	1655810	1
120	        SP2-3	            1F Tencor	SP-2-3	        SP2-3	                    1	            UP		                86401	86401	1655806	1655806	1
121	        SP2-4	            1F Tencor	SP-2-4	        SP2-4	                    1	            UP		                86401	86401	1610968	1655843	1
122	        SP5	                1F Tencor	SP-5	        SP5	                        1	            UP		                86401	86401	1472333	1655817	1
123	        SP7	                1F Tencor	SP-7	        SP7	                        1	            UP		                86401	86401	1642110	1655818	1
124	        RPW3065	            1F Tencor	3065	        RPW3065	                    1	            UP		                86401	86401	1643132	1655814	1
125	        RPW3065-2	        1F Tencor	3065-2	        RPW3065-2	                1	            UP		                86401	86401	1653362	1655810	1
126	        RPW3085	            1F Tencor	RPW3085	        RPW3085	                    1	            UP		                86401	86401	1475877	1655837	1
127	        BOX_CLEAN-4	        1F Tencor	Box Clean4	    Box cleaner-4	            1	            UP		                86401	86401	1652796	1655818	1
128	        BOX_CLEAN-5	        1F Tencor	Box Clean5	    Box cleaner-5	            1	            UP		                86401	86401	1655806	1655806	1
129	        PACK-5	            1F Tencor	Pack5	        PACK-5	                    1	            UP		                86401	86401	1641066	1655810	1
130	        PACK-6	            1F Tencor	Pack6	        PACK-6	                    1	            UP		                86401	86401	1655806	1655806	1
131	        RPW3080-2	        1C	        3080-2	        RPW3080-2	                1	            UP		                86401	86401	1649871	1655814	1
132	        RPW3080-3	        1C	        3080-3	        RPW3080-3	                1	            UP		                86401	86401	1655806	1655806	1
133	        RPW3080-4	        1C	        3080-4	        RPW3080-4	                1	            UP		                86401	86401	1655808	1655808	1
134	        RPW3080-6	        1C	        RPW3080-6	    RPW3080-6	                1	            UP		                86401	86401	1592557	1655824	1
135	        SPAW59-1	        8" Polish	S59-1	        SPAW59-1	                1	            UP		                53280	86419	1448700	1655927	1
136	        SPAW59-2	        8" Polish	S59-2	        SPAW59-2	                11	            BROKEN	    20-7月 -23	27441	86407	1498799	1655876	2
137	        PRE_CLEAN-1	        8" Clean	PC-1	        PRE_CLEAN-1	                1	            UP		                86401	86401	1654462	1655810	1
138	        FINAL_CLEAN-1	    8" Clean	FC-1	        FINAL_CLEAN-1	            1	            UP		                86401	86401	1584326	1655836	1
139	        EH204-1	            1K	        E+H 204-1	    EH204-1	                    1	            UP		                83527	86405	1641318	1655814	1
140	        EH204-2	            1K	        E+H 204-2	    EH204-2	                    1	            UP		                86401	86401	1655806	1655806	1
141	        BOX_CLEAN-1	        10K	        Box Clean1	    Box cleaner-1	            1	            UP		                86401	86401	1561774	1655823	1
142	        EH202	            E區	        E+H 202	        EH202	                    1	            UP		                81753	86409	1578499	1655872	1
143	        ADE7200	            E區	        ADE72	        ADE7200	                    1	            UP		                84290	86405	1560458	1655870	1
144	        SP1	                4F Tencor	SP-1	        SP1	                        1	            UP		                55028	86403	1510566	1655838	1
145	        6220-1	            4F Tencor	6220-1	        6220-1	                    1	            UP		                86401	86401	1655127	1655832	1
146	        6220-2	            4F Tencor	6220-2	        6220-2	                    1	            UP		                86401	86401	1654789	1655828	1
147	        LASER_MARK-2	    4F Tencor	LM-2	        LASER_MARK-2	            1	            UP		                86401	86401	1653804	1655810	1
148	        LASER_MARK-3	    4F Tencor	LM-3	        LASER_MARK-3	            1	            UP		                86401	86401	1655806	1655806	1
149	        ADE9300	            4F Tencor	ADE93	        ADE9300	                    1	            UP		                86401	86401	1549276	1655830	1
150	        12DRYER	            ETCH	    12DRYER	        12DRYER	                    1	            UP		                86401	86401	1655806	1655806	1
151	        12DRYER-1	        ETCH	    12DRYER-1	    12DRYER-1	                1	            UP		                86401	86401	1651043	1655814	1
152	        12DRYER-2	        ETCH	    12DRYER-2	    12DRYER-2	                2	            DOWN	    07-7月 -23	        86401	21	    1655810	2
153	        12DRYER-CU	        ETCH	    12DRYER-CU	    12DRYER-CU	                1	            UP		                86401	86401	1655806	1655806	1
155	        12H2SO4-2	        ETCH	    12H2SO4-2	    12H2SO4-2	                1	            UP		                86401	86401	1655806	1655806	1
156	        12H2SO4-3	        ETCH	    12H2SO4-3	    12H2SO4-3	                1	            UP		                86401	86401	1655806	1655806	1
157	        12H2SO4-CU	        ETCH	    12H2SO4-CU	    12H2SO4-CU	                3	            OFF	        22-5月 -23	        86401		    1655806	2
158	        12H2SO4-4-CU	    ETCH	    12H2SO4-4-CU	12H2SO4-4-CU	            1	            UP		                86401	86401	1648466	1655818	1
159	        12HF-1	            ETCH	    12HF-1	        12HF-1	                    1	            UP		                86401	86401	1648578	1655810	1
161	        12HF-3	            ETCH	    12HF-3	        12HF-3	                    1	            UP		                86401	86401	1655806	1655806	1
162	        12HF-4	            ETCH	    12HF-4	        12HF-4	                    1	            UP		                86401	86401	1655806	1655806	1
163	        12HF-5	            ETCH	    12HF-5	        12HF-5	                    1	            UP		                86401	86401	1641241	1655814	1
164	        12HF-CU	            ETCH	    12HF-CU	        12HF-CU	                    1	            UP		                86401	86401	1655806	1655806	1
166	        12KOH-2	            ETCH	    12KOH-2	        12KOH-2	                    1	            UP		                86401	86401	1655806	1655806	1
167	        12KOH-3	            ETCH	    12KOH-3	        12KOH-3	                    1	            UP		                86401	86401	1655806	1655806	1
168	        12KOH-CU	        ETCH	    12KOH-CU	    12KOH-CU	                1	            UP		                86401	86401	1655806	1655806	1
169	        8DRYER-1	        ETCH	    8DRYER-1	    8DRYER-1	                1	            UP		                86401	86401	1655806	1655806	1
170	        8DRYER-2	        ETCH	    8DRYER-2	    8DRYER-2	                1	            UP		                86401	86401	1655806	1655806	1
171	        8H2SO4	            ETCH	    8H2SO4	        8H2SO4	                    1	            UP		                86401	86401	1655806	1655806	1
172	        8HF	                ETCH	    8HF	            8HF	                        1	            UP		                86401	86401	1640552	1655810	1
173	        8KOH-1	            ETCH	    8KOH-1	        8KOH-1	                    1	            UP		                86401	86401	1655806	1655806	1
174	        8KOH-2	            ETCH	    8KOH-2	        8KOH-2	                    1	            UP		                86401	86401	1655806	1655806	1
175	        ETCH_EQP	        ETCH	    ETCH_EQP	    ETCH_EQP	                1	            UP		                86401	86401	1652027	1655821	1
178	        PLASMA-2	        ETCH	    PLASMA-2	    PLASMA-2	                1	            UP		                86401	86401	1641645	1655821	1
179	        PLASMA-3	        ETCH	    PLASMA-3	    PLASMA-3	                1	            UP		                86401	86401	1593179	1655863	1
180	        PLASMA-4	        ETCH	    PLASMA-4	    PLASMA-4	                1	            UP		                86401	86401	1649334	1655810	1
181	        王水	            ETCH	    王水	        王水	                     1	             UP		                 86401	 86401	 1655806 1655806 1
182	        GD-1	            4F A區	    GD-1	        GD-1	                    1	            UP		                86401	86401	1629731	1655816	1
183	        GD-2	            4F A區	    GD-2	        GD-2	                    1	            UP		                67349	86403	1630231	1655812	1
184	        GD-3	            4F A區	    GD-3	        8吋	                        1	            UP		                86401	86401	1633142	1655812	1
185	        GD-4	            4F A區	    GD-4	        8吋	                        1	            UP		                86401	86401	1641442	1655816	1
186	        12GD-1	            4F A區	    12GD-1	        12吋	                    5	            PM	        20-7月 -23	80199	86403	1649604	1655808	2
187	        12GD-2	            4F A區	    12GD-2	        12吋	                    1	            UP		                86401	86401	1583138	1655833	1
188	        12GD-3	            4F A區	    12GD-3	        12吋	                    1	            UP		                86401	86401	1621397	1655819	1
189	        12GD-4	            4F A區	    12GD-4	        12吋	                    1	            UP		                86401	86401	1607887	1655815	1
*/