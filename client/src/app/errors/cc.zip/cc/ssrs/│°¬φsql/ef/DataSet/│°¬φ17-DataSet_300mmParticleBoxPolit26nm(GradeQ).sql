USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD) from CTE
),


-- Copper
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFG_Date'=dbo.RealDateToMfgDate(CollectionTime)
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1 between 21 and 26
and WaferGrade='GradeQ'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFG_Date'=dbo.RealDateToMfgDate(CollectionTime)
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1 between 21 and 26
and WaferGrade='GradeQ'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
)


select a.MFGDate, 'Line'='Copper', 'nm'='26nm', b.*
from TempDay a left join (
select distinct MFG_Date
      ,'Box_Max'=max(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Min'=min(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by MFG_Date)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by MFG_Date))
from tempC with(nolock)
) b
  on a.MFGDate=b.MFG_Date

union all
select a.MFGDate, 'Line'='Non-Copper', 'nm'='26nm', b.*
from TempDay a left join (
select distinct MFG_Date
      ,'Box_Max'=max(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Min'=min(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by MFG_Date)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by MFG_Date))
from tempD with(nolock)
) b
  on a.MFGDate=b.MFG_Date

GO



/*
產生結果如下  20230718 執行時間，為20230718 17:07
MFGDate	            Line	    nm	    MFG_Date	            Box_Max	Box_Min	Box_Avg	Box_75	Box_50	Box_25
--------------------------------------------------------------------------------------------------------------
2023-07-05 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-06-29 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-02 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-11 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-06-30 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-08 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-03 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-09 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-06 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-12 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-01 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-07 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-04 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-10 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-06-28 00:00:00	Copper	    26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL
2023-07-02 00:00:00	Non-Copper	26nm	2023-07-02 00:00:00.000	129	    24	    69	    81	    66	    55
2023-07-11 00:00:00	Non-Copper	26nm	2023-07-11 00:00:00.000	91	    31	    51	    55.5	48.5	43.25
2023-07-10 00:00:00	Non-Copper	26nm	2023-07-10 00:00:00.000	125	    25	    60	    70	    58	    49
2023-07-08 00:00:00	Non-Copper	26nm	2023-07-08 00:00:00.000	114	    42	    75	    90	    72	    59
2023-07-01 00:00:00	Non-Copper	26nm	2023-07-01 00:00:00.000	123	    40	    79	    102	    69	    57
2023-06-30 00:00:00	Non-Copper	26nm	2023-06-30 00:00:00.000	102	    45	    67	    79	    73	    54
2023-07-09 00:00:00	Non-Copper	26nm	2023-07-09 00:00:00.000	128	    26	    63	    74.5	61	    50
2023-07-04 00:00:00	Non-Copper	26nm	2023-07-04 00:00:00.000	130	    28	    72	    84	    70	    57
2023-07-07 00:00:00	Non-Copper	26nm	2023-07-07 00:00:00.000	130	    38	    73	    82	    73	    60.5
2023-07-06 00:00:00	Non-Copper	26nm	2023-07-06 00:00:00.000	130	    31	    79	    94	    77	    63
2023-06-29 00:00:00	Non-Copper	26nm	2023-06-29 00:00:00.000	130	    42	    76	    86.5	75	    64
2023-07-05 00:00:00	Non-Copper	26nm	2023-07-05 00:00:00.000	130	    38	    83	    97	    82	    68
2023-06-28 00:00:00	Non-Copper	26nm	2023-06-28 00:00:00.000	127	    31	    66	    78	    63	    53
2023-07-03 00:00:00	Non-Copper	26nm	2023-07-03 00:00:00.000	130	    24	    71	    84	    70	    58
2023-07-12 00:00:00	Non-Copper	26nm	NULL	                NULL	NULL	NULL	NULL	NULL	NULL

*/