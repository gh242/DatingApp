USE [WarInfo]
GO


DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230718';
-- DECLARE @Mode VARCHAR(2);
-- SET @Mode = 'A';


with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD) from CTE
),


-- Copper
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFG_Date'=dbo.RealDateToMfgDate(CollectionTime)
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1 between 16 and 20
and WaferGrade='GradeT'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFG_Date'=dbo.RealDateToMfgDate(CollectionTime)
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1 between 16 and 20
and WaferGrade='GradeT'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
)


select a.MFGDate, 'Line'='Copper', 'nm'='19nm', b.*
from TempDay a left join (
select distinct MFG_Date
      ,'Box_Max'=max(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Min'=min(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by MFG_Date)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by MFG_Date))
from tempC with(nolock)
) b
  on a.MFGDate=b.MFG_Date

union all
select a.MFGDate, 'Line'='Non-Copper', 'nm'='19nm', b.*
from TempDay a left join (
select distinct MFG_Date
      ,'Box_Max'=max(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Min'=min(ParticleCount1) over (partition by MFG_Date)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by MFG_Date)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by MFG_Date))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by MFG_Date))
from tempD with(nolock)
) b
  on a.MFGDate=b.MFG_Date


/*
產生結果如下  20230718 執行時間，為20230718 09:10
MFGDate	            Line	      nm	MFG_Date	            Box_Max Box_Min	Box_Avg  Box_75	Box_50   Box_25
---------------------------------------------------------------------------------------------------------------------
2023-06-29 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-23 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-02 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-26 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-21 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-27 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-30 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-24 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-03 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-25 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-22 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-01 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-04 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-20 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-28 00:00:00	Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-30 00:00:00	Non-Copper	19nm	2023-06-30 00:00:00.000	175	  58        111	   129	110	   93
2023-07-01 00:00:00	Non-Copper	19nm	2023-07-01 00:00:00.000	169	  52	      105	   119	104	   89
2023-06-29 00:00:00	Non-Copper	19nm	2023-06-29 00:00:00.000	136	  83	      107	   115	105.5	   97.5
2023-06-23 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-02 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-26 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-21 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-27 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-24 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-03 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-25 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-22 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-07-04 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-20 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL
2023-06-28 00:00:00	Non-Copper	19nm	NULL	                  NULL	  NULL	NULL	   NULL	NULL	   NULL

*/