USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;


with TempA as (
-- Copper
select 'Line'='Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 70 and 88 )
and WaferGrade='GradeA'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
),

-- Non-Copper
TempB as (
select 'Line'='Non-Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 70 and 88 )
and WaferGrade='GradeA'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
),

TempC as (
-- Copper
select 'Line'='Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
)


select distinct 'Line'='Copper', 'nm'='88nm', PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
from tempA with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='88nm', PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
from tempB with(nolock)

union all
select distinct 'Line'='Copper', 'nm'='32nm', PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
from tempC with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='32nm', PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by PreCleaner, FinalCleaner))
from tempD with(nolock)


GO