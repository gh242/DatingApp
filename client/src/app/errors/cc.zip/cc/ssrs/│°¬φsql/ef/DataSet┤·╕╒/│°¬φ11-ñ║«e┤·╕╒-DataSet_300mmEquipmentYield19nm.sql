USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';



/*
產生結果如下  20230718 執行時間，為20230718 15:38
------select * from EDA_Tencorlog
StationName	MFGDate	    CollectionTime	        LotID	                    WaferGrade	WaferGradeOriginal	RecipeName	    KlarfName	                                                                                            Product	Result	HazeAverage	        ParticleCount1	ParticleCount2	AreaCount	TotalArea	        ScratchCount	ScratchLength	RPW350_LotID	T7ID	ThicknessCenter	TTV	    Bow	    Warp	Resistivity	PNtype	Class	VariationLastPolishThicknessCenter	VariationLastPolishTTV	VariationLastPolishWarp	VariationThicknessCenter	VariationTTV	VariationWarp	ParticleSize1	ParticleSize2	Process	ProcessThickness	PolishShift	Polisher	PolishNo	RecipeFine	RecipeRough	PadUsedFine	PadUsedRough	PreCleaner	PreCleanNo	PreCleanSide	FinalCleaner	FinalCleanNo	FinalCleanSide	FinalCleaner2	FinalCleanNo2	FinalCleanSide2
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TENCOR_17	2023-07-12	2023-07-12 11:22:07.000	2AN7E16GPSK-4J2L-JJ01-M07	Reject	    REJECTED	        EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112207_2AN7E16GPSK-4J2L-JJ01-M07_S12_REJECTED.001	2AE	    0	    0.0277648717164993	317	            247	            115	        488869.246887207	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:22:52.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeQ	    GRADEQ	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112252_2AN7E16GPSK-4J2L-JJ01-M07_S11_GRADEQ.001	    2AE	    1	    0.0279821995645761	133	            69	            11	        18510.3427124023	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:23:37.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeT	    GRADET	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112337_2AN7E16GPSK-4J2L-JJ01-M07_S10_GRADET.001	    2AE	    1	    0.0273337494581938	151	            85	            2	        448.838653564453	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:24:22.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeT	    GRADET	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112422_2AN7E16GPSK-4J2L-JJ01-M07_S09_GRADET.001	    2AE	    1	    0.0282096955925226	132	            76	            2	        495.757720947266	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:25:07.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeP	    GRADEP	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112507_2AN7E16GPSK-4J2L-JJ01-M07_S08_GRADEP.001	    2AE	    1	    0.0277843661606312	229	            153	            10	        7541.12940216064	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:25:52.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeQ	    GRADEQ	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112552_2AN7E16GPSK-4J2L-JJ01-M07_S07_GRADEQ.001	    2AE	    1	    0.0282597467303276	160	            89	            3	        3908.6545715332	    0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:26:37.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeQ	    GRADEQ	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112637_2AN7E16GPSK-4J2L-JJ01-M07_S06_GRADEQ.001	    2AE	    1	    0.0274558216333389	204	            78	            8	        14190.6998519897	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:27:22.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeT	    GRADET	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112722_2AN7E16GPSK-4J2L-JJ01-M07_S05_GRADET.001	    2AE	    1	    0.0275527741760015	152	            78	            3	        1309.21981811523	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:28:07.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeQ	    GRADEQ	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112807_2AN7E16GPSK-4J2L-JJ01-M07_S04_GRADEQ.001	    2AE	    1	    0.0271872580051422	180	            116	            4	        8530.55499267578	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:28:52.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeP	    GRADEP	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112852_2AN7E16GPSK-4J2L-JJ01-M07_S03_GRADEP.001	    2AE	    1	    0.0274403765797615	324	            151	            9	        60767.4535903931	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
TENCOR_17	2023-07-12	2023-07-12 11:29:37.000	2AN7E16GPSK-4J2L-JJ01-M07	GradeQ	    GRADEQ	            EG-0.019-GRADET	\\172.28.128.120\Klarf\SP7\2023_07\20230712\230712_112937_2AN7E16GPSK-4J2L-JJ01-M07_S02_GRADEQ.001	    2AE	    1	    0.0283667836338282	173	            95	            14	        215437.065353394	0	            0	            NULL	        NULL	NULL	        NULL	NULL	NULL	NULL	    NULL	NULL	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        19	            26	            GP	    S	                J	        19	        1	        	        	        0	        0	            Ebara4	    2	        L	            ACM1	        7	 	                        NULL	        NULL	 
...
*/

with TempA as (
Non-Copper
select 'Line'='Non-Copper'
       ,Polisher
       ,'PreCleaner'=PreCleaner+PreCleanSide
       ,FinalCleaner
       ,'PassT'=sum(case when WAFERGRADE='GRADET' then 1
                         else 0
                    end)
       ,'PassQ'=sum(case when WAFERGRADE='GRADEQ' then 1
                         else 0
                    end)
       ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                         else 0
                    end)
       ,'Total'=count(*)
-- select *
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20)
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner

/*
產生結果如下  20230718 執行時間，為20230718 15:28
Line	    Polisher	PreCleaner	FinalCleaner	PassT	PassQ	PassP	Total
---------------------------------------------------------------------------------
Non-Copper	19	        Ebara4L	    ACM1	        30	    28	    14	    79
*/


/*
-- Copper
union all
select 'Line'='Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,'PassT'=sum(case when WAFERGRADE='GRADET' then 1
                                        else 0
                                        end)
          ,'PassQ'=sum(case when WAFERGRADE='GRADEQ' then 1
                                        else 0
                                        end)
          ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner
*/
-- )


select a.*
         ,'Fail'=a.Total-a.PassT-a.PassQ-a.PassP
          ,'YieldT'=1.0000*a.PassT/a.Total
          ,'YieldQ'=1.0000*a.PassQ/a.Total
          ,'YieldP'=1.0000*a.PassP/a.Total
from TempA a

GO


/*
產生結果如下  20230718 執行時間，為20230718 15:25
Line	    Polisher	PreCleaner	FinalCleaner	PassT	PassQ	PassP	Total	Fail	YieldT	            YieldQ	            YieldP
-----------------------------------------------------------------------------------------------------------------------------------------------------
Non-Copper	19	        Ebara4L	    ACM1	        30	    28	    14	    79	    7	    0.379746835443037	0.354430379746835	0.177215189873417
*/