USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

--  報表36-DataSet_300mm555Loss 
--與報表 41(815Loss), 46(700Loss), 51(680Loss) 相似

--Non-Copper
select 'Line'='Non-Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1) -- 取12 5 碼
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112)  --20230711
and a.MANU_FROM_EQUID=555
and (a.MANU_FROM_LOTNO like '____[EGJKFMNPX]%' or a.MANU_FROM_LOTNO like '6___X%')
and a.MANU_FROM_LOTNO not like '9V__E%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)

union all
--Copper
select 'Line'='Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=555
and (a.MANU_FROM_LOTNO like '____[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and a.MANU_FROM_LOTNO not like '6___X%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)


GO

/*
執行時間為:20230721 13:45
產生結果如下 
Line	    LotNo	DESCRIPTION	       Qty
--------------------------------------------
Non-Copper	24_E	Broken(破片)	    1
Non-Copper	26_J	Broken(破片)	    2
Non-Copper	2A_E	Broken(破片)	    2
Non-Copper	52_E	Broken(破片)	    1
Non-Copper	72_J	Broken(破片)	    3
Non-Copper	25_F	Chip(缺角)	        5
Non-Copper	2A_E	Chip(缺角)	        9
Non-Copper	2B_E	Chip(缺角)	        5
Non-Copper	52_E	Chip(缺角)	        10
Non-Copper	72_J	Chip(缺角)	        6
Non-Copper	25_F	圓形凹點(circle)	55
Non-Copper	52_E	圓形凹點(circle)	61
Non-Copper	72_J	圓形凹點(circle)	25
Non-Copper	26_J	橘皮 (Orange Peel)	3
Non-Copper	2B_E	橘皮 (Orange Peel)	55
Non-Copper	25_F	邊緣高低差	        12
Non-Copper	26_J	邊緣高低差	        11
Non-Copper	2H_F	邊緣高低差	        100
Non-Copper	72_J	邊緣高低差	        12
Copper	    24_U	Broken(破片)	    9
Copper	    26_C	Broken(破片)	    5
Copper	    2U_S	Broken(破片)	    28
Copper	    24_U	Chip(缺角)	        2
Copper	    26_C	Chip(缺角)	        6
Copper	    2U_S	Chip(缺角)	        22
Copper	    2U_S	Grinding wafer	    85
Copper	    2U_S	橘皮 (Orange Peel)	15
Copper	    24_U	邊緣高低差	        27
Copper	    26_C	邊緣高低差	        149
Copper	    2U_S	邊緣高低差	        508
*/