USE [WarInfo]
GO

/****** Object:  View [dbo].[SSRS_Output_300mm]    Script Date: 2023/7/27 下午 04:12:23 ******/
-- SET ANSI_NULLS ON
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO


-- ALTER VIEW [dbo].[SSRS_Output_300mm]
-- AS
select x.Category
      ,'MFGDate'=cast(left(x.MFGDate, 4)+'-'+subString(x.MFGDate, 5, 2)+'-'+right(x.MFGDate, 2) as datetime)
	  ,'MFGShift'=case when MFGShift='A' or MFGShift='C' then 'D'
	                   when MFGShift='B' or MFGShift='D' then 'N'
					   else 'N/A'
					   end      --,x.LotNo
      ,x.Customer
      ,'PsiPN'=x.FG_PSI
      ,'CustomerPN'=case when x.FG_Customer='' or x.FG_Customer is null then 'N/A'
                         ELSE rtrim(x.FG_Customer)
                         end
      ,x.Qty
	FROM (
		-- Outside
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock),  [EDC].[dbo].[View_PackingImageFN] B  with(nolock) 
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  -- 5-20171006-TY33E171SE-2PH9E10F0A  -25
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock) , [EDC].[dbo].[View_PackingImageFN] B  with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)		 
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer


		-- Outside  20201213 virus crash
		union all
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		 and  A.FG_Valid = 'Y'
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer



		-- Jasont requet 2019/7/30
		union all		-- Outside
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode_His] A
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer


		) x

GO


