USE [RCS_New]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;


--報表53-內容測試-DataSet_300mmAfterCMPWIP(WIP_LINE_Non_Copper)
--報表54-內容測試-DataSet_300mmAfterCMPWIP(WIP_LINE_Copper)
--報表55-內容測試-DataSet_300mmAfterCMPWIP

with TempA as (
select N=440
union all 
select N+120 from TempA where N<1880
),

tempB as (
select 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempA
)

select 'Interval'=a.WIP_DATE
          ,a.WIP_LINE
          ,'Qty'=sum(a.WIP_QTY)
from FN_WIP_2HOUR a with(nolock), tempB b
where a.WIP_DATE=b.Interval
and (a.WIP_EQUID=670 or a.WIP_EQUID=663 or a.WIP_EQUID=680 or a.WIP_EQUID=755 or a.WIP_EQUID=810 or a.WIP_EQUID=811 or a.WIP_EQUID=815)  
-- group by a.WIP_DATE, a.WIP_LINE, a.WIP_EQUID


union all
select Interval, 'Non-Copper', 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 0 from tempB where getdate()>=Interval


GO

/*
執行時間為:20230725 10:59
產生結果如下 
Interval	            WIP_LINE	Qty
---------------------------------------------
2023-07-11 11:20:00.000	Copper	    1640
2023-07-12 05:20:00.000	Copper	    768
2023-07-11 09:20:00.000	Copper	    286
2023-07-11 11:20:00.000	Copper	    240
2023-07-12 05:20:00.000	Non-Copper	286
2023-07-11 07:20:00.000	Copper	    200
2023-07-11 13:20:00.000	Copper	    64
2023-07-11 07:20:00.000	Copper	    840
2023-07-12 01:20:00.000	Non-Copper	1773
2023-07-11 23:20:00.000	Non-Copper	189
2023-07-11 19:20:00.000	Non-Copper	432
2023-07-12 07:20:00.000	Non-Copper	542
2023-07-11 13:20:00.000	Non-Copper	405
2023-07-11 15:20:00.000	Copper	    613
2023-07-12 03:20:00.000	Copper	    2408
2023-07-11 07:20:00.000	Non-Copper	577
2023-07-12 05:20:00.000	Non-Copper	432
2023-07-11 11:20:00.000	Non-Copper	12
2023-07-11 11:20:00.000	Copper	    455
2023-07-11 09:20:00.000	Copper	    1585
2023-07-11 21:20:00.000	Non-Copper	286
2023-07-12 05:20:00.000	Copper	    2805
2023-07-11 13:20:00.000	Non-Copper	808
2023-07-11 19:20:00.000	Non-Copper	71
2023-07-11 15:20:00.000	Copper	    1794
2023-07-12 03:20:00.000	Non-Copper	204
2023-07-11 21:20:00.000	Non-Copper	1186
2023-07-12 01:20:00.000	Non-Copper	243
2023-07-11 17:20:00.000	Non-Copper	48
2023-07-11 07:20:00.000	Non-Copper	849
2023-07-11 21:20:00.000	Copper	    428
2023-07-12 03:20:00.000	Copper	    612
2023-07-12 07:20:00.000	Non-Copper	240
2023-07-11 13:20:00.000	Copper	    1732
2023-07-11 23:20:00.000	Copper	    612
2023-07-11 23:20:00.000	Non-Copper	71
2023-07-11 13:20:00.000	Non-Copper	1650
2023-07-11 23:20:00.000	Non-Copper	533
2023-07-12 07:20:00.000	Copper	    726
2023-07-12 07:20:00.000	Copper	    890
2023-07-11 07:20:00.000	Copper	    1715
2023-07-11 15:20:00.000	Copper	    2225
2023-07-11 09:20:00.000	Copper	    1577
2023-07-11 19:20:00.000	Non-Copper	106
2023-07-11 09:20:00.000	Non-Copper	603
2023-07-11 07:20:00.000	Copper	    286
2023-07-11 11:20:00.000	Copper	    2069
2023-07-12 01:20:00.000	Copper	    480
2023-07-11 17:20:00.000	Copper	    529
2023-07-11 19:20:00.000	Copper	    472
2023-07-11 21:20:00.000	Non-Copper	71
2023-07-11 15:20:00.000	Copper	    72
2023-07-11 13:20:00.000	Copper	    2112
2023-07-11 13:20:00.000	Non-Copper	4
2023-07-12 05:20:00.000	Non-Copper	124
2023-07-11 07:20:00.000	Non-Copper	957
2023-07-11 09:20:00.000	Copper	    72
2023-07-11 21:20:00.000	Non-Copper	432
2023-07-11 19:20:00.000	Non-Copper	737
2023-07-11 07:20:00.000	Non-Copper	392
2023-07-11 09:20:00.000	Non-Copper	812
2023-07-11 13:20:00.000	Copper	    399
2023-07-11 21:20:00.000	Copper	    178
2023-07-11 23:20:00.000	Non-Copper	233
2023-07-11 23:20:00.000	Non-Copper	1601
2023-07-12 07:20:00.000	Copper	    1955
2023-07-11 07:20:00.000	Copper	    503
2023-07-11 19:20:00.000	Copper	    178
2023-07-12 03:20:00.000	Non-Copper	495
2023-07-11 21:20:00.000	Copper	    1782
2023-07-12 03:20:00.000	Non-Copper	47
2023-07-12 05:20:00.000	Copper	    574
2023-07-11 09:20:00.000	Non-Copper	466
2023-07-11 11:20:00.000	Non-Copper	1646
2023-07-11 11:20:00.000	Copper	    108
2023-07-12 03:20:00.000	Non-Copper	251
2023-07-11 23:20:00.000	Copper	    2240
2023-07-12 01:20:00.000	Non-Copper	173
2023-07-11 17:20:00.000	Non-Copper	782
2023-07-11 21:20:00.000	Non-Copper	209
2023-07-11 17:20:00.000	Non-Copper	155
2023-07-12 03:20:00.000	Copper	    577
2023-07-11 15:20:00.000	Non-Copper	211
2023-07-11 17:20:00.000	Copper	    65
2023-07-12 01:20:00.000	Copper	    2799
2023-07-11 19:20:00.000	Copper	    1854
2023-07-12 07:20:00.000	Non-Copper	120
2023-07-11 17:20:00.000	Copper	    1710
2023-07-11 11:20:00.000	Non-Copper	4
2023-07-11 13:20:00.000	Copper	    120
2023-07-11 21:20:00.000	Copper	    567
2023-07-11 15:20:00.000	Non-Copper	855
2023-07-12 05:20:00.000	Copper	    1704
2023-07-11 19:20:00.000	Copper	    930
2023-07-12 01:20:00.000	Non-Copper	211
2023-07-11 19:20:00.000	Non-Copper	461
2023-07-11 09:20:00.000	Non-Copper	44
2023-07-12 07:20:00.000	Non-Copper	187
2023-07-11 21:20:00.000	Copper	    1655
2023-07-12 01:20:00.000	Copper	    521
2023-07-11 23:20:00.000	Copper	    497
2023-07-12 03:20:00.000	Non-Copper	1030
2023-07-12 07:20:00.000	Copper	    588
2023-07-12 03:20:00.000	Copper	    1679
2023-07-12 05:20:00.000	Non-Copper	1030
2023-07-12 01:20:00.000	Non-Copper	429
2023-07-11 23:20:00.000	Copper	    1741
2023-07-11 15:20:00.000	Non-Copper	925
2023-07-11 11:20:00.000	Non-Copper	898
2023-07-12 01:20:00.000	Copper	    49
2023-07-11 11:20:00.000	Non-Copper	368
2023-07-11 19:20:00.000	Copper	    352
2023-07-11 17:20:00.000	Non-Copper	858
2023-07-11 09:20:00.000	Copper	    478
2023-07-11 17:20:00.000	Copper	    96
2023-07-11 07:20:00.000	Non-Copper	330
2023-07-11 09:20:00.000	Non-Copper	1272
2023-07-12 01:20:00.000	Copper	    1682
2023-07-12 07:20:00.000	Non-Copper	365
2023-07-12 07:20:00.000	Copper	    212
2023-07-11 15:20:00.000	Copper	    422
2023-07-11 23:20:00.000	Copper	    24
2023-07-11 17:20:00.000	Non-Copper	47
2023-07-12 05:20:00.000	Non-Copper	240
2023-07-11 17:20:00.000	Copper	    2706
2023-07-11 07:20:00.000	Non-Copper	0
2023-07-11 09:20:00.000	Non-Copper	0
2023-07-11 11:20:00.000	Non-Copper	0
2023-07-11 13:20:00.000	Non-Copper	0
2023-07-11 15:20:00.000	Non-Copper	0
2023-07-11 17:20:00.000	Non-Copper	0
2023-07-11 19:20:00.000	Non-Copper	0
2023-07-11 21:20:00.000	Non-Copper	0
2023-07-11 23:20:00.000	Non-Copper	0
2023-07-12 01:20:00.000	Non-Copper	0
2023-07-12 03:20:00.000	Non-Copper	0
2023-07-12 05:20:00.000	Non-Copper	0
2023-07-12 07:20:00.000	Non-Copper	0
2023-07-11 07:20:00.000	Copper	    0
2023-07-11 09:20:00.000	Copper	    0
2023-07-11 11:20:00.000	Copper	    0
2023-07-11 13:20:00.000	Copper	    0
2023-07-11 15:20:00.000	Copper	    0
2023-07-11 17:20:00.000	Copper	    0
2023-07-11 19:20:00.000	Copper	    0
2023-07-11 21:20:00.000	Copper	    0
2023-07-11 23:20:00.000	Copper	    0
2023-07-12 01:20:00.000	Copper	    0
2023-07-12 03:20:00.000	Copper	    0
2023-07-12 05:20:00.000	Copper	    0
2023-07-12 07:20:00.000	Copper	    0
*/