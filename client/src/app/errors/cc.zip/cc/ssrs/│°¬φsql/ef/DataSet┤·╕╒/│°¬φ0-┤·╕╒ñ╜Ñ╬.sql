DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
DECLARE @TargetOutput200mm int;
SET @TargetOutput200mm = 2560;


-- select 'LotNo'=substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)
--           ,'HighT'=0
--           ,'HighQ'=0
--           ,'HighP'=0
--           ,'Normal'=-1*sum(MFG_MOVE)
--           ,'Low'=0
-- from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
-- where MFG_Date=convert(char(8), @YYYYMMDD, 112) 
-- and MFG_EQUID=810
-- and MFG_LOTNO like '%RR%'
-- and MFG_MOVE>0
-- group by substring(MFG_LOTNO, 1, 2)+'_'+substring(MFG_LOTNO, 5, 1)


-- select top(100) * 
-- from [RCS_NEW].[dbo].[FN_MANUFACTURE]
-- where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
-- and MANU_FROM_EQUID=680



select * 
from sap_sd_so_v 
where NETPR>0      -- ??
and VKORG='1100'   -- ?? 