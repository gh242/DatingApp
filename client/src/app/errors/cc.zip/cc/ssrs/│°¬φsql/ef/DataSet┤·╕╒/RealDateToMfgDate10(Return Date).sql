USE [WarInfo]
GO

/****** Object:  UserDefinedFunction [dbo].[RealDateToMfgDate10]    Script Date: 2023/7/27 上午 11:41:59 ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO



ALTER Function [dbo].[RealDateToMfgDate10](@RealDate DateTime) Returns Date
As  
Begin 
	 Return
		Case IsDate(@RealDate) 
	  		When 1 Then Cast(Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) As Date)
			Else Null
		End
End
GO


