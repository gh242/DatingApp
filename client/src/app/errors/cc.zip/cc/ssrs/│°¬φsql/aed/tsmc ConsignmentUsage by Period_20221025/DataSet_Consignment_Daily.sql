USE [WarInfo]
GO

DECLARE @StartDate SMALLDATETIME;
SET @StartDate = '20230701';
DECLARE @EndDate SMALLDATETIME;
SET @EndDate = '20230730';
DECLARE @Mode VARCHAR(2);
SET @Mode = 'A';

select 'BUDAT'=a.CRPDate
           ,'CustFabCode'=isnull(b.CustFabCode, 'N/A')
           ,'PN'=case when a.Product not like 'V600001%' and a.Product like '%[ABCNO]' then left(a.Product, len(a.Product)-1)+'A'
                      when a.Product not like 'V600001%' and a.Product like '%[ABCNO]_' then left(a.Product, len(a.Product)-2)+'A'
                      when a.Product like '%[DEF]' or  a.Product like '%[DEF]_' then 'Mechanical'
                      when a.Product like 'V600001%' then 'V600001'
                      when a.Product like '%P' then left(a.Product, len(a.Product)-1)+'P'
                      when a.Product like '%P_' then left(a.Product, len(a.Product)-2)+'P'
                      when a.Product like '%Q' then left(a.Product, len(a.Product)-1)+'Q'
                      when a.Product like '%T' then left(a.Product, len(a.Product)-1)+'T'
                      else a.Product 
                end
           ,cast(sum(a.GIQty) as integer) AS GIQTY 
from Customer_Consignment a with(nolock) 
    left join Customer_Master b with(nolock)
	            on a.Plant = b.CustFabCode
                 and a.MANDT = b.MANDT
                 and  a.PSI_Plant = b.SalesOrg --新增(FAB1&FAB3客戶JOIN)
where a.MANDT='888'
and a.is_holiday <> 'Y'
and a.CRPDate between @StartDate and @EndDate
and a.WaferSize IN(@P_SIZE)
and b.CustFabCode in (@FAB)
and a.Product in (@PN)
and (a.is_Billing<>'Y' or a.is_Billing is null)  -- 2022-05-24 add by FN
group by a.CRPDate, isnull(b.CustFabCode, 'N/A'), a.Product