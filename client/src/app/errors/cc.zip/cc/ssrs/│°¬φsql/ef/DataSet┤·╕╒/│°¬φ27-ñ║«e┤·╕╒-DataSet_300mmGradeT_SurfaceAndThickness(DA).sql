USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

--報表27-內容測試-DataSet_300mmGradeT_SurfaceAndThickness(DA)          參數不一樣 Process = DA
--與 報表30-內容測試-DataSet_300mmGradeT_SurfaceAndThickness(DP) 一樣, 參數不一樣 Process = DP
--與 報表34-內容測試-DataSet_300mmGradeT_SurfaceAndThickness(G) 一樣,  參數不一樣 Process like G*

--只是報表圖 參數不一樣
--報表25 呈現 Percentage, 報表26 呈現 Qty

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='DA'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
/*
執行時間為:20230719 16:19
產生結果如下 
Line	MFGDate	Process	ProcessThickness	Qty	Percentage
----------------------------------------------------------

*/
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='DP'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='GD'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
/*
執行時間為:20230719 16:19
產生結果如下 
Line	MFGDate	Process	ProcessThickness	Qty	Percentage
----------------------------------------------------------

*/
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='GP'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
/*
執行時間為:20230719 16:21
產生結果如下 
Line	    MFGDate	                Process	ProcessThickness	Qty	Percentage
-------------------------------------------------------------------------------------
Non-Copper	2023-07-12 00:00:00.000	GP	    S	                11	0.343750000000000
*/
)

-- 19nm Non-Copper
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='DA'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='DA'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
/*
執行時間為:20230719 16:23
產生結果如下 
MFGDate	            Line	    nm	    Process	ProcessThickness	Qty	    Percentage
--------------------------------------------------------------------------------------
2023-07-05 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-29 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-02 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-11 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-30 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-08 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-03 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-09 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-06 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-12 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-01 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-07 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-04 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-10 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-28 00:00:00	Non-Copper	19nm	DA	 	                    NULL	NULL
*/
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='DP'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='DP'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='GD'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='GD'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')

/*
執行時間為:20230719 16:23
產生結果如下 
MFGDate	            Line	    nm	    Process	ProcessThickness	Qty	    Percentage
--------------------------------------------------------------------------------------
2023-07-05 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-06-29 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-02 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-11 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-06-30 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-08 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-03 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-09 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-06 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-12 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-01 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-07 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-04 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-10 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
2023-06-28 00:00:00	Non-Copper	19nm	GD	 	                    NULL	NULL
*/
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='GP'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='GP'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
/*
執行時間為:20230719 16:23
產生結果如下 
MFGDate	            Line	    nm	    Process	ProcessThickness	Qty	    Percentage
---------------------------------------------------------------------------------------------
2023-07-12 00:00:00	Non-Copper	19nm	GP	    S	                11	    0.343750000000000
2023-07-05 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-06-29 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-02 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-11 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-06-30 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-08 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-03 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-09 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-06 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-01 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-07 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-04 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-07-10 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
2023-06-28 00:00:00	Non-Copper	19nm	GP	     	                NULL	NULL
*/
Go


/*
執行時間為:20230719 16:13
產生結果如下 
MFGDate	                Line	    nm	    Process	ProcessThickness	Qty	    Percentage
------------------------------------------------------------------------------------------
2023-07-05 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-29 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-02 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-11 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-30 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-08 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-03 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-09 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-06 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-12 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-01 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-07 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-04 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-07-10 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-28 00:00:00	    Non-Copper	19nm	DA	 	                    NULL	NULL
2023-06-29 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-05 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-02 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-11 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-08 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-06-30 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-03 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-09 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-06 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-12 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-01 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-04 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-06-28 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-07 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-07-10 00:00:00	    Non-Copper	19nm	DP	 	                    NULL	NULL
2023-06-28 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-06-29 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-06-30 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-01 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-02 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-03 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-04 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-05 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-06 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-07 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-08 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-09 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-10 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-11 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-12 00:00:00	    Non-Copper	19nm	GD	 	                    NULL	NULL
2023-07-12 00:00:00	    Non-Copper	19nm	GP	    S	                11	    0.343750000000000
2023-06-29 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-05 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-02 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-11 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-08 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-06-30 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-03 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-09 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-06 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-01 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-04 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-06-28 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-07 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
2023-07-10 00:00:00	    Non-Copper	19nm	GP	 	                    NULL	NULL
*/