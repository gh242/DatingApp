USE [RCS_New]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;
DECLARE @DailyNo int;
SET @DailyNo = 12;


with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, getdate()-1*@DailyNo, @YYYYMMDD) 
),

TempDay as (
select 'WIP_DATE'=cast(DateAdd(day, -1*N, @YYYYMMDD) as date)
from CTE
),

TempA as (
select 'WIP_DATE'=cast([WIP_DATE] as date)
      ,[WIP_EQUID]
      --,[WIP_LINE]
      ,'WIP_QTY'=sum([WIP_QTY])
from FN_WIP_2HOUR a with(nolock)
where [WIP_DATE]>=getdate()-14
and convert(char(8), [WIP_DATE], 108)='07:20:00'
group by cast([WIP_DATE] as date), [WIP_EQUID]--, [WIP_LINE]
)


select 'WIP_DATE'=dateadd(d, -1, b.WIP_DATE)
      --,a.WIP_LINE
      ,a.WIP_EQUID
      ,'Qty'=a.WIP_QTY
from TempDay b left join TempA a
               on a.WIP_DATE=b.WIP_DATE

GO