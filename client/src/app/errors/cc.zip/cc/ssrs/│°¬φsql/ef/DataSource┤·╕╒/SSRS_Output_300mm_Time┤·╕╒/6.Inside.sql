----------------------6.Inside---FG_MFGDate>'20150101'-----------------------------------------------------------------------
		-- Inside
		union all
		select 'Category'='Inside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'		  
		  and A.FG_MFGDate>'20150101'