/* Outside*/ SELECT 'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'MFGShift' = A.FG_MFGType, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
WHERE   A.FG_BarCode4 LIKE '[A-Z]%' AND A.FG_BarCode4 NOT LIKE 'PS_2M_%' /*12" Oxide*/ AND 
                   A.FG_BarCode4 NOT LIKE 'PS_6MZ%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE 'PS_8MZ%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE 'PSE8MT%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '[A-Z]___X_%' /*internal revenue*/ AND 
                   A.FG_BarCode4 NOT LIKE '[A-SU-Z]___[QVW]%' /*Oxide*/ AND 
                   A.FG_BarCode4 NOT LIKE 'P[BC]__S_%' /*and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知*/ AND 
                   A.FG_MFGDate > '20150101' AND A.FG_Valid = 'Y'
/* Inside*/ UNION ALL
SSRS_Output_200mm_TimeSELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'MFGShift' = A.FG_MFGType, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE 'PS_6MZ%' OR
                   A.FG_BarCode4 LIKE 'PS_8MZ%' OR
                   A.FG_BarCode4 LIKE 'PSE8MT%' OR
                   A.FG_BarCode4 LIKE '[A-Z]___X_%') /*and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知*/ AND 
                   A.FG_MFGDate > '20150101' AND A.FG_Valid = 'Y'