USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

-- 報表35-內容測試-DataSet_300mm555
-- 與 報表 40(815),45(700),50(680) 很像，MANU_FROM_EQUID 不同

-- with TempA as ( 
-- Non-Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Non-Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=680
and (MANU_FROM_LOTNO like '[1-9]___[EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

union all
-- Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=680
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0

/*
執行時間為:20230720 16:51
產生結果如下 
Print_Date	          Line	          Qty	Loss
-------------------------------------------------
2023-07-12 06:04:58.000	Non-Copper	4	0
2023-07-12 06:06:31.000	Non-Copper	12	0
2023-07-12 06:06:39.000	Non-Copper	11	0
2023-07-12 06:06:39.000	Non-Copper	12	0
2023-07-12 06:06:52.000	Non-Copper	11	0
2023-07-12 06:17:47.000	Non-Copper	12	0
2023-07-12 06:17:53.000	Non-Copper	12	0
2023-07-12 06:40:33.000	Non-Copper	12	0
2023-07-12 06:40:37.000	Non-Copper	12	0
2023-07-12 06:40:40.000	Non-Copper	12	0
2023-07-12 06:40:44.000	Non-Copper	12	0
2023-07-11 09:49:17.000	Copper	     0	2
2023-07-11 11:59:26.000	Copper	     0	1
2023-07-11 15:06:12.000	Copper	     0	2
2023-07-11 15:06:25.000	Copper	     0	1
2023-07-11 15:52:57.000	Copper	     0	1
2023-07-11 17:04:53.000	Copper	     0	1
2023-07-11 17:04:53.000	Copper	     0	2
2023-07-11 17:04:53.000	Copper	     0	6
2023-07-11 07:57:19.000	Copper	     12	0
2023-07-11 07:57:30.000	Copper	     12	0
2023-07-11 07:58:07.000	Copper	     12	0
2023-07-11 07:58:17.000	Copper	     11	0
2023-07-11 07:58:24.000	Copper	     12	0
2023-07-11 07:58:33.000	Copper	     12	0
2023-07-11 07:58:40.000	Copper	     12	0
2023-07-11 07:58:41.000	Copper	     12	0
2023-07-11 07:58:50.000	Copper	     12	0
2023-07-11 07:58:53.000	Copper	     12	0
...
共791筆
*/

-- )


-- select x.Interval
--          ,x.Line
--          ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
--                              else null 
--                              end 
--          ,'Loss'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Loss
--                              else null 
--                              end 
--          ,'TargetQty'=x.TargetQty/2
-- from (
-- select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--           ,'TargetQty'=1*@Stripper*@TargetOutput300mm/12   --1*1.05*12800/12
-- from TempA a
-- where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
--                a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
--                a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD) 
--             )
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=2*@Stripper*@TargetOutput300mm/12   --2*1.05*12800/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD)  and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=3*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=4*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=5*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=6*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=7*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=8*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=9*@Stripper*@TargetOutput300mm/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=10*@Stripper*@TargetOutput300mm/12   --10*1.05*12800/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=11*@Stripper*@TargetOutput300mm/12   --11*1.05*12800/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
-- group by a.Line

-- union all
-- select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) 
--           ,a.Line
--           ,'Qty'=sum(a.Qty)
--           ,'Loss'=sum(a.Loss)
--          ,'TargetQty'=12*@Stripper*@TargetOutput300mm/12   --12*1.05*12800/12
-- from TempA a
-- where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
-- group by a.Line
-- ) x


GO


/*
執行時間為:20230720 16:48
產生結果如下 
Interval	               Line	          Qty	     Loss	TargetQty
----------------------------------------------------------------
2023-07-11 09:20:00      Copper	     607	     0	560
2023-07-11 09:20:00      Non-Copper	47	     0	560
2023-07-11 11:20:00      Copper	     1154	     2	1120
2023-07-11 11:20:00      Non-Copper	109	     10	1120
2023-07-11 13:20:00      Copper	     1685	     3	1680
2023-07-11 13:20:00      Non-Copper	119	     12	1680
2023-07-11 15:20:00      Copper	     2294	     6	2240
2023-07-11 15:20:00      Non-Copper	119	     12	2240
2023-07-11 17:20:00      Copper	     3322	     16	2800
2023-07-11 17:20:00      Non-Copper	119	     12	2800
2023-07-11 19:20:00      Copper	     3756	     16	3360
2023-07-11 19:20:00      Non-Copper	143	     12	3360
2023-07-11 21:20:00      Copper	     4374	     16	3920
2023-07-11 21:20:00      Non-Copper	206	     13	3920
2023-07-11 23:20:00      Copper	     4917	     20	4480
2023-07-11 23:20:00      Non-Copper	381	     16	4480
2023-07-12 01:20:00      Copper	     5388	     29	5040
2023-07-12 01:20:00      Non-Copper	617	     17	5040
2023-07-12 03:20:00      Copper	     5792	     35	5600
2023-07-12 03:20:00      Non-Copper	940	     21	5600
2023-07-12 05:20:00      Copper	     6188	     39	6160
2023-07-12 05:20:00      Non-Copper	1507	     39	6160
2023-07-12 07:20:00      Copper	     6680	     42	6720
2023-07-12 07:20:00      Non-Copper	1724	     39	6720
*/