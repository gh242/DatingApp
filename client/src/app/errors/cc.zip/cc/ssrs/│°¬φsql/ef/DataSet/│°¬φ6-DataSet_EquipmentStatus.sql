with
t1 as (select * from EQPGROUP_MFG),
t2 as (select * from TBLEMSEQUIPMENTSTATE where EQUIPMENTSTATE not in ('1','21','22','23','31')),
t3 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, 0 as RN from
    (
        select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, rank() over(partition by EQUIPMENTNO order by STARTTIME, EQPSERIALNO) as RN from TBLEMSEQUIPMENTSTATELOG
        where STARTTIME <= sysdate-1 and ENDTIME > sysdate-1 
    ) a
    where a.RN=1
    union 
    select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, 0 as RN from TBLEMSEQUIPMENTSTATE 
         where STARTTIME < sysdate-1 
    union    
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, rank() over(partition by a.EQUIPMENTNO order by a.STARTTIME, a.EQPSERIALNO) as RN from
    (
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATELOG
        union
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATE
    ) a
    where a.STARTTIME > sysdate-1 and a.STARTTIME <= sysdate
),
k4 as (select * from TBLEQPEQUIPMENTBASIS),
f3 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, case when a.STARTTIME < sysdate-1 then sysdate-1 else a.STARTTIME end STARTTIME, nvl(a1.STARTTIME,sysdate) ENDTIME
    from (select * from t3) a
    left join (select * from t3) a1 on a.EQUIPMENTNO=a1.EQUIPMENTNO and a.RN=a1.RN-1
),
r3 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) YAT
from f3
where EQUIPMENTSTATE in ('0','1','21','22','23','31')
group by EQUIPMENTNO),
s3 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) YTT
from f3
group by EQUIPMENTNO),

t4 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, 0 as RN from
    (
        select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, rank() over(partition by EQUIPMENTNO order by STARTTIME, EQPSERIALNO) as RN from TBLEMSEQUIPMENTSTATELOG
        where STARTTIME <= :stime and ENDTIME > :stime 
    ) a
    where a.RN=1
    union 
    select EQUIPMENTNO, EQUIPMENTSTATE, STARTTIME, 0 as RN from TBLEMSEQUIPMENTSTATE
         where STARTTIME < :stime
    union    
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, a.STARTTIME, rank() over(partition by a.EQUIPMENTNO order by a.STARTTIME, a.EQPSERIALNO) as RN from
    (
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATELOG
        union
        select EQPSERIALNO, EQUIPMENTNO, EQUIPMENTSTATE, EQUIPMENTTYPE, STARTTIME from TBLEMSEQUIPMENTSTATE
    ) a
    where a.STARTTIME > :stime and a.STARTTIME <= sysdate
),
f4 as (
    select a.EQUIPMENTNO, a.EQUIPMENTSTATE, case when a.STARTTIME < :stime then :stime else a.STARTTIME end STARTTIME, nvl(a1.STARTTIME,sysdate) ENDTIME
    from (select * from t4) a
    left join (select * from t4) a1 on a.EQUIPMENTNO=a1.EQUIPMENTNO and a.RN=a1.RN-1
),
r4 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) MAT
from f4
where EQUIPMENTSTATE in ('0','1','21','22','23','31')
group by EQUIPMENTNO),
s4 as (
select EQUIPMENTNO, SUM(WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)) MTT
from f4
group by EQUIPMENTNO)

select t1.SEQUENCE, t1.EQUIPMENTNO, t1.STATION, t1.EQUIPMENTNAME,k4.DESCRIPTION, a.EQUIPMENTSTATE, b.STATENAME, t2.STARTTIME, r3.YAT, s3.YTT, r4.MAT, s4.MTT,
Case when a.EQUIPMENTSTATE in ('1','21','22','23','31') then '1'
when a.EQUIPMENTSTATE in ('0') then '0' else '2' end STATECOLOR
from TBLEMSEQUIPMENTSTATE a, TBLEQPSTATEBASIS b, t1
left join t2 on t1.EQUIPMENTNO = t2.EQUIPMENTNO
left join r3 on t1.EQUIPMENTNO = r3.EQUIPMENTNO
left join s3 on t1.EQUIPMENTNO = s3.EQUIPMENTNO
left join r4 on t1.EQUIPMENTNO = r4.EQUIPMENTNO
left join s4 on t1.EQUIPMENTNO = s4.EQUIPMENTNO
left join k4 on t1.EQUIPMENTNO = k4.EQUIPMENTNO
where a.EQUIPMENTNO = t1.EQUIPMENTNO and a.EQUIPMENTSTATE = b.EQUIPMENTSTATE
order by t1.SEQUENCE