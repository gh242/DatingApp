-- SELECT 'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                    + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'MFGShift' = A.FG_MFGType, 
--                    'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
-- FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
-- WHERE   A.FG_BarCode4 LIKE '[A-Z]%' AND A.FG_BarCode4 NOT LIKE 'PS_2M_%' /*12" Oxide*/ AND 
--                    A.FG_BarCode4 NOT LIKE 'PS_6MZ%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE 'PS_8MZ%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE 'PSE8MT%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE '[A-Z]___X_%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE '[A-SU-Z]___[QVW]%' /*Oxide*/ AND 
--                    A.FG_BarCode4 NOT LIKE 'P[BC]__S_%' /*and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss�q��*/ AND 
--                    A.FG_MFGDate > '20150101' AND A.FG_Valid = 'Y'

--�������ͤ��e
--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:20
--Category	MFG_Date				MFGDate	MFGShift	LotNo	Qty	Print_Date
----------------------------------------------------------------------------------------
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N3I1	25	2023-07-16 09:48:05.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N3I1	25	2023-07-16 11:01:02.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N3I1	25	2023-07-16 11:24:37.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N5I1	25	2023-07-16 12:06:23.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N5I1	25	2023-07-16 12:49:18.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N5I1	25	2023-07-16 14:48:42.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N5I1	25	2023-07-16 15:20:02.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    T6N5I1	25	2023-07-16 15:26:36.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    PCNNI1	25	2023-07-16 08:20:11.000
--Outside	2023-07-16 00:00:00.000	20230716	A	    PCNNI1	25	2023-07-16 09:04:26.000



--SSRS_Output_200mm_Time
--17843 �����

SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'MFGShift' = A.FG_MFGType, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE 'PS_6MZ%' OR
                   A.FG_BarCode4 LIKE 'PS_8MZ%' OR
                   A.FG_BarCode4 LIKE 'PSE8MT%' OR
                   A.FG_BarCode4 LIKE '[A-Z]___X_%') /*and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss�q��*/ AND 
                   A.FG_MFGDate > '20150101' AND A.FG_Valid = 'Y'

--Category	MFG_Date				MFGDate	MFGShift	LotNo	Qty	Print_Date
---------------------------------------------------------------------------------------
--Inside	2020-12-19 00:00:00.000	20201219	A	    DXKBX2	25	2020-12-19 16:31:40.000
--Inside	2020-12-19 00:00:00.000	20201219	A	    DXKBX2	25	2020-12-19 16:58:53.000
--Inside	2020-12-19 00:00:00.000	20201219	A	    DXKBX2	25	2020-12-19 17:23:00.000
--Inside	2020-12-19 00:00:00.000	20201219	A	    DXKBX2	25	2020-12-19 17:49:35.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 17:25:21.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 17:37:01.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 17:58:50.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 18:22:27.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 18:46:34.000
--Inside	2020-12-20 00:00:00.000	20201220	C	    DXKBX2	25	2020-12-20 19:09:13.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 20:32:30.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 20:55:49.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 21:18:25.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 21:40:13.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 22:27:29.000
--Inside	2020-12-20 00:00:00.000	20201220	B	    DXKBX2	25	2020-12-20 22:49:01.000
