USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with TempA as (
-- Non-Copper
select 'Line'='Non-Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,'PassT'=sum(case when WAFERGRADE='GRADET' then 1
                                        else 0
                                        end)
          ,'PassQ'=sum(case when WAFERGRADE='GRADEQ' then 1
                                        else 0
                                        end)
          ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20)
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner

/*
-- Copper
union all
select 'Line'='Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,'PassT'=sum(case when WAFERGRADE='GRADET' then 1
                                        else 0
                                        end)
          ,'PassQ'=sum(case when WAFERGRADE='GRADEQ' then 1
                                        else 0
                                        end)
          ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner
*/
)


select a.*
         ,'Fail'=a.Total-a.PassT-a.PassQ-a.PassP
          ,'YieldT'=1.0000*a.PassT/a.Total
          ,'YieldQ'=1.0000*a.PassQ/a.Total
          ,'YieldP'=1.0000*a.PassP/a.Total
from TempA a

GO