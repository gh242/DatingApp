USE [RCS_New]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;
DECLARE @DailyNo int;
SET @DailyNo = 12;


with TempA as (
select N=440
union all 
select N+120 from TempA where N<1880
),

tempB as (
select 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempA
)

select 'Interval'=a.WIP_DATE
          ,a.WIP_LINE
          ,a.WIP_EQUID
          ,'Qty'=sum(a.WIP_QTY)
from FN_WIP_2HOUR a with(nolock), tempB b
where a.WIP_DATE=b.Interval
group by a.WIP_DATE, a.WIP_LINE, a.WIP_EQUID


-- 670 preClean
union all
select Interval, 'Non-Copper', 670, 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 670, 0 from tempB where getdate()>=Interval

-- 680 Dark Room
union all
select Interval, 'Non-Copper', 680, 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 680, 0 from tempB where getdate()>=Interval

-- 755 Final Cleanre
union all
select Interval, 'Non-Copper', 755, 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 755, 0 from tempB where getdate()>=Interval

--810 Surface Scan
union all
select Interval, 'Non-Copper', 810, 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 810, 0 from tempB where getdate()>=Interval

-- 815 RPW350
union all
select Interval, 'Non-Copper', 815, 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 815, 0 from tempB where getdate()>=Interval


GO