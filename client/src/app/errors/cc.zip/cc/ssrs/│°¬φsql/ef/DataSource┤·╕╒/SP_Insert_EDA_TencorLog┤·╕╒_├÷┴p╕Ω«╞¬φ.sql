
select

--EDA_Tencorlog
SP_Insert_EDA_TencorLog測試_關聯資料表
SP_Insert_EDA_TencorLog
    1.[EDC].[dbo].[EDC_VIEW_810_Map_T7ID_FN](view)
        a.dbo.EDC_VIEW_810_Map(view)
            a-1.dbo.EDC_DATA_810
            a-2.dbo.EDC_DATA_810_Map
            a-3.dbo.EDC_VIEW_TBI(view)(1千6百萬多筆資料)
                a-3-1.dbo.EDC_DATA_823
            a-4.LEFT join [EDC].[dbo].[Equipment_List] on dbo.EDC_DATA_810.STATION_NAME = [EDC].[dbo].[Equipment_List].StationName
        b.dbo.EDC_DATA_RPW350
        c.dbo.Chart_SP_RPW350
        d.TableShot.dbo.View_SupplierACC ??
    2.[EDC].[dbo].[EDC_Map_Recipe] (依據StationName, Recipe, BeginTime塞ParticleSize1)


--報表3, 77
sap_sd_so_v (WarInfo同義字)(172.28.128.178)
