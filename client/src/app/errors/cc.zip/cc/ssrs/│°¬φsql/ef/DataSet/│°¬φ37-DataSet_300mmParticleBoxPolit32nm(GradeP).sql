USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with TempA as (
-- Copper
select 'Line'='Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
),

-- Non-Copper
TempB as (
select 'Line'='Non-Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product  not like '2_[BCDHLUYIS]%'
)


select distinct 'Line'='Copper', 'nm'='32nm', Polisher,  PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
from tempA with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='32nm',  Polisher,  PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
from tempB with(nolock)

GO