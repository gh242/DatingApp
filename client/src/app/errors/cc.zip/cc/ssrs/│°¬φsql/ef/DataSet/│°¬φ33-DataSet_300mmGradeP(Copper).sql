USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';


with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

TempA as (
select 'Line'='Copper'
          ,'Product'=left(Product, 1)+right(Product, 1)
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeP' then 1
	                      else 0
		      end)
          ,'Qty1'=sum(case when WaferGradeOriginal='GRADEP1' then 1
	                        else 0
		        end)
          ,'Percentage'=1.0000*sum(case when WaferGradeOriginal='GRADEP' then 1
	                                            else 0
		                             end) / Count(*)
          ,'Percentage1'=1.0000*sum(case when WaferGradeOriginal='GRADEP1' then 1
	                                            else 0
		                             end) / Count(*)
          ,'TotalQty'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
and LotID not like '2_____-P-%'
group by left(Product, 1)+right(Product, 1), dbo.RealDateToMfgDate(CollectionTime)

union all
select 'Line'='Non-Copper'
          ,'Product'=left(Product, 1)+right(Product, 1)
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeP' then 1
	                      else 0
		      end)
          ,'Qty1'=sum(case when WaferGradeOriginal='GRADEP1' then 1
	                        else 0
		        end)
          ,'Percentage'=1.0000*sum(case when WaferGradeOriginal='GRADEP' then 1
	                                            else 0
		                             end) / Count(*)
          ,'Percentage1'=1.0000*sum(case when WaferGradeOriginal='GRADEP1' then 1
	                                            else 0
		                             end) / Count(*)
          ,'TotalQty'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and LotID not like '2_____-P-%'
group by left(Product, 1)+right(Product, 1), dbo.RealDateToMfgDate(CollectionTime)
)


select a.MFGDate, b.Line, b.Product, b.Qty, b.Qty1, 'Percentage'=isnull(b.Percentage, 0), 'Percentage1'=isnull(b.Percentage1, 0),b.TotalQty
from TempDay a left join tempA b
                         on a.MFGDate=b.MFGDate


GO