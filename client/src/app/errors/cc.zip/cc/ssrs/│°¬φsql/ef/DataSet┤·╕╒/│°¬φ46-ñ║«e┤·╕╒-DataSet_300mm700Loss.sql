USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;


select 'Line'='Non-Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and (a.MANU_FROM_EQUID=700 or a.MANU_FROM_EQUID=701)
and (a.MANU_FROM_LOTNO like '____[EGJKFMNPX]%' or a.MANU_FROM_LOTNO like '6___X%')
and a.MANU_FROM_LOTNO not like '9V__E%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)

union all
select 'Line'='Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and (a.MANU_FROM_EQUID=700 or a.MANU_FROM_EQUID=701)
and (a.MANU_FROM_LOTNO like '____[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and a.MANU_FROM_LOTNO not like '6___X%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)


GO

/*
執行時間為:20230721 13:54
產生結果如下 
Line	    LotNo	DESCRIPTION	    Qty
--------------------------------------------
Non-Copper	2B_E	Broken(破片)	1
Non-Copper	52_E	Broken(破片)	2
Non-Copper	2A_E	Hold fro P.E.	1
Non-Copper	2A_X	Hold fro P.E.	325
Non-Copper	2H_X	Hold fro P.E.	530
Non-Copper	2A_E	HOLD-TTV	    13
Non-Copper	6A_E	HOLD-TTV	    2
Non-Copper	25_F	ID-MIX	        2
Non-Copper	2A_E	ID-MIX	        3
Non-Copper	52_E	ID-MIX	        29
Non-Copper	6A_E	ID-MIX	        1
Non-Copper	72_J	ID-MIX	        2
Non-Copper	26_J	P/N Type剔退	98
Non-Copper	2A_E	P/N Type剔退	114
Non-Copper	2Y_J	P/N Type剔退	3
Non-Copper	26_J	RES(阻值)	    18
Non-Copper	2A_E	RES(阻值)	    38
Non-Copper	2Y_J	RES(阻值)	    5
Non-Copper	52_E	RES(阻值)	    1
Non-Copper	25_F	THK(厚度不足)	1
Non-Copper	26_J	THK(厚度不足)	8
Non-Copper	2A_E	THK(厚度不足)	27
Non-Copper	2B_E	THK(厚度不足)	23
Non-Copper	2Y_J	THK(厚度不足)	5
Non-Copper	52_E	THK(厚度不足)	34
Non-Copper	6A_E	THK(厚度不足)	6
Non-Copper	72_J	THK(厚度不足)	35
Non-Copper	26_J	TTV過高	        18
Non-Copper	2A_E	TTV過高	        19
Non-Copper	2Y_J	TTV過高	        12
Non-Copper	52_E	TTV過高	        2
Non-Copper	72_J	TTV過高	        3
Non-Copper	25_F	Warp過高	    7
Non-Copper	26_J	Warp過高	    16
Non-Copper	2A_E	Warp過高	    192
Non-Copper	2B_E	Warp過高	    83
Non-Copper	2Y_J	Warp過高	    14
Non-Copper	52_E	Warp過高	    4
Non-Copper	6A_E	Warp過高	    4
Non-Copper	72_J	Warp過高	    5
Copper	26_C	Broken(破片)	    1
Copper	26_L	Broken(破片)	    2
Copper	2U_S	Broken(破片)	    2
Copper	26_C	Chip(缺角)	        1
Copper	24_U	ID-MIX	            2
Copper	26_C	ID-MIX	            26
Copper	2U_S	ID-MIX	            1
Copper	21_C	RES(阻值)	        3
Copper	24_U	RES(阻值)	        2
Copper	26_C	RES(阻值)	        30
Copper	2U_S	RES(阻值)	        50
Copper	21_C	THK(厚度不足)	    1
Copper	24_U	THK(厚度不足)	    376
Copper	26_C	THK(厚度不足)	    48
Copper	2U_S	THK(厚度不足)	    151
Copper	21_C	TTV過高	            6
Copper	24_U	TTV過高	            44
Copper	26_C	TTV過高	            42
Copper	26_L	TTV過高	            5
Copper	2U_S	TTV過高	            49
Copper	6A_C	TTV過高	            3
Copper	21_C	Warp過高	        8
Copper	24_U	Warp過高	        62
Copper	26_C	Warp過高	        135
Copper	26_L	Warp過高	        4
Copper	2U_S	Warp過高	        264
*/
