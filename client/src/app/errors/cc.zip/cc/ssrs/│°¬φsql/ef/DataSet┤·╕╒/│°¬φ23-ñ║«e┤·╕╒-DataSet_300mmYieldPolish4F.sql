USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

--報表19-DataSet_300mmYield4F
--報表23-DataSet_300mmYieldPolish4F

--與 報表19-內容測試-DataSet_300mmYield4F Dataset 相似
--只是報表圖 呈現不一樣
--報表23 呈現 Groups(Polisher), 報表19 呈現 Groups(PreCleaner+FinalCleanSide)

with TempA as (
-- Copper
select 'Line'='Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                           else 0
                      end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%'  then 1
                           else 0
                      end)
          ,'Total'=count(*)
-- select * 
from EDA_Tencorlog with(nolock)
where StationName not like 'TENCOR_1[123457]' -- 4F 不是TENCOR_1幾
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD)  --07:20
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1) -- 隔日07:20
and LotID like '[1-9]___[BCDHLUYIS]%' -- 第1碼是1到9，第5碼是 BCDHLUYIS 其中1碼
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher

/*
執行時間為:20230719 10:02
產生結果如下 
Line	Polisher	Pass	Mech	Total
------------------------------------------
Copper	13	        111	    32	    156
Copper	17	        94	    24	    132
Copper	5	        230	    15	    255
Copper	3	        125	    53	    186
Copper	10	        289	    0	    305
Copper	12	        150	    49	    211
Copper	15	        240	    50	    395
Copper	2	        154	    40	    213
Copper	14	        173	    53	    237
Copper	1	        193	    65	    270
Copper	7	        182	    75	    292
Copper	8	        0	    2	    3
Copper	6	        195	    43	    249
Copper	4	        188	    69	    306
Copper	11	        121	    53	    189
*/

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                           else 0
                      end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                           else 0
                      end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName not like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD)  --07:20
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1) -- 隔日07:20
and (LotID like '[1-9]%' or LotID like 'PS__M%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher

/*
執行時間為:20230719 10:02
產生結果如下 
Line	    Polisher	Pass	Mech	Total
----------------------------------------------
Non-Copper	26	        53	    13	    78
Non-Copper	23	        82	    15	    114
Non-Copper	19	        18	    5	    24
Non-Copper	28	        47	    29	    131
Non-Copper	20	        66	    21	    103
Non-Copper	21	        45	    16	    76
Non-Copper	22	        16	    20	    58
*/

)

select a.*
          ,'Yield'=1.0000*a.Pass/a.Total
from TempA a

GO

/*
執行時間為:20230719 09:39
產生結果如下 
Line	    Polisher	Pass	Mech	Total	Yield
-----------------------------------------------------------------
Copper	    13	        111	    32	    156	    0.711538461538461
Copper	    17	        94	    24	    132	    0.712121212121212
Copper	    5	        230	    15	    255	    0.901960784313725
Copper	    3	        125	    53	    186	    0.672043010752688
Copper	    10	        289	    0	    305	    0.947540983606557
Copper	    12	        150	    49	    211	    0.710900473933649
Copper	    6	        195	    43	    249	    0.783132530120481
Copper	    14	        173	    53	    237	    0.729957805907172
Copper	    2	        154	    40	    213	    0.723004694835680
Copper	    1	        193	    65	    270	    0.714814814814814
Copper	    7	        182	    75	    292	    0.623287671232876
Copper	    8	        0	    2	    3	    0.000000000000000
Copper	    15	        240	    50	    395	    0.607594936708860
Copper	    4	        188	    69	    306	    0.614379084967320
Copper	    11	        121	    53	    189	    0.640211640211640
Non-Copper	19	        18	    5	    24	    0.750000000000000
Non-Copper	28	        47	    29	    131	    0.358778625954198
Non-Copper	21	        45	    16	    76	    0.592105263157894
Non-Copper	22	        16	    20	    58	    0.275862068965517
Non-Copper	23	        82	    15	    114	    0.719298245614035
Non-Copper	26	        53	    13	    78	    0.679487179487179
Non-Copper	20	        66	    21	    103	    0.640776699029126
*/