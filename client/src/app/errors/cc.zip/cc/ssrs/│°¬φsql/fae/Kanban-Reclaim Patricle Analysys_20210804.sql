
USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @nm int;
SET @nm = 32;
DECLARE @DailyNo VARCHAR(12);
SET @DailyNo = '14';
DECLARE @Yaxis VARCHAR(5);
SET @Yaxis = 'Qty';


/*
with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*@DailyNo, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=cast(DateAdd(day, -1*N, @YYYYMMDD) as date) from CTE
),
*/

with TempA as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                       when @nm=32 then 'GradeP'
                                       when @nm=26 then 'GradeQ'
                                       when @nm=19 then 'GradeT'
                                       end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '2___[CBDUXHILYMS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
),

TempCleaner as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '2___[CBDUXHILYMS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=PreCleaner+'+'+FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
),

TempPolisher as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=' All'
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '2___[CBDUXHILYMS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=cast(Polisher as varchar)
          ,'Cleaner'=' All'
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
),

TempAll as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=' All'
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '2___[CBDUXHILYMS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=[dbo].[RealDateToMfgDate](CollectionTime)
          ,'Polisher'=' All'
          ,'Cleaner'=' All'
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ParticleSize1=@nm
and WaferGrade=case when @nm=88 then 'GradeA'
                                   when @nm=32 then 'GradeP'
                                   when @nm=26 then 'GradeQ'
                                   when @nm=19 then 'GradeT'
                                   end
and CollectionTime>=DateAdd(n, 440-1440*@DailyNo, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '2___[CBDUXHILYMS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
)



select Line
          ,MFGDate
          ,Polisher
          ,Cleaner
          ,'Box_Max'=max(ParticleCount1)
          ,'Box_Min'=min(ParticleCount1)
          ,'Box_Avg'=avg(ParticleCount1)
          ,'Box_StDev'=case when @Yaxis='Qty' then Count(*)
                                          else stdev(ParticleCount1)
                                          end
from tempA with(nolock)
group by Line, MFGDate, Polisher, Cleaner
union all
select Line
          ,MFGDate
          ,Polisher
          ,Cleaner
          ,'Box_Max'=max(ParticleCount1)
          ,'Box_Min'=min(ParticleCount1)
          ,'Box_Avg'=avg(ParticleCount1)
          ,'Box_StDev'=case when @Yaxis='Qty' then Count(*)
                                          else stdev(ParticleCount1)
                                          end
from TempCleaner with(nolock)
group by Line, MFGDate, Polisher, Cleaner
union all
select Line
          ,MFGDate
          ,Polisher
          ,Cleaner
          ,'Box_Max'=max(ParticleCount1)
          ,'Box_Min'=min(ParticleCount1)
          ,'Box_Avg'=avg(ParticleCount1)
          ,'Box_StDev'=case when @Yaxis='Qty' then Count(*)
                                          else stdev(ParticleCount1)
                                          end
from TempPolisher with(nolock)
group by Line, MFGDate, Polisher, Cleaner

union all
select Line
          ,MFGDate
          ,Polisher
          ,Cleaner
          ,'Box_Max'=max(ParticleCount1)
          ,'Box_Min'=min(ParticleCount1)
          ,'Box_Avg'=avg(ParticleCount1)
          ,'Box_StDev'=case when @Yaxis='Qty' then Count(*)
                                          else stdev(ParticleCount1)
                                          end
from TempAll with(nolock)
group by Line, MFGDate, Polisher, Cleaner



GO