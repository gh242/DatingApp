DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
DECLARE @TargetOutput200mm int;
SET @TargetOutput200mm = 2560;


/*
select Print_Date
         ,Qty
from SSRS_Output_200mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
union all
select 'Print_Date'=DateAdd(n, 1760, @YYYYMMDD)
          ,'QTY'=-1*MANU_QTY
from [RCS_200mm].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'
and MANU_FROM_LOTNO not like '[A-Z]___[QWV]%'
AND MANU_FMLB='M'
and MANU_QTY>0
*/


--with TempB as (
--select N=440+120+120
--union all 
--select N+120 from TempB where N<1880
--)
--select * from TempB

--N
------
--680
--800
--920
--1040
--1160
--1280
--1400
--1520
--1640
--1760
--1880

with
TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),
tempC as (
select 'N'=(N-440)/120*@TargetOutput200mm/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)
select * from tempC

--N		Interval
-------	------
--426	2023-07-04 11:20:00
--640	2023-07-04 13:20:00
--853	2023-07-04 15:20:00
--1066	2023-07-04 17:20:00
--1280	2023-07-04 19:20:00
--1493	2023-07-04 21:20:00
--1706	2023-07-04 23:20:00
--1920	2023-07-05 01:20:00
--2133	2023-07-05 03:20:00
--2346	2023-07-05 05:20:00
--2560	2023-07-05 07:20:00