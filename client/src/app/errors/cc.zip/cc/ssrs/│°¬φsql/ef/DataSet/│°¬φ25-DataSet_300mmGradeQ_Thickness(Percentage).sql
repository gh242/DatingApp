USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

/*
-- Copper
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[CBDUXHILYMS]'
group by dbo.RealDateToMfgDate(CollectionTime)
),
*/

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime), ProcessThickness
/*
--all 
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'ProcessThickness'='All'
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime)
*/
)

-- 26nm Non-Copper
select a.MFGDate, 'Line'='Non-Copper', 'nm'='26nm', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate

/*
-- 26nm Copper
union all
select a.MFGDate, 'Line'='Copper', 'nm'='26nm', b.Qty, b.Percentage
from TempDay a left join tempC b
                         on a.MFGDate=b.MFGDate
*/

GO

/*
執行時間為:20230719 15:46
產生結果如下 
MFGDate	                Line	    nm	    ProcessThickness	Qty 	Percentage
-----------------------------------------------------------------------------------------
2023-07-04 00:00:00	    Non-Copper	26nm	A	                122	    0.628865979381443
2023-07-02 00:00:00	    Non-Copper	26nm	S	                336	    0.588441330998248
2023-07-09 00:00:00	    Non-Copper	26nm	S	                254	    0.594847775175644
2023-07-03 00:00:00	    Non-Copper	26nm	Y	                84	    0.567567567567567
2023-07-07 00:00:00	    Non-Copper	26nm	S	                93	    0.756097560975609
2023-07-09 00:00:00	    Non-Copper	26nm	A	                245	    0.610972568578553
2023-07-02 00:00:00	    Non-Copper	26nm	A	                251	    0.622828784119106
2023-06-30 00:00:00	    Non-Copper	26nm	S	                17	    0.708333333333333
2023-07-08 00:00:00	    Non-Copper	26nm	A	                30	    0.434782608695652
2023-07-11 00:00:00	    Non-Copper	26nm	S	                34	    0.871794871794871
2023-06-29 00:00:00	    Non-Copper	26nm	S	                362	    0.510578279266572
2023-07-06 00:00:00	    Non-Copper	26nm	A	                183	    0.536656891495601
2023-06-29 00:00:00	    Non-Copper	26nm	A	                129	    0.339473684210526
2023-07-04 00:00:00	    Non-Copper	26nm	S	                464	    0.745980707395498
2023-07-05 00:00:00	    Non-Copper	26nm	A	                210	    0.596590909090909
2023-06-28 00:00:00	    Non-Copper	26nm	A	                21	    0.437500000000000
2023-07-08 00:00:00	    Non-Copper	26nm	S	                29	    0.381578947368421
2023-07-10 00:00:00	    Non-Copper	26nm	A	                161	    0.522727272727272
2023-07-01 00:00:00	    Non-Copper	26nm	S	                9	    0.375000000000000
2023-07-03 00:00:00	    Non-Copper	26nm	A	                243	    0.642857142857142
2023-07-06 00:00:00	    Non-Copper	26nm	S	                159	    0.630952380952380
2023-07-05 00:00:00	    Non-Copper	26nm	S	                325	    0.679916317991631
2023-07-07 00:00:00	    Non-Copper	26nm	A	                30	    0.468750000000000
2023-06-29 00:00:00	    Non-Copper	26nm	Y	                0	    0.000000000000000
2023-07-03 00:00:00	    Non-Copper	26nm	S	                511	    0.702888583218707
2023-07-10 00:00:00	    Non-Copper	26nm	S	                349	    0.706477732793522
2023-06-28 00:00:00	    Non-Copper	26nm	S	                405	    0.731046931407942
2023-07-12 00:00:00	    Non-Copper	26nm	X	                NULL	NULL
*/