USE [WarInfo]
GO

/****** Object:  UserDefinedFunction [dbo].[RealDateToMfgDate]    Script Date: 2023/7/27 上午 11:44:13 ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


ALTER Function [dbo].[RealDateToMfgDate](@RealDate DateTime) Returns DateTime 
As  
Begin 
	 Return
		Case IsDate(@RealDate) 
	  		When 1 Then Cast(Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) As DateTime)
			Else Null
		End
End
GO