USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

--報表42-內容測試-DataSet_300mmPolisherParticleBoxpolit(GradeP GradeA)
--報表37-內容測試-DataSet_300mmParticleBoxPolit32nm(GradeP)
--報表17-內容測試-DataSet_300mmParticleBoxPolit26nm(GradeQ)
--報表5-內容測試-DataSet_300mmParticleBoxPolit19nm(GradeT)

--報表47-DataSet_300mmCleanerParticleBoxPolit
--報表52-DataSet_300mmCleanerParticleBoxPolit

with TempA as (
-- Copper
select 
-- *
'Line'='Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[BCDHLUYIS]%'
/*
執行時間為:20230724 9:20
產生結果如下 
Line	Polisher	PreCleaner	FinalCleaner	ParticleCount1
--------------------------------------------------------------
Copper	27	        Ebara3L	    ACM1	        115
Copper	27	        Ebara3L	    ACM1	        108
Copper	27	        Ebara3L	    ACM1	        130
Copper	24	        Ebara3R	    ACM1	        32
Copper	24	        Ebara3R	    ACM1	        54
Copper	24	        Ebara3R	    ACM1	        36
Copper	24	        Ebara3R	    ACM1	        35
Copper	24	        Ebara3R	    ACM1	        32
Copper	24	        Ebara3R	    ACM1	        29
Copper	24	        Ebara3R	    ACM1	        23
Copper	24	        Ebara3R	    ACM1	        96
...
938筆
*/
),

-- -- Non-Copper
TempB as (
select 'Line'='Non-Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,ParticleCount1
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 30 and 32 )
and WaferGrade='GradeP'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product  not like '2_[BCDHLUYIS]%'
/*
執行時間為:20230725 9:26
產生結果如下 
Line	    Polisher	PreCleaner	FinalCleaner	ParticleCount1
--------------------------------------------------------------
Non-Copper	18	        Ebara4L	    ACM1	        51
Non-Copper	18	        Ebara4L	    ACM1	        35
Non-Copper	18	        Ebara4L	    ACM1	        38
Non-Copper	18	        Ebara4L	    ACM1	        33
Non-Copper	18	        Ebara4L	    ACM1	        44
Non-Copper	18	        Ebara4L	    ACM1	        29
Non-Copper	18	        Ebara4L	    ACM1	        179
Non-Copper	18	        Ebara4L	    ACM1	        34
Non-Copper	18	        Ebara4L	    ACM1	        57
Non-Copper	18	        Ebara4L	    ACM1	        17
Non-Copper	18	        Ebara4L	    ACM1	        33
Non-Copper	18	        Ebara4L	    ACM1	        87
...
405筆
*/
)


select distinct 'Line'='Copper', 'nm'='32nm', Polisher,  PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
from tempA with(nolock)

union all
select distinct'Line'='Non-Copper', 'nm'='32nm',  Polisher,  PreCleaner, FinalCleaner
      ,'Box_Max'=max(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Min'=min(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_Avg'=avg(ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner)
      ,'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_50'=(PERCENTILE_CONT(0.50) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
      ,'Box_25'=(PERCENTILE_CONT(0.25) within group (order by ParticleCount1) over (partition by Polisher, PreCleaner, FinalCleaner))
from tempB with(nolock)

GO

/*
執行時間為:20230725 9:36
產生結果如下 
Line	    nm	    Polisher	PreCleaner	FinalCleaner	Box_Max	Box_Min	Box_Avg	Box_75	Box_50	Box_25
--------------------------------------------------------------------------------------------------------------
Copper	    32nm	17	        FC3L	    SC2	            192	    131	    161	    176.75	161.5	146.25
Copper	    32nm	17	        FC3R	    SC2	            128	    104	    113	    118	    108	    106
Copper	    32nm	27	        Ebara3L	    ACM1	        181	    12	    43	    45.75	32	    24
Copper	    32nm	27	        Ebara3R	    ACM1	        167	    15	    38	    40.25	32	    27
Copper	    32nm	12	        FC3L	    SC2	            198	    148	    183	    196.5	193	    179.5
Copper	    32nm	12	        FC3R	    SC2	            186	    95	    144	    161	    142	    139
Copper	    32nm	17	        Ebara1R	    ACM1	        198	    44	    96	    116.5	90	    68.75
Copper	    32nm	24	        Ebara3L	    ACM1	        149	    6	    25	    29	    21	    17
Copper	    32nm	25	        Ebara3L	    ACM1	        126	    17	    36	    42.25	32.5	27
Copper	    32nm	24	        Ebara3R	    ACM1	        120	    12	    32	    36	    28.5	23
Copper	    32nm	12	        Ebara1R	    ACM1	        190	    25	    73	    89.5	64	    50.5
Copper	    32nm	8	        Ebara1L	    ACM1	        199	    75	    114	    126	    102.5	93.25
Copper	    32nm	8	        Ebara1R	    ACM1	        190	    28	    75	    93	    66	    51
Copper	    32nm	25	        Ebara3R	    ACM1	        190	    21	    50	    56	    45.5	36.25
Copper	    32nm	17	        Ebara1L	    ACM1	        199	    69	    131	    163	    130	    99
Non-Copper	32nm	20	        SCC1D	    ACM1	        152	    80	    120	    133.75	126	    107.75
Non-Copper	32nm	18	        SCC1C	    NULL	        122	    29	    49	    48.5	42.5	36.75
Non-Copper	32nm	19	        SCC1C	    ACM1	        141	    17	    53	    62	    48	    36
Non-Copper	32nm	19	        SCC1D	    ACM1	        137	    23	    55	    67.25	53	    39.75
Non-Copper	32nm	19	        SCC1B	    ACM1	        133	    33	    64	    76.5	49	    44.5
Non-Copper	32nm	20	        SCC1B	    ACM1	        167	    42	    87	    114	    78	    59
Non-Copper	32nm	18	        SCC1C	    ACM1	        138	    30	    74	    98	    75	    45.25
Non-Copper	32nm	19	        Ebara4L	    ACM1	        75	    17	    34	    40.25	30	    22.25
Non-Copper	32nm	19	        SCC1A	    ACM1	        57	    24	    36	    38.75	37	    31.25
Non-Copper	32nm	-23	        Ebara1R	 	                149	    57	    96	    105.5	93.5	78.5
Non-Copper	32nm	18	        SCC1A	    ACM1	        189	    18	    72	    95	    70	    41.5
Non-Copper	32nm	18	        SCC1B	    ACM1	        142	    13	    58	    75	    55.5	31.75
Non-Copper	32nm	20	        SCC1A	    ACM1	        177	    47	    88	    107.5	73.5	68.5
Non-Copper	32nm	18	        SCC1D	    ACM1	        119	    24	    52	    56	    45	    37
Non-Copper	32nm	20	        SCC1C	    ACM1	        170	    57	    100	    119	    90.5	70.25
Non-Copper	32nm	18	        Ebara4R	    ACM1	        133	    7	    46	    57	    30	    24.5
Non-Copper	32nm	-23	        N-	        NULL	        144	    79	    111	    127.75	111.5	95.25
Non-Copper	32nm	18	        Ebara4L	    ACM1	        179	    17	    50	    58.5	43	    31
*/