USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230718';

-- DECLARE @MANU_REALDATE nvarchar(10);
-- SET @MANU_REALDATE = '20230718';

-- 宣告純量變數
declare @MANU_REALDATE varchar(50) = '20230718';
declare @WIP_DATE SMALLDATETIME = '2020-04-20 09:20:00.000';

DECLARE @MANU_ENDTIME nvarchar(10);
SET @MANU_ENDTIME = '080313';





-- select Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) -- 2023/07/03

-- select DateAdd(n, 440, @YYYYMMDD) ; -- 2023-07-17 07:20:00
-- select DateAdd(n, 560, @YYYYMMDD)  ;-- 2023-07-17 09:20:00
-- select DateAdd(n, 1760, @YYYYMMDD);  -- 2023-07-18 05:20:00
-- select DateAdd(n, 1880, @YYYYMMDD) ; -- 2023-07-18 07:20:00

-- select DateAdd(n, 440, @RealDate-14); --2023-06-20 07:20:00
-- select DateAdd(n, 440, @RealDate+1)	  -- 2023-07-05 07:20:00

-----SELECT convert(varchar, getdate(), 108) - hh:mm:ss
select convert(char(8), @WIP_DATE, 108) -- 09:20:00


-------------Oracle wf3000
-----------FUN_DATEDIFFSECOND  函數功能：時間相減

-- WF3000.FUN_DATEDIFFSECOND(ENDTIME, STARTTIME)
/*
create or replace FUNCTION  FUN_DATEDIFFSECOND
( EndTime IN Date, StartTime in Date
) RETURN int AS
BEGIN
    RETURN 24*60*60*(EndTime-StartTime)+1;
END  FUN_DATEDIFFSECOND;
*/

--------RealDateToMfgDate----
-- 回傳 DateTime
--函數位置：資料表\可程式性\函數\純量值函數
--功能：減7小時20分，取年月日格式(yyyy/mm/dd)
-- [dbo].[RealDateToMfgDate]
-- dbo.RealDateToMfgDate(CollectionTime) -- 減440分，取年月日格式(yyyy/mm/dd)
/*
ALTER Function [dbo].[RealDateToMfgDate](@RealDate DateTime) Returns DateTime 
As  
Begin 
	 Return
		Case IsDate(@RealDate) 			----SELECT convert(varchar, getdate(), 111) - yyyy/mm/dd
	  		When 1 Then Cast(Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) As DateTime)
			Else Null
		End
End
*/

--------RealDateToMfgDate10----
-- 回傳 Date
/*
ALTER Function [dbo].[RealDateToMfgDate10](@RealDate DateTime) Returns Date
As  
Begin 
	 Return
		Case IsDate(@RealDate) 
	  		When 1 Then Cast(Convert(VarChar(10), DateAdd(minute, -440, @RealDate), 111) As Date)
			Else Null
		End
End
GO
*/


--報表15
--where MFG_Date between convert(char(8), @YYYYMMDD-Day(@YYYYMMDD)+1, 112)  and convert(char(8), @YYYYMMDD, 112) 
-- select
-- left(convert(char(8), @YYYYMMDD, 112), 6)+'01'
-- --20230701

-- select
-- convert(char(8), @YYYYMMDD-Day(@YYYYMMDD)+1, 112)
-- --20230701

-- select 
-- convert(char(8), @YYYYMMDD, 112) 
-- --20230718

-- select 
-- DateAdd(n, 440, @YYYYMMDD-14) 
-- --2023-07-04 07:20:00
-- select 
-- DateAdd(n, 440, @YYYYMMDD+1) 
-- --2023-07-19 07:20:00

-- select
-- DateAdd(mi, 1880, @YYYYMMDD)   --加31小時20分
--2023-07-19 07:20:00

--報表28
-- cast
-- cast(Polisher as varchar)
-- 這些函式會將某種資料類型的運算式轉換成另一種資料類型。

--報表31
-- select 
-- cast(left(@MANU_REALDATE, 4)
--                            +'-'+substring(@MANU_REALDATE, 5, 2)
--                            +'-'+right(@MANU_REALDATE, 2)
--                            +' '+left(@MANU_ENDTIME, 2)
--                            +':'+substring(@MANU_ENDTIME, 3, 2)
--                            +':'+right(@MANU_ENDTIME, 2) as DateTime)
-- 2023-07-18 08:03:13.000  (cast ... as DateTime)