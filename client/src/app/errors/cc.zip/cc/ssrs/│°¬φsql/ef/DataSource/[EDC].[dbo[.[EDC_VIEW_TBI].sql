USE [EDC]
GO

/****** Object:  View [dbo].[EDC_VIEW_TBI]    Script Date: 2023/7/26 下午 01:26:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


































ALTER VIEW [dbo].[EDC_VIEW_TBI]
AS
SELECT     StationName, CollectionTime, SrcSlotID, DFNDefectBinLimits_19 As DestPortID, DestSlotID, 

		--EDC.dbo.tsmcNewLotID(CollectionTime,
		--20180307 add %-%-%-% for Remote Run
		(CASE WHEN LotID IS NULL THEN 'TEST' WHEN LTrim(LotID) LIKE 'EG-%' OR LotID LIKE '%SPC%' OR LotID LIKE '%TEST%' OR LotID LIKE '%-%-%-%' THEN LotID 
			 WHEN Len(LotID) >= 21 AND (LTrim(LotID) LIKE '[1-9]%' OR LTrim(LotID) LIKE 'PS_2%' OR LTrim(LotID) LIKE 'PSXCEX%') AND Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND Substring(LotID, Charindex('-', LotID) + 8, 1) NOT LIKE '[KSTA]' THEN 
				CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 3, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 8 + 1) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 8 + 1) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 8 + 1) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 8 + 1) 
					 ELSE LotID 
					 END 
			 WHEN Len(LotID) = 18 AND (LTrim(LotID) LIKE '[1-9]%' OR LTrim(LotID) LIKE 'PS_2%' OR LTrim(LotID) LIKE 'PSXCEX%') AND Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND Substring(LotID, Charindex('-', LotID) + 8, 1) NOT LIKE '[KSTA]' THEN 
				CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 3, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
					 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
					 ELSE LotID 
					 END 
			 WHEN Len(LotID) >= 28 AND (LTrim(LotID) LIKE '[1-9]%' OR LTrim(LotID) LIKE 'PS_2%' OR LTrim(LotID) LIKE 'PSXCEX%') AND Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND Substring(LotID, Charindex('-', LotID) + 8, 1) LIKE '[KSTA]' THEN 
				CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND SrcSlotID <= 12 THEN 
						CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 3, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 ELSE LotID 
							 END 
					 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) LIKE '[KSTA]' AND SrcSlotID > 12 THEN 
						CASE WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 10, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) + '-' + RIGHT(LotID, Len(LotID) - Charindex('-', LotID) - 15 + 1) 
							 ELSE LotID 
							 END 
					 ELSE LotID 
					 END 
			 WHEN Len(LotID) >= 25 AND (LTrim(LotID) LIKE '[1-9]%' OR LTrim(LotID) LIKE 'PS_2%' OR LTrim(LotID) LIKE 'PSXCEX%') AND Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND Substring(LotID, Charindex('-', LotID) + 8, 1) LIKE '[KSTA]' THEN 
				CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) LIKE '[KSTA]' AND SrcSlotID <= 12 THEN 
						CASE WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 3, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 1, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 2, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 5, 3) 
							 ELSE LotID 
							 END 
					 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) LIKE '[KSTA]' AND SrcSlotID > 12 THEN 
						CASE WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'K' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 10, 2) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'S' THEN LEFT(LotID, Charindex('-', LotID)) + 'S' + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'T' THEN LEFT(LotID, Charindex('-', LotID)) + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) 
							 WHEN Substring(LotID, Charindex('-', LotID) + 8, 1) = 'A' THEN LEFT(LotID, Charindex('-', LotID)) + 'A' + Substring(LotID, Charindex('-', LotID) + 9, 3) + '-J' + Substring(LotID, Charindex('-', LotID) + 12, 3) 
							 ELSE LotID 
							 END 
					 ELSE LotID 
					 END 
			 ELSE LotID 
			 END) AS LotID, 
                     
                      EdgeExclusion, 
                      CASE WHEN DataCollectType = '1' AND (EDC_DATA_823.StationName LIKE 'TENCOR_0[14568]' Or EDC_DATA_823.StationName LIKE 'TENCOR_14') THEN 'OBLIQUE' WHEN DataCollectType = '0' AND 
                      (EDC_DATA_823.StationName LIKE 'TENCOR_0[14568]' Or EDC_DATA_823.StationName LIKE 'TENCOR_14')  THEN 'NORMAL' WHEN DataCollectType = '0' AND (EDC_DATA_823.StationName = 'TENCOR_07' OR
                      EDC_DATA_823.StationName = 'TENCOR_09' OR EDC_DATA_823.StationName = 'TENCOR_11' OR EDC_DATA_823.StationName = 'TENCOR_15') THEN 'OBLIQUE' WHEN DataCollectType = '1' AND (EDC_DATA_823.StationName = 'TENCOR_07' OR
                      EDC_DATA_823.StationName = 'TENCOR_09' OR EDC_DATA_823.StationName = 'TENCOR_11' OR EDC_DATA_823.StationName = 'TENCOR_15') THEN 'NORMAL' ELSE 'ERROR' END AS LaserType, 
                      CASE WHEN DispositionName = 'GRADE A' THEN 'GRADEA' WHEN DispositionName = 'GRADE B' THEN 'GRADEB' WHEN DispositionName = 'GRADE C' THEN 'GRADEC'
                       WHEN DispositionName = 'GRADE D' THEN 'GRADED' WHEN DispositionName = 'GRADE E' THEN 'GRADEE' WHEN DispositionName = 'GRADE F' THEN 'GRADEF' WHEN
                       DispositionName = 'GRADE%F_' THEN 'GRADEF' WHEN DispositionName LIKE 'GRADEA%' THEN 'GRADEA' WHEN RecipeName = 'MX216-5G' AND 
                      DispositionName LIKE 'GRADEG%' THEN 'GRADEG' 
					  WHEN EDC_DATA_823.StationName = 'TENCOR_01' AND (RecipeName = 'T3E-TD1G' OR
                      RecipeName = 'T3E-XD1G' OR
                      RecipeName = 'T6E-TXG' OR
                      RecipeName = 'T6E-YZDG' OR
					  RecipeName = 'T6E-XPG-DCN' OR--20200205 T6E-G
					  RecipeName = 'T6E-TPG-DCN' OR--20200205 T6E-G
					  RecipeName = 'T6L-TPG-DCN' OR--20200205 T6L-G
					  RecipeName = 'T6L-XPG-DCN' OR--20200205 T6L-G
					  RecipeName LIKE 'T6E-[YZ]PDG-DCN' OR
					  RecipeName LIKE 'T6L-[YZ]PDG-DCN' OR
                      RecipeName LIKE 'T4E-T5-[TX]DG') 
					  AND (DispositionName LIKE 'GRADEG%' OR DispositionName LIKE 'REJECT%') THEN 'GRADEG' 
					  WHEN EDC_DATA_823.StationName = 'TENCOR_01' AND (RecipeName LIKE 'T3[EL]-[TX]PDG-DCN') 
					  AND (DispositionName LIKE 'GRADEG%' ) THEN 'GRADEG' 
					  WHEN EDC_DATA_823.StationName = 'TENCOR_01' AND (RecipeName LIKE 'T6L-ZPDG-DCN') 
					  AND (DispositionName LIKE 'GRADEG%' ) THEN 'GRADEG' 
					  WHEN EDC_DATA_823.StationName <> 'TENCOR_01' AND (
					  RecipeName = 'T6E-XPG-DCN' OR--20200205 T6E-G
					  RecipeName = 'T6E-TPG-DCN' OR--20200205 T6E-G
					  RecipeName = 'T6L-TPG-DCN' OR--20200205 T6L-G
					  RecipeName = 'T6L-XPG-DCN' OR --20200205 T6L-G
					  RecipeName = 'T6E-YPDG-DCN' OR--20200206 T6E-G
					  RecipeName = 'T6E-ZPDG-DCN' OR--20200206 T6E-G
					  RecipeName = 'T6L-YPDG-DCN' OR--20200206 T6L-G
					  RecipeName = 'T6L-ZPDG-DCN'OR--20200206 T6L-G
					  RecipeName ='T8L-TPDG-DCN'OR--20200206 T8L-G
					  RecipeName ='T8L-TPG-DCN'OR--20200206 T8L-G
					  RecipeName ='T8L-XPDG-DCN'OR--20200206 T8L-G
					  RecipeName ='T8L-XPG-DCN')--20200206 T8L-G
					  AND (DispositionName LIKE 'GRADEG%') THEN 'GRADEG' 
					  WHEN DispositionName LIKE 'GRADEB%' 
					  AND RecipeName <> 'UMC306-3B1' 
					  AND RecipeName <> 'T6E-TXB' 
					  AND RecipeName <> 'T6E-TB' 
					  AND RecipeName <> 'T6E-XB' 
					  AND RecipeName <> 'T6L-TPB1' --20200206 T6L-B
					  AND RecipeName <> 'T6L-XPB1' --20200206 T6L-B
					  AND RecipeName <> 'T6E-TPB1' --20200206 T6E-B
					  AND RecipeName <> 'T6E-XPB1'--20200206 T6E-B
	     			  THEN 'GRADEB'
					  --WHEN DispositionName LIKE 'GRADEB%'AND(
					  --RecipeName = 'T6L-TPB1' OR--20200206 T6L-B
					  --RecipeName = 'T6L-XPB1' OR--20200206 T6L-B
					  --RecipeName = 'T6E-TPB1' OR--20200206 T6E-B
					  --RecipeName = 'T6E-XPB1')--20200206 T6E-B
					  --AND (DispositionName LIKE 'GRADEB%') THEN 'GRADEB1' 
					  WHEN DispositionName LIKE 'GRADES%' THEN 'GRADES' 
					  WHEN DispositionName = 'OVERLOAD' THEN 'REJECTED' 
					  WHEN (StationName = 'TENCOR_07' OR
                      StationName = 'TENCOR_09' OR StationName = 'TENCOR_11' OR StationName = 'TENCOR_15') THEN CASE WHEN RecipeName = 'TEST-MIX' THEN CASE WHEN DFWHazeAvg < 0.1 AND DFTotalScratchLength < 10 AND 
                      DFAreaCount < 7 AND DFTotalArea < 10 AND DFDefectBinCount_2 < 91 AND DFDefectBinCount_3 < 26 AND DFDefectLPDNCount_2 < 91 AND 
                      DFTotalScratchLength < 10 THEN 'GRADEA' ELSE CASE WHEN DFTotalScratchLength < 10 AND DFAreaCount < 7 AND DFTotalArea < 10 AND 
                      DFDefectBinCount_2 < 91 AND DFDefectBinCount_3 < 26 AND DFDefectLPDNCount_2 < 91 AND 
                      DFTotalScratchLength < 10 THEN 'HAZEA' ELSE CASE WHEN DFWHazeAvg < 0.1 AND DFAreaCount < 11 AND DFTotalArea < 10 AND DFDefectBinCount_5 < 46 AND 
                      DFDefectLPDNCount_2 < 150 AND DFTotalScratchLength < 10 THEN 'POLISH' ELSE CASE WHEN DFWHazeAvg < 0.1 AND DFAreaCount < 11 AND 
                      DFTotalArea < 10 AND DFDefectBinCount_5 < 26 AND DFDefectLPDNCount_2 < 591 AND 
                      DFTotalScratchLength < 10 THEN 'GRADEC' ELSE CASE WHEN DFDefectLPDNCount_2 < 1 THEN 'GRADEF1' ELSE CASE WHEN DFWHazeAvg < 0.2 AND 
                      DFAreaCount < 600 AND DFTotalArea < 600 AND DFDefectBinCount_2 < 600 AND 
                      DFDefectLPDNCount_2 < 200 THEN 'REPOLISH' ELSE 'REJECTED' END END END END END END ELSE DispositionName END ELSE DispositionName END AS DispositionName,
                       RecipeName, 
		CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'SC-3' OR RecipeName = 'SSMC-3' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-3GM' OR RecipeName = 'HJ8220-3' OR RecipeName = '8220-6' THEN DFWSumAllDefects 
			 WHEN RecipeName = '8215-3' THEN DFDefectBinCount_1 - DFDefectBinCount_2 
			 WHEN RecipeName = '816250-3' THEN DFSumAllDefects - DFDefectBinCount_3 - DFDefectLPDNCount_3 
			 --When StationNAme='TENCOR_17' then DFSumAllDefects + DFAreaCount - DFdefectBinCount_18      --2021/10/15 added by FN
			 --20220808 add for UMC客戶需收uncluster (借用DFNDefectBinLimits_14欄位收值)
			 WHEN LotID Like '72__[JM]%' THEN DFNDefectBinLimits_14			 
			 ELSE DFSumAllDefects 
			 END AS DFSumAllDefects, 
						 DFWHazeAvg AS DFHazeAvg, 
                      DFWHazePeak AS DFHazePeak, DFNHazeAvg, DFNHazePeak, 
		CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'SC-3' OR RecipeName = 'SSMC-3' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-3GM' OR RecipeName = 'HJ8220-3' OR RecipeName = '8220-6' THEN DFWDefectBinCount_1
		  	 --When StationNAme='TENCOR_17' then DFDefectBinCount_1 + DFAreaCount - DFdefectBinCount_18      --2021/10/15 added by FN, 20220619 marked by michelle(SP7 Issue Fixed)
			 ELSE DFDefectBinCount_1 
			 END AS DFDefectBinCount_1,
		CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'SC-3' OR RecipeName = 'SSMC-3' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-3GM' OR RecipeName = 'HJ8220-3' OR RecipeName = '8220-6' THEN DFWDefectBinCount_2
		  	 --When StationNAme='TENCOR_17' then DFDefectBinCount_2 + DFAreaCount - DFdefectBinCount_18      --2021/10/15 added by FN, 20220619 marked by michelle(SP7 Issue Fixed)
		     ELSE DFDefectBinCount_2 
			 END AS DFDefectBinCount_2, 
		CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'SC-3' OR RecipeName = 'SSMC-3' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-3GM' OR RecipeName = 'HJ8220-3' OR RecipeName = '8220-6' THEN DFWDefectBinCount_3
		  	 --When StationNAme='TENCOR_17' then DFDefectBinCount_3 + DFAreaCount - DFdefectBinCount_18      --2021/10/15 added by FN, 20220619 marked by michelle(SP7 Issue Fixed)
	         ELSE DFDefectBinCount_3 
		     END AS DFDefectBinCount_3, 
		CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'SC-3' OR RecipeName = 'SSMC-3' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-3GM' OR RecipeName = 'HJ8220-3' OR RecipeName = '8220-6' THEN DFWDefectBinCount_4
		  	 --When StationNAme='TENCOR_17' then DFDefectBinCount_4 + DFAreaCount - DFdefectBinCount_18     --2021/10/15 added by FN, 20220619 marked by michelle(SP7 Issue Fixed)
	         ELSE DFDefectBinCount_4 
		     END AS DFDefectBinCount_4, 
	    CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_5 ELSE DFDefectBinCount_5 END AS DFDefectBinCount_5, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_6 ELSE DFDefectBinCount_6 END AS DFDefectBinCount_6, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_7 ELSE DFDefectBinCount_7 END AS DFDefectBinCount_7, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_8 ELSE DFDefectBinCount_8 END AS DFDefectBinCount_8, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_9 ELSE DFDefectBinCount_9 END AS DFDefectBinCount_9, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_10 ELSE DFDefectBinCount_10 END AS DFDefectBinCount_10, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_11 ELSE DFDefectBinCount_11 END AS DFDefectBinCount_11, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_12 ELSE DFDefectBinCount_12 END AS DFDefectBinCount_12, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_13 ELSE DFDefectBinCount_13 END AS DFDefectBinCount_13, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_14 ELSE DFDefectBinCount_14 END AS DFDefectBinCount_14, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_15 ELSE DFDefectBinCount_15 END AS DFDefectBinCount_15, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_16 ELSE DFDefectBinCount_16 END AS DFDefectBinCount_16, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_17 ELSE DFDefectBinCount_17 END AS DFDefectBinCount_17, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_18 ELSE DFDefectBinCount_18 END AS DFDefectBinCount_18, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinCount_19 ELSE DFDefectBinCount_19 END AS DFDefectBinCount_19, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_1 ELSE DFDefectBinLimits_1 END AS DFDefectBinLimits_1, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_2 ELSE DFDefectBinLimits_2 END AS DFDefectBinLimits_2, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_3 ELSE DFDefectBinLimits_3 END AS DFDefectBinLimits_3, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_4 ELSE DFDefectBinLimits_4 END AS DFDefectBinLimits_4, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_5 ELSE DFDefectBinLimits_5 END AS DFDefectBinLimits_5, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_6 ELSE DFDefectBinLimits_6 END AS DFDefectBinLimits_6, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_7 ELSE DFDefectBinLimits_7 END AS DFDefectBinLimits_7, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_8 ELSE DFDefectBinLimits_8 END AS DFDefectBinLimits_8, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_9 ELSE DFDefectBinLimits_9 END AS DFDefectBinLimits_9, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_10 ELSE DFDefectBinLimits_10 END AS DFDefectBinLimits_10, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_11 ELSE DFDefectBinLimits_11 END AS DFDefectBinLimits_11, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_12 ELSE DFDefectBinLimits_12 END AS DFDefectBinLimits_12, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_13 ELSE DFDefectBinLimits_13 END AS DFDefectBinLimits_13, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_14 ELSE DFDefectBinLimits_14 END AS DFDefectBinLimits_14, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_15 ELSE DFDefectBinLimits_15 END AS DFDefectBinLimits_15, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_16 ELSE DFDefectBinLimits_16 END AS DFDefectBinLimits_16, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_17 ELSE DFDefectBinLimits_17 END AS DFDefectBinLimits_17, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_18 ELSE DFDefectBinLimits_18 END AS DFDefectBinLimits_18, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'SC-3' OR
                      RecipeName = 'SSMC-3' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-3GM' OR
                      RecipeName = 'HJ8220-3' OR
                      RecipeName = '8220-6' THEN DFWDefectBinLimits_19 ELSE DFDefectBinLimits_19 END AS DFDefectBinLimits_19, ISNULL(DFDefectLPDNCount_1, 0) 
                      AS DFDefectLPDNCount_1, ISNULL(DFDefectLPDNCount_2, 0) AS DFDefectLPDNCount_2, ISNULL(DFDefectLPDNCount_3, 0) AS DFDefectLPDNCount_3, 
                      ISNULL(DFDefectLPDNCount_4, 0) AS DFDefectLPDNCount_4, ISNULL(DFDefectLPDNCount_5, 0) AS DFDefectLPDNCount_5, ISNULL(DFDefectLPDNCount_6, 0) 
                      AS DFDefectLPDNCount_6, ISNULL(DFDefectLPDNCount_7, 0) AS DFDefectLPDNCount_7, ISNULL(DFDefectLPDNCount_8, 0) AS DFDefectLPDNCount_8, 
                      ISNULL(DFDefectLPDNCount_9, 0) AS DFDefectLPDNCount_9, ISNULL(DFDefectLPDNCount_10, 0) AS DFDefectLPDNCount_10, ISNULL(DFDefectLPDNCount_11, 0) 
                      AS DFDefectLPDNCount_11, ISNULL(DFDefectLPDNCount_12, 0) AS DFDefectLPDNCount_12, ISNULL(DFDefectLPDNCount_13, 0) AS DFDefectLPDNCount_13, 
                      ISNULL(DFDefectLPDNCount_14, 0) AS DFDefectLPDNCount_14, ISNULL(DFDefectLPDNCount_15, 0) AS DFDefectLPDNCount_15, ISNULL(DFDefectLPDNCount_16, 0) 
                      AS DFDefectLPDNCount_16, ISNULL(DFDefectLPDNCount_17, 0) AS DFDefectLPDNCount_17, ISNULL(DFDefectLPDNCount_18, 0) AS DFDefectLPDNCount_18, 
                      ISNULL(DFDefectLPDNCount_19, 0) AS DFDefectLPDNCount_19, CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_1 ELSE DFWHazeBinPercentage_1 END AS DFHazeBinPercentage_1, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_2 ELSE DFWHazeBinPercentage_2 END AS DFHazeBinPercentage_2, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_3 ELSE DFWHazeBinPercentage_3 END AS DFHazeBinPercentage_3, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_4 ELSE DFWHazeBinPercentage_4 END AS DFHazeBinPercentage_4, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_5 ELSE DFWHazeBinPercentage_5 END AS DFHazeBinPercentage_5, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_6 ELSE DFWHazeBinPercentage_6 END AS DFHazeBinPercentage_6, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_7 ELSE DFWHazeBinPercentage_7 END AS DFHazeBinPercentage_7, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_8 ELSE DFWHazeBinPercentage_8 END AS DFHazeBinPercentage_8, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_9 ELSE DFWHazeBinPercentage_9 END AS DFHazeBinPercentage_9, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_10 ELSE DFWHazeBinPercentage_10 END AS DFHazeBinPercentage_10, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_11 ELSE DFWHazeBinPercentage_11 END AS DFHazeBinPercentage_11, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_12 ELSE DFWHazeBinPercentage_12 END AS DFHazeBinPercentage_12, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_13 ELSE DFWHazeBinPercentage_13 END AS DFHazeBinPercentage_13, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_14 ELSE DFWHazeBinPercentage_14 END AS DFHazeBinPercentage_14, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_15 ELSE DFWHazeBinPercentage_15 END AS DFHazeBinPercentage_15, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_16 ELSE DFWHazeBinPercentage_16 END AS DFHazeBinPercentage_16, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_17 ELSE DFWHazeBinPercentage_17 END AS DFHazeBinPercentage_17, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_18 ELSE DFWHazeBinPercentage_18 END AS DFHazeBinPercentage_18, 
                      CASE WHEN RecipeName = 'SC-3-070507' OR
                      RecipeName = 'GM225W-3' OR
                      RecipeName = '8220-6' OR
                      RecipeName = '81645-5' THEN DFWHazeBinPercentage_19 ELSE DFWHazeBinPercentage_19 END AS DFHazeBinPercentage_19, 
           CASE WHEN RecipeName = 'SC-3-070507' OR RecipeName = 'GM225W-3' OR RecipeName = '8220-6' OR RecipeName = 'PSC-12' THEN DFWAreaCount 
		        ELSE case when (StationNAme='TENCOR_12' And RecipeName Not Like '%IMC303-3%' ) or StationNAme='TENCOR_17'then DFAreaCount - DFdefectBinCount_18
				else DFAreaCount
				end 
								END AS DFAreaCount,
				--20220217 add for 格雷蒙客戶需收cluster total area(借用DFNDefectBinLimits_17欄位收值)
				CASE WHEN RecipeName Like '4F%' OR RecipeName Like 'EG-4F%' THEN DFNDefectBinLimits_17
					  ELSE ISNULL(DFTotalArea, 0) END AS DFTotalArea, ISNULL(DFScratchCount, 0) 
                      AS DFScratchCount, ISNULL(DFSlipLineCount, 0) AS DFSlipLineCount, ISNULL(DFTotalScratchLength, 0) AS DFTotalScratchLength, ISNULL(DFTotalSlipLineLength, 0) 
                      AS DFTotalSlipLineLength, ISNULL(DFNCDefectsCount, 0) AS DFNCDefectsCount, 
					  --20200715 add TSMC 0.026 Q-Grade rule, 20230529 add 0.015 Recipe
					  CASE WHEN (LotID Like '58%' Or RecipeName Like '%0.026%' Or RecipeName Like '%0.019%' Or RecipeName Like '%0.015%') THEN ISNULL(DFNDefectBinLimits_14, 0) ELSE ISNULL(DFNHazeBinPercentage_19, 0) END AS Sumofallcount_Unclustered
FROM         dbo.EDC_DATA_823 WITH (Nolock)




GO


