----------------------1.Outside---A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'-----------------------------------------------------------------------
		-- Outside
		select 'Category'='Outside'
				--  20200813 -> 2020-08-13
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock),  [EDC].[dbo].[View_PackingImageFN] B  with(nolock) 
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  -- 5-20171006-TY33E171SE-2PH9E10F0A  -25
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)