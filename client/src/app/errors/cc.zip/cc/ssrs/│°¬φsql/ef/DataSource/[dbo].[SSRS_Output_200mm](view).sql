USE [WarInfo]
GO

/****** Object:  View [dbo].[SSRS_Output_200mm]    Script Date: 2023/7/31 上午 10:36:17 ******/
-- SET ANSI_NULLS ON
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO


-- ALTER VIEW [dbo].[SSRS_Output_200mm]
-- AS
select 
-- top(100) *
		x.Category
      ,'MFGDate'=cast(left(x.MFGDate, 4)+'-'+subString(x.MFGDate, 5, 2)+'-'+right(x.MFGDate, 2) as datetime)
	  ,'MFGShift'=case when MFGShift='A' or MFGShift='C' then 'D'
	                   when MFGShift='B' or MFGShift='D' then 'N'
					   else 'N/A'
					   end
      --,x.LotNo
      ,x.Customer
      ,'PsiPN'=x.FG_PSI
      ,'CustomerPN'=case when x.FG_Customer='' or x.FG_Customer is null then 'N/A'
                         ELSE rtrim(x.FG_Customer)
                         end
      ,x.Qty
	FROM (
		-- Outside
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[A-Z]%'
		  and A.FG_BarCode4 not like 'PS_2M_%'		--12" Oxide
		  and A.FG_BarCode4 not like 'PS_6MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PS_8MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PSE8MT%'		--internal revenue
		  and A.FG_BarCode4 not like '[A-Z]___X_%'		--internal revenue
	      and A.FG_BarCode4 not like '[A-SU-Z]___[QVW]%'		--Oxide
	      and A.FG_BarCode4 not like 'P[BC]__S_%'		--Stripping only 不列入產出 2020-11-06 Hogoboss mail
		  --and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知
		  and A.FG_MFGDate>'20150101'
		   and  A.FG_Valid = 'Y'
	 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like 'PS_6MZ%'	OR
		           A.FG_BarCode4 like 'PS_8MZ%'	or
		           A.FG_BarCode4 like 'PSE8MT%'	or
		           A.FG_BarCode4 like '[A-Z]___X_%')
		  --and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知
		  and A.FG_MFGDate>'20150101'
		  and  A.FG_Valid = 'Y'
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		) x 

/*
select x.Category
      ,'MFGDate'=cast(left(x.MFGDate, 4)+'-'+subString(x.MFGDate, 5, 2)+'-'+right(x.MFGDate, 2) as datetime)
	  ,'MFGShift'=case when MFGShift='A' or MFGShift='C' then 'D'
	                   when MFGShift='B' or MFGShift='D' then 'N'
					   else 'N/A'
					   end
      --,x.LotNo
      ,x.Customer
      ,'PsiPN'=x.FG_PSI
      ,'CustomerPN'=case when x.FG_Customer='' or x.FG_Customer is null then 'N/A'
                         ELSE x.FG_Customer
                         end
      ,x.Qty
	FROM (
		-- Outside
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImage] B  with(nolock) 
		where A.FG_BarCode4 like '[A-Z]%'
		  and A.FG_BarCode4 not like 'PS_2M_%'		--12" Oxide
		  and A.FG_BarCode4 not like 'PS_6MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PS_8MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PSE8MT%'		--internal revenue
		  and A.FG_BarCode4 not like '[A-Z]___X_%'		--internal revenue
	      and A.FG_BarCode4 not like '[A-Z]___[QVW]%'		--Oxide
		  --and A.FG_Customer<>'V460000G'
		  and A.FG_MFGDate>'20150101'
		  -- and  A.FG_Valid = 'Y'
		  -- 1-20190401-001133-PSI8MY2AT4T -25    
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 6)
		  and A.FG_BarCode4=substring(B.Barcode, 19, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 29, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 32, 2)
	 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImage] B  with(nolock) 
		where (A.FG_BarCode4 like 'PS_6MZ%'	OR
		           A.FG_BarCode4 like 'PS_8MZ%'	or
		           A.FG_BarCode4 like 'PSE8MT%'	or
		           A.FG_BarCode4 like '[A-Z]___X_%')
		  and A.FG_MFGDate>'20150101'
		  -- and  A.FG_Valid = 'Y'
		  -- 2-20190401-042833-UMJ3U1TC04TC-25        
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 6)
		  and A.FG_BarCode4=substring(B.Barcode, 19, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 29, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 32, 2)
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer
		) x 
*/

GO


/*
執行時間為:20230731 10:45
產生結果如下 
Category	MFGDate		MFGShift	Customer	FG_PSI				FG_Customer	   Qty
---------------------------------------------------------------------------------------
Outside		20230708	A			PSI			3WSPSI8RELKM005   	V471100        50
Outside		20230307	D			VIC			3WSVIC8RELKE001   	               300
Outside		20230210	D			TSC			3WSTSC8RELKX001   	V460000C       75
Outside		20230615	A			WAL			3WSWAL8RELKE001   	12-005-200     625
Outside		20230302	D			UMC			3WSUMC8RELKG001   	W0853007P      275
Outside		20230429	B			UMC			3WSUMC8RELKU001   	W0813005P      325
Outside		20230404	D			TSC			3WSTSC6RELKX001   	V420021        75
Outside		20230107	B			MAX			3WSMAX8RELKG001   	01-14-0006     25
Outside		20230521	A			MAX			3WSMAX8RELKE001   	01-14-0003     25
Outside		20230112	C			TSC			3WSTSC6RELKX001   	V420021        250
Outside		20230506	D			TSC			3WSTSC8RELKX001   	V460000C       175
Outside		20230202	D			TSC			3WSTSC8RELKX001   	V460000        200
Outside		20230405	B			TSC			3WSTSC8RELKX001   	V460000        175
Outside		20230104	B			MAX			3WSMAX8RELKG001   	01-14-0005     100
Outside		20230221	C			UMC			3WSUMC8RELKU001   	W0813001P      250
Outside		20230708	A			UMC			3WSUMC8RELKU001   	W0823000P      50
Outside		20230407	D			UMC			3WSUMC8RELKU001   	W0813005P      25
Outside		20230115	C			MAX			3WSMAX8RELKE001   	01-14-0019     75
Outside		20230315	A			VIC			3WSVIC8RELKE001   	               200
Outside		20230511	C			VIC			3WSVIC8RELKE001   	               200
Outside		20230310	A			UMC			3WSUMC8RELKE001   	W0853013P      450
Outside		20230715	B			MAX			3WSMAX8RELKE002   	01-14-0004     50
Outside		20230116	C			UMC			3WSUMC8RELKU001   	W0823004P      100
Outside		20230625	C			MAX			3WSMAX8RELKE001   	01-14-0019     100
Outside		20230322	A			TSC			3WSTSC8RELKX001   	V460002        500
Outside		20230312	B			AMP			3WSAMP6RELKH001   	01706012       125
Outside		20230305	D			MAX			3WSMAX8RELKE001   	01-14-0017     150
Outside		20230603	B			HGY			3WSHGY8RELKA001   	1991000012G    50
Outside		20230607	A			TSC			3WSTSC8RELKX001   	V460000        125
Outside		20230703	C			MAX			3WSMAX8RELKE001   	01-14-0016     100
Outside		20230326	D			WAL			3WSWAL8RELKE001   	12-003-200     50
Outside		20230620	B			TSC			3WSTSC8RELKX001X  	V460000G       75
Outside		20230326	A			TSC			3WSTSC8RELKX001   	V450000        119
Outside		20230227	A			TSC			3WSTSC8RELKX001   	V460000        75
Outside		20230319	A			MAX			3WSMAX8RELKE001   	01-14-0005     125
Outside		20230712	D			UMC			3WSUMC8RELKG001   	W0853012P      50
Outside		20230503	B			TSC			3WSTSC8RELKX001   	V450000        78
Outside		20230108	B			MAX			3WSMAX8RELKE001   	01-14-0020     25
Outside		20230423	A			MAX			3WSMAX8RELKE001   	01-14-0005     25
Outside		20230112	B			WAL			3WSWAL8RELKE001   	12-003-200     25
Outside		20230505	A			UMC			3WSUMC8RELKE001   	W0853000P      25
Outside		20230311	B			MAX			3WSMAX8RELKE001   	01-14-0016     125
Outside		20230420	A			MAX			3WSMAX8RELKE001   	01-14-0005     50
Outside		20230205	C			TSC			3WSTSC8RELKX001   	V450000        60
Outside		20230118	B			UMC			3WSUMC8RELKU001   	W0823000P      25
Outside		20230207	A			MAX			3WSMAX8RELKE001   	01-14-0005     25
Outside		20230522	B			UMC			3WSUMC8RELKG001   	W0853007P      250
Outside		20230502	D			TSC			3WSTSC8RELKX001   	V460000B       25
Outside		20230612	C			MAX			3WSMAX8RELKE001   	01-14-0005     125
Outside		20230603	A			MAX			3WSMAX8RELKE001   	01-14-0003     175
Outside		20230406	C			MAX			3WSMAX8RELKE001   	01-14-0006     50
Outside		20230215	A			AMP			3WSAMP6RELKH001   	01706012       500
Outside		20230701	D			UMC			3WSUMC8RELKU001   	W0813006P      50
Outside		20230719	C			TSC			3WSTSC8RELKX001X  	V460000G       25
Outside		20230420	A			TSC			3WSTSC8RELKX001   	V460000        25
Outside		20230613	D			TSC			3WSTSC8RELKX001   	V460000C       50
Outside		20230605	C			PSI			3WSPSI8RELKM005   	V471100        150
Outside		20230209	C			UMC			3WSUMC8RELKU001   	W0813005P      25
Outside		20230107	B			TSC			3WSTSC8RELKX001   	V460000B       50
Outside		20230412	A			UMC			3WSUMC8RELKU001   	W0823006P      25
Outside		20230309	C			TSC			3WSTSC8RELKX001   	V460000B       100
Outside		20230511	B			TSC			3WSTSC8RELKX001   	V460000        200
Outside		20230302	D			TSC			3WSTSC8RELKX001   	V460000        100
*/


