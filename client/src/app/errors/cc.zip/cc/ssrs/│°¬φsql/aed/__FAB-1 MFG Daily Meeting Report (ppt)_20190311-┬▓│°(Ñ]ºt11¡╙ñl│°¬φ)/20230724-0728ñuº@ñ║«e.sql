select

20230724
	監視LoadSingleWaferMap，目前正常
	整理Kanban-Reclaim 有77支sql
	報表 31-DataSet_300mmPolish
	報表 32-DataSet_300mmPolishAll
	報表 33-DataSet_300mmGradeP(Copper)
	報表 34-DataSet_300mmGradeT_SurfaceAndThickness(G)
	報表 35-DataSet_300mm555

	view:
	SSRS_Output_300mm_LotNo
	SSRS_Output_200mm_Time
	SSRS_Output_300mm_Time
	

20230725
	報表 36-內容測試-DataSet_300mm555Loss
	報表 37-內容測試-DataSet_300mmParticleBoxPolit32nm(GradeP)
	報表 38 39 43 44 48 49-內容測試-DataSet_300mmGradeT_Product_Surface_Thickness(product_2AE)
	報表 40-內容測試-DataSet_300mm815
	報表 41-內容測試-DataSet_300mm815Loss
	報表 42-內容測試-DataSet_300mmPolisherParticleBoxpolit(GradeP GradeA)
	報表 45-內容測試-DataSet_300mm700
	報表 46-內容測試-DataSet_300mm700Loss
	報表 47 52-內容測試-DataSet_300mmCleanerParticleBoxPolit(Line_NonCopper)
	報表 50-內容測試-DataSet_300mm680
	報表 53 54 55-內容測試-DataSet_300mmAfterCMPWIP
	報表 56 60 64 68 72 76-內容測試-DataSet_300mmDailyWIP
	報表 575859 616263 656667 697071 737475-DataSet_300mmWIP
	報表 77-內容測試-DataSet_Revenue

	整理 SP_Insert_EDA_TencorLog 這一支store procedure
	主要是建麼 EDA_TencorLog 這個資料表

20230726

	--EDA_Tencorlog
	SP_Insert_EDA_TencorLog測試_關聯資料表
	SP_Insert_EDA_TencorLog
		1.[EDC].[dbo].[EDC_VIEW_810_Map_T7ID_FN](view)
			a.dbo.EDC_VIEW_810_Map(view)
				a-1.dbo.EDC_DATA_810
				a-2.dbo.EDC_DATA_810_Map
				a-3.dbo.EDC_VIEW_TBI(view)(1千6百萬多筆資料)
					a-3-1.dbo.EDC_DATA_823
				a-4.LEFT join [EDC].[dbo].[Equipment_List] on dbo.EDC_DATA_810.STATION_NAME = [EDC].[dbo].[Equipment_List].StationName
			b.dbo.EDC_DATA_RPW350
			c.dbo.Chart_SP_RPW350
			d.TableShot.dbo.View_SupplierACC ?? 595筆
		2.[EDC].[dbo].[EDC_Map_Recipe] (依據StationName, Recipe, BeginTime塞ParticleSize1) 80188筆


	--報表3, 77
	sap_sd_so_v (WarInfo同義字)(172.28.128.178)
20230727
	SP_Insert_EDA_TencorLog
	EDC_VIEW_810_Map_T7ID_FN
	Reports Executed During Past 180 Days_v2.xlsx
20230728
