USE [EDC]
GO

SELECT [StationName]
      ,[CollectionTime]
      ,[LotID]
      ,[SrcSlotID]
      ,[DispositionName]
      ,[RecipeName]
      ,[KlarfName]
      ,[Map]
  FROM [dbo].[EDC_DATA_810_Map]
  Where StationName ='TENCOR_10'
  and CollectionTime>='2023/7/5 13:00:00'


