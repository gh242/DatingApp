with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @EndDate-1*@DistanceDaily, @EndDate) 
),

TempDay as (
select 'MFG_Date'=cast(DateAdd(day, -1*N, @EndDate) as date) from CTE
),

TempLoss as (
select a.MFG_DATE
          ,'CODE'=rtrim(b.CODE_CODE) 
          ,'CODE_DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'FailQty'=Sum(a.MFG_QTY)
from FN_MFG_LOSS a with(nolock), FN_CODE_DEFINITION b with(nolock)
where a.MFG_DATE between convert(char(10), (@EndDate-1*@DistanceDaily), 112) and convert(char(10), @EndDate, 112)
and a.MFG_EQUID=680
and a.MFG_LOTNO like case when @Customer='All' then '[A-Z]%'
                                                 when @Customer='tsmc' then 'T%'
                                                 when @Customer='UMC' then 'U%'
                                                 when @Customer='UMC Polish' then 'U___[UF]%'
                                                 when @Customer='UMC Reclaim' then 'U___[EI]%' 
                                                 when @Customer='Maxchip' then 'P[BC]%'                                                                end
and a.MFG_LOTNO not like case when @Customer='All' then 'PS_2%' 
                                                        else ''
                                                        end
and a.MFG_LOTNO not like '%A8'
and a.MFG_LOTNO not like 'EG%'
and a.MFG_EQUID=b.CODE_EQUID
and rtrim(a.MFG_CODE)=rtrim(b.CODE_CODE)
and b.CODE_CODE in (@LossCode)

and not ( (a.MFG_LOTNO like 'HI__E%' or a.MFG_LOTNO like 'MX__E%' or a.MFG_LOTNO like 'P[BC]__E%' or a.MFG_LOTNO like 'UM__[EFU]%') and b.CODE_CODE='L18     ' )
and not (a.MFG_LOTNO like '___[MN]%' and b.CODE_CODE='L19     ')

group by a.MFG_DATE, rtrim(b.CODE_CODE), rtrim(b.CODE_DESCRIPTION)
)


select a.MFG_DATE
          ,b.CODE 
          ,b.CODE_DESCRIPTION
          ,b.FailQty
from TempDay a left join TempLoss b
                                  on convert(char(10), a.MFG_DATE, 112)=b.MFG_DATE