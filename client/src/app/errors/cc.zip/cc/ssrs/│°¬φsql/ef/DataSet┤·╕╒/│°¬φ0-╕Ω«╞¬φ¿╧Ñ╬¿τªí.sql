DECLARE @RealDate SMALLDATETIME;
SET @RealDate = '20230704';

DECLARE YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230717';



--報表3
-- https://learn.microsoft.com/zh-tw/sql/t-sql/language-elements/like-transact-sql?view=sql-server-ver16
/*
LIKE '_% _%'
_ (底線)	任何單一字元。				   WHERE au_fname LIKE '_ean' 會尋找所有四個字母且結尾為 ean(Dean)、Sean 等) 的名字。
%			任何含有零或多個字元的字串。	WHERE title LIKE '%computer%' 可找出書名中含有 computer 這個字的所有書名。
[ ]	在指定範圍 [a-f] 或集合 [abcdef] 中的任何單一字元。	
										 WHERE au_lname LIKE '[C-P]arsen' 可找出結尾是 arsen，開頭是 C 和 P 之間的
										 任何單一字元的作者姓氏，例如，Carsen、Larsen、Karsen 等等。 在範圍搜尋中，
										 範圍所包含的字元可能會因定序的排序規則而不同。
[^]	不在指定範圍 [^a-f] 或集合 [^abcdef] 中的任何單一字元。
										 WHERE au_lname LIKE 'de[^l]%' 會尋找開頭是 de 且下一個字元不是 l 的作者姓氏。


left(KDMAT, charindex(' ', KDMAT)-1)
https://dotblogs.com.tw/flairming/2014/02/14/143993
首先，介紹一下CHARINDEX這個用法，CHARINDEX('-','A1-123')就是算到-前(包括-號喔)的字元數，
所以說SELECT CHARINDEX('-','A1-123') 結果會是 3。

所以如果我要取A1的話(也就是-之前的字串)，我只需這樣寫：
SELECT SUBSTRING('A1-123',1,CHARINDEX('-','A1-123')-1)

left
傳回字元字串含指定字元數的左側部分。
SELECT LEFT('abcdefg',2); 
--   
ab


--報表5
PERCENTILE_CONT
'Box_75'=(PERCENTILE_CONT(0.75) within group (order by ParticleCount1) over (partition by MFG_Date))

--PERCENTILE_CONT() within group
--根據 SQL Server 中的資料行值連續分佈計算百分位數。 其結果會以內插值取代，可能不會等於資料行中的任何特定值
--https://learn.microsoft.com/zh-tw/sql/t-sql/functions/percentile-cont-transact-sql?view=sql-server-ver16
--https://docs.aws.amazon.com/zh_tw/redshift/latest/dg/r_WF_PERCENTILE_CONT.html

--報表14
rtrim：去除右邊空白
https://qaz50208.pixnet.net/blog/post/279518704



Charindex
此函式會在第二個字元運算式內搜尋一個字元運算式，並傳回第一個運算式的開始位置 (如果找到的話)。
DECLARE @document VARCHAR(64);  
  
SELECT @document = 'Reflectors are vital safety' +  
                   ' components of your bicycle.';  
SELECT CHARINDEX('vital', @document, 5);  
以下為結果集。
-----------   
16          