USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='DA'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='DP'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='GD'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,Process
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeT' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeT' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 18 and 20 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
and process='GP'
and ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
group by dbo.RealDateToMfgDate(CollectionTime), Process, ProcessThickness
)

-- 19nm Non-Copper
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='DA'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='DA'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='DP'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='DP'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='GD'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='GD'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')
union all
select a.MFGDate
          ,'Line'='Non-Copper'
          ,'nm'='19nm'
          ,'Process'='GP'
          ,'ProcessThickness'=isnull(b.ProcessThickness, ' ')
          ,b.Qty
          ,b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate
                         and b.Process='GP'
                         and b.ProcessThickness in ('A', 'S', 'W', 'Y', 'Z')


GO