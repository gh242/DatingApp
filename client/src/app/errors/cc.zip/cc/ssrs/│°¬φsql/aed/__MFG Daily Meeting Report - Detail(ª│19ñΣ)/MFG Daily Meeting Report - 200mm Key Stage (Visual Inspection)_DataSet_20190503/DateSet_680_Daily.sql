with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @EndDate-1*@DistanceDaily, @EndDate) 
),

TempDay as (
select 'MFG_Date'=cast(DateAdd(day, -1*N, @EndDate) as date) from CTE
),

TempDaily as (
select MFG_DATE
          ,'PassQty'=Sum(MFG_MOVE)
          ,'FailQty'=Sum(MFG_LOSS)
from FN_MFG_WORK with(nolock)
where MFG_DATE between convert(char(10), (@EndDate-1*@DistanceDaily), 112) and convert(char(10), @EndDate, 112)
and MFG_EQUID=680
and MFG_LOTNO like case when @Customer='All' then '[A-Z]%'
                                              when @Customer='tsmc' then 'T%'
                                              when @Customer='UMC' then 'U%'
                                              when @Customer='UMC Polish' then 'U___[UF]%'
                                              when @Customer='UMC Reclaim' then 'U___[EI]%' 
                                              when @Customer='Maxchip' then 'P[BC]%'                                      end
and MFG_LOTNO not like case when @Customer='All' then 'PS_2%' 
                                                     else ''
                                                     end
and MFG_LOTNO not like '%A8'
and MFG_LOTNO not like 'EG%'
group by MFG_DATE

union all
select a.MFG_DATE
          ,'PassQty'=Sum(a.MFG_QTY)
          ,'FailQty'=-1*Sum(a.MFG_QTY)
from FN_MFG_LOSS a with(nolock), FN_CODE_DEFINITION b with(nolock)
where a.MFG_DATE between convert(char(10), (@EndDate-1*@DistanceDaily), 112) and convert(char(10), @EndDate, 112)
and a.MFG_EQUID=680
and a.MFG_LOTNO like case when @Customer='All' then '[A-Z]%'
                                                 when @Customer='tsmc' then 'T%'
                                                 when @Customer='UMC' then 'U%'
                                                 when @Customer='UMC Polish' then 'U___[UF]%'
                                                 when @Customer='UMC Reclaim' then 'U___[EI]%' 
                                                 when @Customer='Maxchip' then 'P[BC]%'                                                                end
and a.MFG_LOTNO not like case when @Customer='All' then 'PS_2%' 
                                                        else ''
                                                        end
and a.MFG_LOTNO not like '%A8'
and a.MFG_LOTNO not like 'EG%'
and a.MFG_EQUID=b.CODE_EQUID
and rtrim(a.MFG_CODE)=rtrim(b.CODE_CODE)
and b.CODE_CODE in (@LossCode)

and ( ((a.MFG_LOTNO like 'HI__E%' or a.MFG_LOTNO like 'MX__E%' or a.MFG_LOTNO like 'P[BC]__E%' or a.MFG_LOTNO like 'UM__[EFU]%') and b.CODE_CODE='L18     ' )
          or
          (a.MFG_LOTNO like '___[MN]%' and b.CODE_CODE='L19     ')
        )
group by a.MFG_DATE
),

CTEW as (
select N=0
union all 
select N+7 from CTEW where N<DateDiff(day, @EndDate-7*@DistanceWeekly2, @EndDate) 
),

TempWeek as (
select 'MFG_DATE'=dbo.RealDateToWeekNo(cast(DateAdd(day, -1*N, @EndDate)+' 07:20:00' as datetime)) from CTEW
),

TempWeekly as (
select 'MFG_DATE'=[dbo].[RealDateToWeekNo](cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as datetime))
          ,'PassQty'=Sum(MFG_MOVE)
          ,'FailQty'=Sum(MFG_LOSS)
from FN_MFG_WORK with(nolock)
where MFG_DATE between convert(char(10),  [dbo].[RealDateToWeekFirstDate](@EndDate-7*@DistanceWeekly2), 112) and convert(char(10), @EndDate, 112)
and MFG_EQUID=680
and MFG_LOTNO like case when @Customer='All' then '[A-Z]%'
                                              when @Customer='tsmc' then 'T%'
                                              when @Customer='UMC' then 'U%'
                                              when @Customer='UMC Polish' then 'U___[UF]%'
                                              when @Customer='UMC Reclaim' then 'U___[EI]%' 
                                              when @Customer='Maxchip' then 'P[BC]%'                                      end
and MFG_LOTNO not like case when @Customer='All' then 'PS_2%' 
                                                     else ''
                                                     end
and MFG_LOTNO not like '%A8'
and MFG_LOTNO not like 'EG%'
group by [dbo].[RealDateToWeekNo](cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as datetime))

union all
select 'MFG_DATE'=[dbo].[RealDateToWeekNo](cast(left(a.MFG_DATE, 4)+'-'+substring(a.MFG_DATE, 5, 2)+'-'+right(a.MFG_DATE, 2) as datetime))
          ,'PassQty'=Sum(a.MFG_QTY)
          ,'FailQty'=-1*Sum(a.MFG_QTY)
from FN_MFG_LOSS a with(nolock), FN_CODE_DEFINITION b with(nolock)
where a.MFG_DATE between convert(char(10),  [dbo].[RealDateToWeekFirstDate](@EndDate-7*@DistanceDaily), 112) and convert(char(10), @EndDate, 112)
and a.MFG_EQUID=680
and a.MFG_LOTNO like case when @Customer='All' then '[A-Z]%'
                                                 when @Customer='tsmc' then 'T%'
                                                 when @Customer='UMC' then 'U%'
                                                 when @Customer='UMC Polish' then 'U___[UF]%'
                                                 when @Customer='UMC Reclaim' then 'U___[EI]%' 
                                                 when @Customer='Maxchip' then 'P[BC]%'                                                                end
and a.MFG_LOTNO not like case when @Customer='All' then 'PS_2%' 
                                                        else ''
                                                        end
and a.MFG_LOTNO not like '%A8'
and a.MFG_LOTNO not like 'EG%'
and a.MFG_EQUID=b.CODE_EQUID
and rtrim(a.MFG_CODE)=rtrim(b.CODE_CODE) 
and b.CODE_CODE in (@LossCode)

and ( ((a.MFG_LOTNO like 'HI__E%' or a.MFG_LOTNO like 'MX__E%' or a.MFG_LOTNO like 'P[BC]__E%' or a.MFG_LOTNO like 'UM__[EFU]%') and b.CODE_CODE='L18     ' )
          or
          (a.MFG_LOTNO like '___[MN]%' and b.CODE_CODE='L19     ')
        )
group by [dbo].[RealDateToWeekNo](cast(left(a.MFG_DATE, 4)+'-'+substring(a.MFG_DATE, 5, 2)+'-'+right(a.MFG_DATE, 2) as datetime))
)


select 'Mode'='2.Daily'
          ,'MFG_DATE'=substring(convert(char(10), a.MFG_DATE, 111), 6, 5)
          ,b.PassQty
          ,b.FailQty
from TempDay a left join TempDaily b with(nolock)
                                  on convert(char(10), a.MFG_DATE, 112)=b.MFG_DATE
union all
select 'Mode'='1.Weekly'
          ,a.MFG_DATE
          ,b.PassQty
          ,b.FailQty
from TempWeek a left join TempWeekly b
                                   on a.MFG_DATE=b.MFG_DATE