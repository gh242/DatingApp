USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';


select 'Line'='Non-Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=555
and (a.MANU_FROM_LOTNO like '____[EGJKFMNPX]%' or a.MANU_FROM_LOTNO like '6___X%')
and a.MANU_FROM_LOTNO not like '9V__E%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)

union all
select 'Line'='Copper'
          ,'LotNo'=left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1)
          ,'DESCRIPTION'=rtrim(b.CODE_DESCRIPTION)
          ,'Qty'=sum(a.MANU_QTY)
from [RCS_NEW].[dbo].[FN_MANUFACTURE] a with(nolock), [RCS_NEW].[dbo].[FN_CODE_DEFINITION] b  with(nolock)
where a.MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and a.MANU_FROM_EQUID=555
and (a.MANU_FROM_LOTNO like '____[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and a.MANU_FROM_LOTNO not like '6___X%'
and a.MANU_FROM_LOTNO not like '%-%-[34]%'
and a.MANU_FMLB='L'
and a.MANU_QTY>0
and a.MANU_FROM_EQUID=b.CODE_EQUID
and a.MANU_CODE=b.CODE_CODE
and b.CODE_TYPE='L'
group by left(a.MANU_FROM_LOTNO, 2)+'_'+substring(a.MANU_FROM_LOTNO, 5, 1), rtrim(b.CODE_DESCRIPTION)


GO