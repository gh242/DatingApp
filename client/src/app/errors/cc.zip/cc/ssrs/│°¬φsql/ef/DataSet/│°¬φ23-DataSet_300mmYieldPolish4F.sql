USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

with TempA as (
-- Copper
select 'Line'='Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%'  then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName not like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,Polisher
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                                        else 0
                                        end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where StationName not like 'TENCOR_1[123457]'
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__M%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
--and (LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher
)


select a.*
          ,'Yield'=1.0000*a.Pass/a.Total
from TempA a


GO

/*
執行時間為:20230719 14:45
產生結果如下 
Line	    PreCleaner	FinalCleaner	Pass	Mech	Total	Yield
---------------------------------------------------------------------------------
Copper	    PC3L	    SC2	            83	    27	    130	    0.638461538461538
Copper	    PC3R	    SC2	            93	    24	    131	    0.709923664122137
Copper	    FC3L	    SC1	            12	    0	    12	    1.000000000000000
Copper	    Ebara2L	    GF1	            40	    28	    70	    0.571428571428571
Copper	    PC3R	    GF1	            176	    4	    194	    0.907216494845360
Copper	    PC2 	    SC1	            102	    29	    140	    0.728571428571428
Copper	    PC3L	    SC1	            140	    47	    198	    0.707070707070707
Copper	    FC3R	    GF1	            60	    9	    72	    0.833333333333333
Copper	    PC3R	    SC1	            135	    55	    210	    0.642857142857142
Copper	    I-CleanR	SC2	            20	    11	    36	    0.555555555555555
Copper	    I-CleanR	GF1	            51	    0	    56	    0.910714285714285
Copper	    FC3R	    Oasis	        110	    20	    138	    0.797101449275362
Copper	    Ebara2L	    Oasis	        5	    30	    36	    0.138888888888888
Copper	    FC3R	    SC2	            179	    44	    320	    0.559375000000000
Copper	    FC3R	    SC1	            15	    7	    24	    0.625000000000000
Copper	    I-CleanL	Oasis	        3	    0	    3	    1.000000000000000
Copper	    FC3L	    SC2	            200	    55	    301	    0.664451827242524
Copper	    I-CleanR	SC1	            45	    26	    80	    0.562500000000000
Copper	    FC3L	    GF1	            77	    5	    84	    0.916666666666666
Copper	    I-CleanL	SC2	            21	    11	    34	    0.617647058823529
Copper	    PC2 	    SC2	            183	    83	    293	    0.624573378839590
Copper	    Ebara1R	    Oasis	        108	    14	    126	    0.857142857142857
Copper	    Ebara1L	    Oasis	        146	    24	    182	    0.802197802197802
Copper	    FC3L	    Oasis	        119	    25	    151	    0.788079470198675
Copper	    I-CleanL	GF1	            66	    0	    68	    0.970588235294117
Copper	    I-CleanR	Oasis	        10	    0	    12	    0.833333333333333
Copper	    I-CleanL	SC1	            33	    34	    71	    0.464788732394366
Copper	    PC3L	    GF1	            213	    11	    227	    0.938325991189427
Non-Copper	SCC1A	    NULL	        86	    30	    136	    0.632352941176470
Non-Copper	SCC1B	    NULL	        88	    29	    151	    0.582781456953642
Non-Copper	SCC1D	    NULL	        47	    19	    102	    0.460784313725490
Non-Copper	Ebara4L	    SCC1	        23	    0	    23	    1.000000000000000
Non-Copper	SCC1A	    SCC1	        4	    6	    10	    0.400000000000000
Non-Copper	SCC1B	    SCC1	        5	    5	    11	    0.454545454545454
Non-Copper	SCC1C	    NULL	        74	    30	    151	    0.490066225165562
*/