----------------------5.Outside---FG_MFGDate>'20150101'-----------------------------------------------------------------------
		-- Jasont requet 2019/7/30
		-- Outside		 
		 union all
		 select 'Category'='Outside'
			   ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'FG_Customer'=rtrim(A.FG_Customer)
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=cast(A.FG_BarCode6 as integer)
			   ,Print_Date
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'