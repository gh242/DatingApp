USE [WarInfo]
GO

/****** Object:  View [dbo].[SSRS_Output_200mm_Time]    Script Date: 2023/7/24 上午 11:02:10 ******/
-- SET ANSI_NULLS ON
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO

-- ALTER VIEW [dbo].[SSRS_Output_200mm_Time]
-- AS


/*
Category	MFG_Date				MFGDate		MFGShift	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 16:25:32.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 17:00:46.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 17:19:35.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 17:36:41.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 17:57:13.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 18:15:53.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 18:35:37.000
Inside		2023-05-15 00:00:00.000	20230515	C			PSE8MT	25	2023-05-15 18:54:09.000
Inside		2023-05-15 00:00:00.000	20230515	B			PSE8MT	25	2023-05-15 19:42:09.000
Inside		2023-05-15 00:00:00.000	20230515	B			PSE8MT	25	2023-05-15 19:59:51.000
Inside		2023-05-15 00:00:00.000	20230515	B			PSE8MT	25	2023-05-15 20:21:22.000
*/

		-- Outside
		select  
					'Category'='Outside'
					--  20200813 -> 2020-08-13
		           ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			       ,'MFGDate'=A.FG_MFGDate
			       ,'MFGShift'=A.FG_MFGType
			       ,'LotNo'=left(A.FG_BarCode4,6)
			       ,'Qty'=cast(A.FG_BarCode6 as integer)
			       ,Print_Date
				-- top(20) *
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[A-Z]%'
		  and A.FG_BarCode4 not like 'PS_2M_%'		--12" Oxide
		  and A.FG_BarCode4 not like 'PS_6MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PS_8MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PSE8MT%'		--internal revenue
		  and A.FG_BarCode4 not like '[A-Z]___X_%'		--internal revenue
	      and A.FG_BarCode4 not like '[A-SU-Z]___[QVW]%'		--Oxide
	      and A.FG_BarCode4 not like 'P[BC]__S_%'		--Stripping only 不列入產出 2020-11-06 Hogoboss mail
		  --and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知
		  and A.FG_MFGDate>'20150101'
		  and  A.FG_Valid = 'Y'

/*
 [RCS].[dbo].[FG_Barcode]
FG_MFGDate	FG_MFGType	FG_PSI				FG_Customer		FG_BarCode1	FG_BarCode2	FG_BarCode3	FG_BarCode4	FG_BarCode5	FG_BarCode6		FG_WaferGrade	FG_BoxNo	FG_AutoPrint	FG_Account	FG_Valid	Print_Date				Print_Times	Print_Mode
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	000512    	T6KBM147XB	X 			25				GRADEA    		002 		Y				EDCUSER		Y			2020-11-09 00:07:42.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	002609    	T6KBM147XB	X 			25				GRADEA    		003 		Y				EDCUSER		Y			2020-11-09 00:27:03.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	005158    	T6KBM147XB	X 			25				GRADEA    		004 		Y				EDCUSER		Y			2020-11-09 00:52:50.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	011256    	T6KBM147XB	X 			25				GRADEA    		005 		Y				EDCUSER		Y			2020-11-09 01:13:38.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	015223    	T6KBM147XB	X 			25				GRADEA    		006 		Y				EDCUSER		Y			2020-11-09 01:52:55.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	021324    	T6KBM147XB	X 			25				GRADEA    		007 		Y				EDCUSER		Y			2020-11-09 02:13:52.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	024144    	T6KBM147XB	X 			25				GRADEA    		008 		Y				EDCUSER		Y			2020-11-09 02:42:05.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	030605    	T6KBM147XB	X 			25				GRADEA    		009 		Y				EDCUSER		Y			2020-11-09 03:06:48.000	1			NULL
20201108	D			3WSPSI8RELKM001   	V471100         5			20201109	034009    	T6KBM147XB	X 			25				GRADEA    		010 		Y				EDCUSER		Y			2020-11-09 03:41:30.000	1			NULL
20201129	B			3WSTSC8RELKX001   	V460002         5			20201130	000509    	T6KBI102TB	T 			25				GRADEB    		029 		Y				EDCUSER		Y			2020-11-30 00:05:03.000	1			NULL
*/

		-- Inside
		union all
		select 'Category'='Inside'
					--  20200813 -> 2020-08-13
			       ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			       ,'MFGDate'=A.FG_MFGDate
			       ,'MFGShift'=A.FG_MFGType
			       ,'LotNo'=left(A.FG_BarCode4,6)
				   ,'Qty'=cast(A.FG_BarCode6 as integer)
			       ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like 'PS_6MZ%'	OR
		           A.FG_BarCode4 like 'PS_8MZ%'	or
		           A.FG_BarCode4 like 'PSE8MT%'	or
		           A.FG_BarCode4 like '[A-Z]___X_%')
		  --and A.FG_Customer<>'V460000G'      -- 20200813 Hogoboss通知
		  and A.FG_MFGDate>'20150101'
		  and  A.FG_Valid = 'Y'


/*
		-- Outside
		select  'Category'='Outside'
		           ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			       ,'MFGDate'=A.FG_MFGDate
			       ,'MFGShift'=A.FG_MFGType
			       ,'LotNo'=left(A.FG_BarCode4,6)
			       ,'Qty'=cast(A.FG_BarCode6 as integer)
			       ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImage] B  with(nolock) 
		where A.FG_BarCode4 like '[A-Z]%'
		  and A.FG_BarCode4 not like 'PS_2M_%'		--12" Oxide
		  and A.FG_BarCode4 not like 'PS_6MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PS_8MZ%'		--internal revenue
		  and A.FG_BarCode4 not like 'PSE8MT%'		--internal revenue
		  and A.FG_BarCode4 not like '[A-Z]___X_%'		--internal revenue
	      and A.FG_BarCode4 not like '[A-Z]___[QVW]%'		--Oxide
		  --and A.FG_Customer<>'V460000G'
		  and A.FG_MFGDate>'20150101'
		 -- and  A.FG_Valid = 'Y'
		  -- 1-20190401-001133-PSI8MY2AT4T -25    
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 6)
		  and A.FG_BarCode4=substring(B.Barcode, 19, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 29, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 32, 2)
		-- Inside
		union all
		select 'Category'='Inside'
			       ,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			       ,'MFGDate'=A.FG_MFGDate
			       ,'MFGShift'=A.FG_MFGType
			       ,'LotNo'=left(A.FG_BarCode4,6)
				   ,'Qty'=cast(A.FG_BarCode6 as integer)
			       ,Print_Date
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImage] B  with(nolock) 
		where (A.FG_BarCode4 like 'PS_6MZ%'	OR
		           A.FG_BarCode4 like 'PS_8MZ%'	or
		           A.FG_BarCode4 like 'PSE8MT%'	or
		           A.FG_BarCode4 like '[A-Z]___X_%')
		  and A.FG_MFGDate>'20150101'
		  -- and  A.FG_Valid = 'Y'
		  -- 2-20190401-042833-UMJ3U1TC04TC-25        
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 6)
		  and A.FG_BarCode4=substring(B.Barcode, 19, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 29, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 32, 2)
 */


GO


