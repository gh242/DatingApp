USE [WarInfo]
GO

/****** Object:  StoredProcedure [dbo].[Sp_Insert_BI_300mm_Output_Daily]    Script Date: 2023/7/26 下午 03:43:16 ******/
-- SET ANSI_NULLS OFF
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO







-- ALTER PROCEDURE [dbo].[Sp_Insert_BI_300mm_Output_Daily] 
-- @StartDate datetime,
-- @EndDate datetime
-- AS

--  delete from [dbo].[BI_300mm_Output_Daily]
-- 		where MFGDate between @StartDate and @EndDate

--  Insert into 
 [dbo].[BI_300mm_Output_Daily] (
					 MFGDate
					,GradeU
					,GradeT
				    ,GradeQ
				    ,GradeP
					,Normal
					,Low
 					,Total
					 )
		select 'MFGDate'=MFGDate
				  ,'GradeU'=sum(x.GradeU)
				  ,'GradeT'=sum(x.GradeT)
				  ,'GradeQ'=sum(x.GradeQ)
				  ,'GradeP'=sum(x.GradeP)
				  ,'Normal'=sum(x.Normal)
				  ,'Low'=sum(x.Low)
 				  ,'Total'=sum(x.GradeU)+sum(x.GradeT)+sum(x.GradeQ)+sum(x.GradeP)+sum(x.Normal)+sum(x.Low)
				  from (
				  		select 'MFGDate'=MFG_Date
								  ,'GradeU'=sum(Qty)
								  ,'GradeT'=0
								  ,'GradeQ'=0
								  ,'GradeP'=0
								  ,'Normal'=0
								  ,'Low'=0
						from SSRS_Output_300mm_Time with(nolock)
						where FG_Customer like 'V65%U'
						group by MFG_Date
						union all
						select 'MFGDate'=MFG_Date
								  ,'GradeU'=0
								  ,'GradeT'=sum(Qty)
								  ,'GradeQ'=0
								  ,'GradeP'=0
								  ,'Normal'=0
								  ,'Low'=0
						from SSRS_Output_300mm_Time with(nolock)
						where FG_Customer like 'V65%T'
						group by MFG_Date
						union all
						select 'MFGDate'=MFG_Date
								  ,'GradeU'=0
						          ,'GradeT'=0
						          ,'GradeQ'=sum(Qty)
								  ,'GradeP'=0
								  ,'Normal'=0
								  ,'Low'=0
						from SSRS_Output_300mm_Time with(nolock)
						where FG_Customer like 'V65%Q'
						group by MFG_Date
						union all
						select  'MFGDate'=MFG_Date
								  ,'GradeU'=0
						          ,'GradeT'=0
						          ,'GradeQ'=0
								  ,'GradeP'=sum(Qty)
								  ,'Normal'=0
								  ,'Low'=0
						from SSRS_Output_300mm_Time with(nolock)
						where  ( FG_Customer like 'V65%P' or
								  FG_Customer='180-ECLX8' or
								  FG_Customer='180-ECLR8' or 
								  FG_Customer='180-ECLT8' or
								  FG_Customer='180-ECLX8' or
								  FG_Customer='180-EALX8' or
								  FG_Customer='180-ELR18' or
								  FG_Customer='180-ELT08' 
								)
						group by MFG_Date
						union all
						select 'MFGDate'=MFG_Date
								  ,'GradeU'=0
						          ,'GradeT'=0
						          ,'GradeQ'=0
								  ,'GradeP'=0
								  ,'Normal'=sum(Qty)
								  ,'Low'=0
						from SSRS_Output_300mm_Time with(nolock)
						where FG_Customer not like 'V65%[PQT]'
						and FG_Customer not like 'V650000[DF]%'
						and FG_Customer not like 'V65000[67][DF]%'
						and FG_Customer not like 'V6500[12][12][DF]%'
                        and FG_Customer<>'V65000013D'
                        and FG_Customer<>'V600001F'
						and FG_Customer not like '02-14-0018'
						and FG_Customer not like '02-14-002[1568]'
						and FG_Customer not like '02-14-003[034]'
						--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
						and FG_Customer<>'180-ECLX8'     
						and FG_Customer<>'180-ECLR8'
						and FG_Customer<>'180-ECDR8'
						and FG_Customer<>'180-ECDT8'
						and FG_Customer<>'180-ECLT8'
						and FG_Customer<>'180-ECLX8'
						and FG_Customer<>'180-EALX8'
						and FG_Customer<>'180-EDR38'
						and FG_Customer<>'180-EDT38'
						and FG_Customer<>'180-ELR18'
						and FG_Customer<>'180-ELT08' 
						and LotNo not like 'PSD2MZ_F[TX]%]'
						group by MFG_Date
						union all
						select 'MFGDate'=MFG_Date
								  ,'GradeU'=0
						          ,'GradeT'=0
						          ,'GradeQ'=0
								  ,'GradeP'=0
								  ,'Normal'=0
								  ,'Low'=sum(Qty)
						from SSRS_Output_300mm_Time with(nolock)
						where (FG_Customer like 'V650000[DF]%' or
								 FG_Customer like 'V65000[67][DF]%' or
						         FG_Customer like 'V6500[12][12][DF]%' or
                                 FG_Customer='V65000013D' or
                                 FG_Customer='V600001F' or
								 FG_Customer like '02-14-0018' or 
								 FG_Customer like '02-14-002[1568]' or 
								 FG_Customer like '02-14-003[034]' or
								 FG_Customer='180-ECDR8' or
								 FG_Customer='180-ECDT8' or
								 FG_Customer='180-EDR38' or
								 FG_Customer='180-EDT38' or
								 LotNo like 'PSD2MZ_F[TX]%]')
						group by MFG_Date
						union all
						select 'MFGDate'=cast(left(MFG_Date, 4)+'/'+substring(MFG_Date, 5, 2)+'/'+substring(MFG_Date, 7, 2) as datetime) 
								  ,'GradeU'=0
						          ,'GradeT'=0
						          ,'GradeQ'=0
								  ,'GradeP'=0
								  ,'Normal'=-1*sum(MFG_MOVE)
								  ,'Low'=0
						from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
						where MFG_EQUID=810
						and MFG_LOTNO like '%RR%'
						and MFG_MOVE>0
						group by cast(left(MFG_Date, 4)+'/'+substring(MFG_Date, 5, 2)+'/'+substring(MFG_Date, 7, 2) as datetime) 
						) x		
			where x.MFGDate between @StartDate and @EndDate
			group by MFGDate
GO


