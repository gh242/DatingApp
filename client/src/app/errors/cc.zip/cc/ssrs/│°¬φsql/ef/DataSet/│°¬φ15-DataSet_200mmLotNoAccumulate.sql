USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

select 'LotNo'=substring(LotNo, 1, 2)  --+'_'+substring(LotNo, 5, 1)
          ,'Qty'=sum(Qty)
from SSRS_Output_200mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
group by substring(LotNo, 1, 2)  --+'_'+substring(LotNo, 5, 1)

union all
select 'LotNo'=substring(MFG_LOTNO, 1, 2)  --+'_'+substring(MFG_LOTNO, 5, 1)
          ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_200mm].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between convert(char(8), @YYYYMMDD-Day(@YYYYMMDD)+1, 112)  and convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_LOTNO not like '[A-Z]___[QWV]%'
and MFG_MOVE>0
group by substring(MFG_LOTNO, 1, 2)  --+'_'+substring(MFG_LOTNO, 5, 1)

GO

/*
產生結果如下  20230718 執行時間，為20230718 16:21
LotNo	Qty
------------
PS	    4000
T5	    3250
AP	    3175
AJ	    675
UM	    6650
AT	    1325
F2	    913
PC	    550
US	    350
T8	    830
T3	    850
AD	    75
CX	    850
T6	    3500
PB	    1000
VI	    888
T8	    -225
*/