USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

--報表28-內容測試-DataSet_300mmYieldEbara
--與報表19,20很像

with TempA as (
-- Copper
select 'Line'='Copper'
          ,'Polisher'=right(PreCleaner, 1)+'+'+cast(Polisher as varchar)
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                           else 0
                      end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                           else 0
                      end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where PreCleaner like 'Ebara%' 
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD)  --07:20
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1) -- 隔日07:20
and LotID like '[1-9]___[BCDHLUYIS]%' -- 第1碼是1到9，第5碼是 BCDHLUYIS 其中1碼
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by right(PreCleaner, 1)+'+'+cast(Polisher as varchar)
/*
執行時間為:20230720 14:19
產生結果如下 
Line	Polisher	Pass	Mech	Total
-------------------------------------------
Copper	1+14	    62	    12	    78
Copper	2+1	        9	    15	    24  
Copper	2+13	    5	    10	    15
Copper	3+27	    218	    4	    238
Copper	1+13	    31	    3	    36
Copper	1+3	        45	    6	    53
Copper	3+25	    228	    1	    249
Copper	1+1	        50	    14	    70
Copper	1+12	    69	    1	    97
Copper	3+24	    206	    4	    228
Copper	1+2	        56	    1	    59
Copper	1+8	        161	    3	    212
Copper	2+14	    0	    11	    12
Copper	2+3	        31	    22	    55
Copper	1+17	    130	    4	    174
Copper	1+4	        10	    2	    12
*/

-- Non-Copper
union all
select 'Line'='Non-Copper'
          ,'Polisher'=right(PreCleaner, 1)+'+'+cast(Polisher as varchar)
          ,'Pass'=sum(case when WAFERGRADE='PASS' or WAFERGRADE like 'GRADE[ABCNOPQTS]%' then 1
                           else 0
                      end)
          ,'Mech'=sum(case when WAFERGRADE like 'GRADE[DEF]%' then 1
                           else 0
                      end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where PreCleaner like 'Ebara%' 
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
--and LotID not like '[1-9]___[EGJKFNP]%' or LotID like 'PS__2%')
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by right(PreCleaner, 1)+'+'+cast(Polisher as varchar)
/*
Line	    Polisher	Pass	Mech	Total
---------------------------------------------
Non-Copper	4+22	    17	    6	    23
Non-Copper	4+18	    154	    0	    184
Non-Copper	4+19	    124	    5	    153
Non-Copper	4+23	    23	    0	    23
*/
)


select a.*
          ,'Yield'=1.0000*a.Pass/a.Total
from TempA a

GO


/*
執行時間為:20230720 14:15
產生結果如下 
Line	     Polisher	 Pass	Mech	Total	 Yield
-------------------------------------------------------------
Copper	     2+1	     9	    15	    24	     0.375000000000000
Copper	     1+4	     10	    2	    12	     0.833333333333333
Copper	     1+14	     62	    12	    78	     0.794871794871794
Copper	     1+17	     130	4	    174	     0.747126436781609
Copper	     1+13	     31	    3	    36	     0.861111111111111
Copper	     1+12	     69	    1	    97	     0.711340206185567
Copper	     3+24	     206	4	    228	     0.903508771929824
Copper	     2+13	     5	    10	    15	     0.333333333333333
Copper	     3+27	     218	4	    238	     0.915966386554621
Copper	     1+2	     56	    1	    59	     0.949152542372881
Copper	     1+8	     161	3	    212	     0.759433962264150
Copper	     2+14	     0	    11	    12	     0.000000000000000
Copper	     2+3	     31	    22	    55	     0.563636363636363
Copper	     1+3	     45	    6	    53	     0.849056603773584
Copper	     3+25	     228	1	    249	     0.915662650602409
Copper	     1+1	     50	    14	    70	     0.714285714285714
Non-Copper	 4+23	     23	    0	    23	     1.000000000000000
Non-Copper	 4+19	     124	5	    153	     0.810457516339869
Non-Copper	 4+18	     154	0	    184	     0.836956521739130
Non-Copper	 4+22	     17	    6	    23	     0.739130434782608
*/