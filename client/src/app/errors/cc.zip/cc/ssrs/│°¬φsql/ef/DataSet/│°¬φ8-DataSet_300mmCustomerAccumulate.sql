USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';

select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
          ,'HighT'=sum(Qty)
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN like 'V65%[T]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
          ,'HighT'=0
          ,'HighQ'=sum(Qty)
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN like 'V65%[Q]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=sum(Qty)
          ,'Normal'=0
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and ( CustomerPN like 'V65%P' or
          CustomerPN like 'V65%P2' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-ECLR8' or 
          CustomerPN='180-ECLT8' or
          CustomerPN='180-ECLX8' or
          CustomerPN='180-EALX8' or
          CustomerPN='180-ELR18' or
          CustomerPN='180-ELT08' 
        )
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=sum(Qty)
          ,'Low'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and CustomerPN not like 'V65%[PQT]'
and CustomerPN not like 'V65%P2'
and CustomerPN not like 'V650000[DF]%'
and CustomerPN not like 'V65000[67][DF]%'
and CustomerPN not like 'V6500[12][12][DF]%'
and CustomerPN<>'V65000013D'
and CustomerPN<>'V600001F'
and CustomerPN not like '02-14-0018'
and CustomerPN not like '02-14-002[1568]'
and CustomerPN not like '02-14-003[034]'
--180-ECR78     180-ECT68    180-EAR18    180-EAT08   180-EAX28    180-ECR78    180-ECT68    180-ECX88                        
and CustomerPN<>'180-ECLX8'     
and CustomerPN<>'180-ECLR8'
and CustomerPN<>'180-ECDR8'
and CustomerPN<>'180-ECDT8'
and CustomerPN<>'180-ECLT8'
and CustomerPN<>'180-ECLX8'
and CustomerPN<>'180-EALX8'
and CustomerPN<>'180-EDR38'
and CustomerPN<>'180-EDT38'
and CustomerPN<>'180-ELR18'
and CustomerPN<>'180-ELT08' 
and LotNo not like 'PSD2MZ_F[TX]%]'
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end

union all
select 'LotNo'=case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=0
          ,'Low'=sum(Qty)
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and ( CustomerPN like 'V650000[DF]%' or
         CustomerPN like 'V65000[67][DF]%' or 
        CustomerPN like 'V6500[12][12][DF]%' or
        CustomerPN='V65000013D' or
        CustomerPN='V600001F' or
         CustomerPN like '02-14-0018' or 
         CustomerPN like '02-14-002[1568]' or 
         CustomerPN like '02-14-003[034]' or
         CustomerPN='180-ECDR8' or
         CustomerPN='180-EDR38' or
         CustomerPN='180-EDT38' or
         LotNo like 'PSD2MZ_F[TX]%]')
group by case when LotNo like '9%' then substring(LotNo, 1, 2)
                                  else substring(LotNo, 1, 1)
                                  end

union all
select 'LotNo'=case when MFG_LOTNO like '9%' then substring(MFG_LOTNO , 1, 2)
                                  else substring(MFG_LOTNO , 1, 1)
                                  end
          ,'HighT'=0
          ,'HighQ'=0
          ,'HighP'=0
          ,'Normal'=-1*sum(MFG_MOVE)
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between left(convert(char(8), @YYYYMMDD, 112), 6)+'01'  and convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0
group by case when MFG_LOTNO like '9%' then substring(MFG_LOTNO , 1, 2)
                                  else substring(MFG_LOTNO , 1, 1)
                                  end

GO

/*
產生結果如下  20230718 執行時間，為20230718 14:49
LotNo	HighT	HighQ	HighP	Normal	Low
--------------------------------------------
2	    275	    0	    0	    0	    0
2	    0	    2075	0	    0	    0
2	    0	    0	    3750	0	    0
5	    0	    0	    275	    0	    0
95	    0	    0	    0	    250	    0
6	    0	    0	    0	    125	    0
2	    0	    0	    0	    32800	0
5	    0	    0	    0	    0	    25
2	    0	    0	    0	    0	    13300
6	    0	    0	    0	    0	    300
2	    0	    0	    0	    -750	0
*/