USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
),

/*
-- Copper
TempC as (
-- Copper
select 'Line'='Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2_[CBDUXHILYMS]'
group by dbo.RealDateToMfgDate(CollectionTime)
),
*/

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,ProcessThickness
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime), ProcessThickness
/*
--all 
union all
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'ProcessThickness'='All'
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime)
*/
)

-- 26nm Non-Copper
select a.MFGDate, 'Line'='Non-Copper', 'nm'='26nm', 'ProcessThickness'=isnull(b.ProcessThickness, 'X'), b.Qty, b.Percentage
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate

/*
-- 26nm Copper
union all
select a.MFGDate, 'Line'='Copper', 'nm'='26nm', b.Qty, b.Percentage
from TempDay a left join tempC b
                         on a.MFGDate=b.MFGDate
*/


GO