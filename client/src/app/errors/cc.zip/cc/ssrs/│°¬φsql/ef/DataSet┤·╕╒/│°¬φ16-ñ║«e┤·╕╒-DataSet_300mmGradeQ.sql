USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @YYYYMMDD-1*14, @YYYYMMDD) 

/*
取0到14
N
-----
0
1
2
3
4
5
6
7
8
9
10
11
12
13
14
*/
),

TempDay as (
select 'MFGDate'=DateAdd(day, -1*N, @YYYYMMDD)
from CTE
/*
select * from TempDay
往前數15天的日期
MFGDate
-------------------
2023-07-12 00:00:00
2023-07-11 00:00:00
2023-07-10 00:00:00
2023-07-09 00:00:00
2023-07-08 00:00:00
2023-07-07 00:00:00
2023-07-06 00:00:00
2023-07-05 00:00:00
2023-07-04 00:00:00
2023-07-03 00:00:00
2023-07-02 00:00:00
2023-07-01 00:00:00
2023-06-30 00:00:00
2023-06-29 00:00:00
2023-06-28 00:00:00
*/
)
,
-- select * from TempDay

-- /*
-- -- Copper
-- TempC as (
-- -- Copper
-- select 'Line'='Copper'
--           ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
--           ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
-- 	                      else 0
-- 		      end)
--           ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
-- 	                                            else 0
-- 		                             end) / Count(*)
--           ,'QtyP'=sum(case when WaferGrade='GradeP' then 1
-- 	                      else 0
-- 		      end)
--           ,'PercentageP'=1.0000*sum(case when WaferGrade='GradeP' then 1
-- 	                                            else 0
-- 		                             end) / Count(*)
--           ,'TotalQty'=Count(*)
-- from EDA_Tencorlog with(nolock)
-- where ( ParticleSize1 between 21 and 26 )
-- and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
-- and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
-- and Product like '2_[BCDHLUYIS]%'
-- group by dbo.RealDateToMfgDate(CollectionTime)
-- ),
-- */

-- Non-Copper
TempD as (
select 'Line'='Non-Copper'
          ,'MFGDate'=dbo.RealDateToMfgDate(CollectionTime)
          ,'Qty'=sum(case when WaferGrade='GradeQ' then 1
	                      else 0
		      end)
          ,'Percentage'=1.0000*sum(case when WaferGrade='GradeQ' then 1
	                                            else 0
		                             end) / Count(*)
          ,'QtyP'=sum(case when WaferGrade='GradeP' then 1
	                      else 0
		      end)
          ,'PercentageP'=1.0000*sum(case when WaferGrade='GradeP' then 1
	                                            else 0
		                             end) / Count(*)
          ,'TotalQty'=Count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 21 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD-14) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and Product like '2%'
and Product not like '2_[BCDHLUYIS]%'
group by dbo.RealDateToMfgDate(CollectionTime)

/*
產生結果如下  20230718 執行時間，為20230718 16:40
Line	    MFGDate	                Qty	    Percentage	        QtyP	PercentageP	        TotalQty
----------------------------------------------------------------------------------------------------
Non-Copper	2023-06-29 00:00:00.000	491	    0.445958219800181	275	    0.249772933696639	1101
Non-Copper	2023-07-05 00:00:00.000	535	    0.644578313253012	167	    0.201204819277108	830
Non-Copper	2023-07-02 00:00:00.000	587	    0.602669404517453	152	    0.156057494866529	974
Non-Copper	2023-07-08 00:00:00.000	59	    0.406896551724137	39	    0.268965517241379	145
Non-Copper	2023-07-11 00:00:00.000	34	    0.871794871794871	3	    0.076923076923076	39
Non-Copper	2023-06-30 00:00:00.000	17	    0.708333333333333	1	    0.041666666666666	24
Non-Copper	2023-07-09 00:00:00.000	499	    0.602657004830917	102	    0.123188405797101	828
Non-Copper	2023-07-03 00:00:00.000	838	    0.668794892258579	154	    0.122905027932960	1253
Non-Copper	2023-07-06 00:00:00.000	342	    0.576728499156829	102	    0.172006745362563	593
Non-Copper	2023-07-01 00:00:00.000	9	    0.375000000000000	3	    0.125000000000000	24
Non-Copper	2023-07-04 00:00:00.000	586	    0.718137254901960	155	    0.189950980392156	816
Non-Copper	2023-06-28 00:00:00.000	426	    0.707641196013289	102	    0.169435215946843	602
Non-Copper	2023-07-07 00:00:00.000	123	    0.657754010695187	18	    0.096256684491978	187
Non-Copper	2023-07-10 00:00:00.000	510	    0.635910224438902	98	    0.122194513715710	802
*/

)

-- -- Non-Copper
select a.MFGDate, 'Line'='Non-Copper', b.Qty, b.Percentage, b.QtyP, b.PercentageP, b.TotalQty
from TempDay a left join tempD b
                         on a.MFGDate=b.MFGDate

/*
-- Copper
union all
select a.MFGDate, 'Line'='Copper', b.Qty, b.Percentage, b.QtyP, b.PercentageP, b.TotalQty
from TempDay a left join tempC b
                         on a.MFGDate=b.MFGDate
*/

GO


/*
產生結果如下  20230718 執行時間，為20230718 16:40
MFGDate	            Line	    Qty	    Percentage	        QtyP	PercentageP	        TotalQty
-------------------------------------------------------------------------------------------------
2023-06-29 00:00:00	Non-Copper	491	    0.445958219800181	275	    0.249772933696639	1101
2023-07-05 00:00:00	Non-Copper	535	    0.644578313253012	167	    0.201204819277108	830
2023-07-02 00:00:00	Non-Copper	587	    0.602669404517453	152	    0.156057494866529	974
2023-07-08 00:00:00	Non-Copper	59	    0.406896551724137	39	    0.268965517241379	145
2023-07-11 00:00:00	Non-Copper	34	    0.871794871794871	3	    0.076923076923076	39
2023-06-30 00:00:00	Non-Copper	17	    0.708333333333333	1	    0.041666666666666	24
2023-07-09 00:00:00	Non-Copper	499	    0.602657004830917	102	    0.123188405797101	828
2023-07-03 00:00:00	Non-Copper	838	    0.668794892258579	154	    0.122905027932960	1253
2023-07-06 00:00:00	Non-Copper	342	    0.576728499156829	102	    0.172006745362563	593
2023-07-01 00:00:00	Non-Copper	9	    0.375000000000000	3	    0.125000000000000	24
2023-07-04 00:00:00	Non-Copper	586	    0.718137254901960	155	    0.189950980392156	816
2023-06-28 00:00:00	Non-Copper	426	    0.707641196013289	102	    0.169435215946843	602
2023-07-07 00:00:00	Non-Copper	123	    0.657754010695187	18	    0.096256684491978	187
2023-07-10 00:00:00	Non-Copper	510	    0.635910224438902	98	    0.122194513715710	802
2023-07-12 00:00:00	Non-Copper	NULL	NULL	            NULL	NULL	            NULL
*/