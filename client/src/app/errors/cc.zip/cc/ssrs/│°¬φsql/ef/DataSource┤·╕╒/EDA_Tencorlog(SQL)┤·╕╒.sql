/****** SSMS 中 SelectTopNRows 命令的指令碼  ******/
SELECT TOP (1000) [StationName]
      ,[MFGDate]
      ,[CollectionTime]
      ,[LotID]
      ,[WaferGrade]
      ,[WaferGradeOriginal]
      ,[RecipeName]
      ,[KlarfName]
      ,[Product]
      ,[Result]
      ,[HazeAverage]
      ,[ParticleCount1]
      ,[ParticleCount2]
      ,[AreaCount]
      ,[TotalArea]
      ,[ScratchCount]
      ,[ScratchLength]
      ,[RPW350_LotID]
      ,[T7ID]
      ,[ThicknessCenter]
      ,[TTV]
      ,[Bow]
      ,[Warp]
      ,[Resistivity]
      ,[PNtype]
      ,[Class]
      ,[VariationLastPolishThicknessCenter]
      ,[VariationLastPolishTTV]
      ,[VariationLastPolishWarp]
      ,[VariationThicknessCenter]
      ,[VariationTTV]
      ,[VariationWarp]
      ,[ParticleSize1]
      ,[ParticleSize2]
      ,[Process]
      ,[ProcessThickness]
      ,[PolishShift]
      ,[Polisher]
      ,[PolishNo]
      ,[RecipeFine]
      ,[RecipeRough]
      ,[PadUsedFine]
      ,[PadUsedRough]
      ,[PreCleaner]
      ,[PreCleanNo]
      ,[PreCleanSide]
      ,[FinalCleaner]
      ,[FinalCleanNo]
      ,[FinalCleanSide]
      ,[FinalCleaner2]
      ,[FinalCleanNo2]
      ,[FinalCleanSide2]
  FROM [WarInfo].[dbo].[EDA_TencorLog]
  where [MFGDate] > '2023-07-22'


/*
StationName	MFGDate	    CollectionTime	        LotID	                WaferGrade	WaferGradeOriginal	RecipeName	    KlarfName	                                                                                        Product	Result	HazeAverage	        ParticleCount1	ParticleCount2	AreaCount	TotalArea	        ScratchCount	ScratchLength	    RPW350_LotID	T7ID	    ThicknessCenter	TTV	    Bow	    Warp	Resistivity	PNtype	Class	    VariationLastPolishThicknessCenter	VariationLastPolishTTV	VariationLastPolishWarp	VariationThicknessCenter	VariationTTV	VariationWarp	ParticleSize1	ParticleSize2	Process	ProcessThickness	PolishShift	Polisher	PolishNo	RecipeFine	RecipeRough	PadUsedFine	PadUsedRough	PreCleaner	PreCleanNo	PreCleanSide	FinalCleaner	FinalCleanNo	FinalCleanSide	FinalCleaner2	FinalCleanNo2	FinalCleanSide2
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
TENCOR_15	2023-07-23	2023-07-24 05:29:40.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_052940_22N7311DAS-PL14-H10B_S23_GRADEA.001	    223	    1	    0.113215252757072	8	            4	            1	        0	                0	            0	                22N7310-23	    FC8RU017SE	755.71	        1.38	-3.18	8.93	22.650	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:28:58.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_052858_22N7311DAS-PL14-H10B_S24_GRADEA.001	    223	    1	    0.111683659255505	40	            25	            2	        1.18439079440314	0	            0	                22N7310-24	    WK4NW157ES	751.49	        3.42	-3.75	8.48	11.770	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:30:21.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053021_22N7311DAS-PL14-H10B_S22_GRADEA.001	    223	    1	    0.114797472953796	18	            7	            0	        0	                1	            1.38404345703125	22N7310-22	    CB861276SL	748.74	        3.24	-3.57	11.37	11.720	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:31:45.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053145_22N7311DAS-PL14-H10B_S20_GRADEA.001	    223	    1	    0.110806204378605	7	            5	            1	        0.0455547022340773	0	            0	                22N7310-20	    CG463490SL	758.57	        2.37	-4.01	12.39	11.500	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:32:27.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053227_22N7311DAS-PL14-H10B_S19_GRADEA.001	    223	    1	    0.113838203251362	10	            7	            0	        0	                0	            0	                22N7310-19	    CH562M39SL	754.42	        1.97	-0.10	5.19	8.004	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:33:09.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053309_22N7311DAS-PL14-H10B_S18_GRADEA.001	    223	    1	    0.116563260555267	30	            12	            3	        0.0741351330608827	0	            0	                22N7310-18	    CG463511SL	758.97	        2.81	-4.43	12.29	11.470	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:33:50.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053350_22N7311DAS-PL14-H10B_S17_GRADEA.001	    223	    1	    0.11536855250597	10	            5	            1	        0.0475603367639291	1	            4.81049755859375	22N7310-17	    CB559N72SL	761.44	        1.87	-2.65	13.57	7.245	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:35:55.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053555_22N7311DAS-PL14-H10B_S14_GRADEA.001	    223	    1	    0.116231359541416	12	            6	            1	        0.0526706817881775	0	            0	                22N7310-14	    SE0XH074MR	760.81	        2.02	-2.28	15.28	24.820	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:34:32.000	22N7311DAS-PL14-H10B	GradeD	    GRADED3	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053432_22N7311DAS-PL14-H10B_S16_GRADED.001	    223	    1	    0.110134862363338	547	            6	            2	        0	                2	            6.01201586914063	22N7310-16	    5JJXD028SJ	764.90	        1.49	-1.48	42.02	9.248	    P TYPE	GRADEF-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:35:13.000	22N7311DAS-PL14-H10B	Reclean	    RECLEAN	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053513_22N7311DAS-PL14-H10B_S15_RECLEAN.001	223	    0	    0.111275531351566	191	            11	            1	        0	                0	            0	                22N7310-15	    8BPUR132SJ	767.60	        2.20	-2.71	39.37	11.060	    P TYPE	RECLEAN	    NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:36:36.000	22N7311DAS-PL14-H10B	Reclean	    RECLEAN	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053636_22N7311DAS-PL14-H10B_S13_RECLEAN.001	223	    0	    0.112097382545471	175	            0	            0	        0	                0	            0	                22N7310-13	    8BPUN039SJ	763.20	        1.92	-0.73	39.67	10.250	    P TYPE	RECLEAN	    NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL
TENCOR_15	2023-07-23	2023-07-24 05:31:03.000	22N7311DAS-PL14-H10B	GradeA	    GRADEA	            EG-TS-ABDF-C	\\172.28.128.120\Klarf\SP2-4\2023_07\20230723\230724_053103_22N7311DAS-PL14-H10B_S21_GRADEA.001	    223	    1	    0.11436416208744	8	            8	            1	        0	                1	            2.29278784179688	22N7310-21	    CJ635M97SL	754.18	        2.54	-0.64	7.05	7.762	    P TYPE	GRADEA-X	NULL	                            NULL	                NULL	                NULL	                    NULL	        NULL	        88	            120	            DA	    S	                P	        21	        14	        	        	        0	        0	            SCC1	    10	        B	            NULL	        NULL	 	                    NULL	           NULL  
  
*/