USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;

-- 報表35-內容測試-DataSet_300mm555
-- 與 報表 40(815),45(700),50(680) 很像，MANU_FROM_EQUID 不同

with TempA as ( 
-- Non-Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Non-Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=815
and (MANU_FROM_LOTNO like '[1-9]___[EGJKFMNPX]%' or MANU_FROM_LOTNO like '6___X%')
and MANU_FROM_LOTNO not like '9V__E%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0
/*
執行時間為:20230721 11:00
產生結果如下 
Print_Date	          Line	      	Qty	Loss
------------------------------------------------
2023-07-11 10:23:13.000	Non-Copper	0	6
2023-07-11 10:23:13.000	Non-Copper	0	1
2023-07-11 10:25:33.000	Non-Copper	0	23
2023-07-11 12:58:57.000	Non-Copper	0	36
2023-07-11 13:20:19.000	Non-Copper	0	13
2023-07-11 16:00:11.000	Non-Copper	0	1
2023-07-11 13:43:44.000	Non-Copper	64	0
2023-07-11 16:00:11.000	Non-Copper	24	0
2023-07-11 16:00:57.000	Non-Copper	15	0
2023-07-11 16:01:58.000	Non-Copper	21	0
2023-07-11 16:03:13.000	Non-Copper	35	0
2023-07-11 16:23:53.000	Non-Copper	128	0
2023-07-11 16:25:33.000	Non-Copper	100	0
2023-07-11 16:27:17.000	Non-Copper	8	0
2023-07-11 17:01:06.000	Non-Copper	27	0
2023-07-11 18:53:01.000	Non-Copper	97	0
2023-07-11 18:54:02.000	Non-Copper	127	0
2023-07-11 18:56:29.000	Non-Copper	25	0
2023-07-11 18:59:22.000	Non-Copper	4	0
2023-07-11 18:59:27.000	Non-Copper	12	0
2023-07-12 01:32:35.000	Non-Copper	0	2
2023-07-12 01:33:17.000	Non-Copper	0	12
2023-07-12 01:33:17.000	Non-Copper	0	4
2023-07-12 02:17:48.000	Non-Copper	0	29
2023-07-12 03:53:01.000	Non-Copper	0	45
2023-07-12 03:53:17.000	Non-Copper	0	1
2023-07-12 04:05:00.000	Non-Copper	0	49
2023-07-12 05:31:28.000	Non-Copper	0	5
2023-07-12 06:00:09.000	Non-Copper	0	1
2023-07-12 06:00:39.000	Non-Copper	0	14
2023-07-12 06:01:22.000	Non-Copper	0	4
2023-07-12 06:07:00.000	Non-Copper	0	1
2023-07-12 06:07:18.000	Non-Copper	0	1
2023-07-12 06:07:37.000	Non-Copper	0	10
2023-07-12 06:08:12.000	Non-Copper	0	8
2023-07-12 06:27:29.000	Non-Copper	0	20
2023-07-12 06:38:01.000	Non-Copper	0	11
2023-07-12 06:38:08.000	Non-Copper	0	1
2023-07-12 07:09:45.000	Non-Copper	0	22
2023-07-12 07:14:08.000	Non-Copper	229	0
...
95筆資料
*/
union all
-- Copper
select 'Print_Date'=cast(left(MANU_REALDATE, 4)
                     +'-'+substring(MANU_REALDATE, 5, 2)
                     +'-'+right(MANU_REALDATE, 2)
                     +' '+left(MANU_ENDTIME, 2)
                     +':'+substring(MANU_ENDTIME, 3, 2)
                     +':'+right(MANU_ENDTIME, 2) as DateTime)
          ,'Line'='Copper'
          ,'Qty'=case when MANU_FMLB='M' then MANU_QTY
                      else 0
                 end
          ,'Loss'=case when MANU_FMLB='L' then MANU_QTY
                       else 0
                  end
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=815
and (MANU_FROM_LOTNO like '[1-9]___[CBDUHILYS]%' or MANU_FROM_LOTNO like '9V__E%')
and MANU_FROM_LOTNO not like '6___X%'
and MANU_FROM_LOTNO not like '%-%-[34]%'
and MANU_FMLB like '[ML]'
and MANU_QTY>0
/*
執行時間為:20230721 11:00
產生結果如下 
Print_Date	          Line	      Qty	Loss
------------------------------------------------
2023-07-11 09:43:04.000	Copper	0	1
2023-07-11 09:45:27.000	Copper	0	2
2023-07-11 09:45:36.000	Copper	0	1
2023-07-11 15:06:39.000	Copper	0	5
2023-07-11 17:17:10.000	Copper	0	2
2023-07-11 17:17:29.000	Copper	0	2
2023-07-11 17:17:36.000	Copper	0	2
2023-07-11 18:42:19.000	Copper	0	10
2023-07-11 18:43:00.000	Copper	0	2
2023-07-11 18:43:12.000	Copper	0	2
2023-07-11 18:43:49.000	Copper	0	1
2023-07-11 18:43:49.000	Copper	0	1
2023-07-11 18:43:58.000	Copper	0	43
2023-07-11 18:54:12.000	Copper	0	1
2023-07-11 18:54:12.000	Copper	0	2
2023-07-11 18:55:51.000	Copper	0	14
2023-07-11 19:02:46.000	Copper	0	2
2023-07-11 09:45:57.000	Copper	11	0
2023-07-11 09:46:09.000	Copper	20	0
2023-07-11 09:46:13.000	Copper	11	0
2023-07-11 09:46:17.000	Copper	12	0
2023-07-11 12:13:35.000	Copper	68	0
2023-07-11 12:13:35.000	Copper	1	0
2023-07-11 12:15:18.000	Copper	23	0
2023-07-11 12:24:07.000	Copper	69	0
2023-07-11 12:26:01.000	Copper	77	0
2023-07-11 12:28:54.000	Copper	66	0
2023-07-11 17:55:03.000	Copper	16	0
2023-07-11 17:55:03.000	Copper	5	0
2023-07-11 17:59:44.000	Copper	483	0
2023-07-11 17:59:44.000	Copper	2	0
2023-07-11 18:03:43.000	Copper	24	0
2023-07-11 18:03:50.000	Copper	25	0
2023-07-11 18:08:16.000	Copper	90	0
2023-07-11 18:08:58.000	Copper	12	0
2023-07-11 18:09:52.000	Copper	24	0
2023-07-11 18:33:55.000	Copper	166	0
2023-07-11 18:34:49.000	Copper	156	0
2023-07-11 18:42:04.000	Copper	280	0
2023-07-11 18:42:04.000	Copper	1	0
2023-07-11 18:44:26.000	Copper	181	0
2023-07-11 18:54:04.000	Copper	104	0
2023-07-11 18:54:12.000	Copper	21	0
2023-07-11 18:59:57.000	Copper	25	0
2023-07-11 19:02:56.000	Copper	42	0
2023-07-11 19:03:00.000	Copper	21	0
2023-07-11 19:03:05.000	Copper	281	0
2023-07-11 19:04:11.000	Copper	43	0
2023-07-11 19:04:38.000	Copper	6	0
2023-07-11 19:04:59.000	Copper	225	0
2023-07-11 20:57:40.000	Copper	0	8
2023-07-11 22:52:26.000	Copper	0	1
2023-07-11 22:54:00.000	Copper	0	3
2023-07-11 22:54:30.000	Copper	0	3
2023-07-11 22:55:17.000	Copper	0	9
2023-07-11 22:55:50.000	Copper	0	12
2023-07-11 22:59:41.000	Copper	11	0
2023-07-11 23:01:12.000	Copper	12	0
2023-07-11 23:02:05.000	Copper	24	0
2023-07-11 23:05:17.000	Copper	10	0
2023-07-12 00:28:17.000	Copper	68	0
2023-07-12 00:31:15.000	Copper	9	0
2023-07-12 00:32:54.000	Copper	191	0
2023-07-12 01:23:07.000	Copper	113	0
2023-07-12 01:23:53.000	Copper	20	0
2023-07-12 01:26:03.000	Copper	30	0
2023-07-12 01:26:03.000	Copper	1	0
2023-07-12 01:26:27.000	Copper	24	0
2023-07-12 01:28:13.000	Copper	147	0
2023-07-12 01:28:56.000	Copper	12	0
2023-07-12 01:29:29.000	Copper	45	0
2023-07-12 01:29:53.000	Copper	12	0
2023-07-12 01:30:16.000	Copper	23	0
2023-07-12 01:30:51.000	Copper	103	0
2023-07-12 01:31:25.000	Copper	12	0
2023-07-12 01:41:38.000	Copper	21	0
2023-07-12 01:42:36.000	Copper	157	0
2023-07-12 01:43:18.000	Copper	45	0
2023-07-12 01:42:44.000	Copper	73	0
2023-07-12 01:52:35.000	Copper	18	0
2023-07-12 01:53:33.000	Copper	9	0
2023-07-12 01:54:52.000	Copper	35	0
2023-07-12 01:55:38.000	Copper	132	0
2023-07-12 02:14:26.000	Copper	25	0
2023-07-12 03:00:03.000	Copper	36	0
2023-07-12 03:00:09.000	Copper	93	0
2023-07-12 03:49:44.000	Copper	33	0
...
181筆資料
*/

)

select x.Interval
         ,x.Line
         ,'Qty'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Qty
                             else null 
                             end 
         ,'Loss'=case when DateAdd(mi, 120, getdate())>x.Interval then x.Loss
                             else null 
                             end 
         ,'TargetQty'=x.TargetQty/2
from (
select 'Interval'=DateAdd(mi, 440+120, @YYYYMMDD)
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
          ,'TargetQty'=1*@Stripper*@TargetOutput300mm/12   --1*1.05*12800/12
from TempA a
where ( (a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 560, @YYYYMMDD) ) or
               a.Print_Date<DateAdd(mi, 440, @YYYYMMDD)  or
               a.Print_Date>=DateAdd(mi, 1880, @YYYYMMDD) 
            )
group by a.Line

union all
select 'Interval'=DateAdd(mi, 560+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=2*@Stripper*@TargetOutput300mm/12   --2*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD)  and a.Print_Date<DateAdd(mi, 680, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 680+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=3*@Stripper*@TargetOutput300mm/12   --3*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 800, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 800+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=4*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 920, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 920+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=5*@Stripper*@TargetOutput300mm/12   --5*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1040, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1040+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=6*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1160, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1160+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=7*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1280, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1280+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=8*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1400, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1400+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=9*@Stripper*@TargetOutput300mm/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1520, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1520+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=10*@Stripper*@TargetOutput300mm/12   --10*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1640, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1640+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=11*@Stripper*@TargetOutput300mm/12   --11*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1760, @YYYYMMDD)
group by a.Line

union all
select 'Interval'=DateAdd(mi, 1760+120, @YYYYMMDD) 
          ,a.Line
          ,'Qty'=sum(a.Qty)
          ,'Loss'=sum(a.Loss)
         ,'TargetQty'=12*@Stripper*@TargetOutput300mm/12   --12*1.05*12800/12
from TempA a
where a.Print_Date>=DateAdd(mi, 440, @YYYYMMDD) and a.Print_Date<DateAdd(mi, 1880, @YYYYMMDD) 
group by a.Line
) x


GO


/*
執行時間為:20230721 09:05
產生結果如下 
Interval	            Line	     	Qty		Loss	TargetQty
-----------------------------------------------------------------
2023-07-11 09:20:00	    Non-Copper	    36	    0	    560
2023-07-11 11:20:00	    Copper	        54	    4	    1120
2023-07-11 11:20:00	    Non-Copper	    296	    30	    1120
2023-07-11 13:20:00	    Copper	        677	    4	    1680
2023-07-11 13:20:00	    Non-Copper	    342	    66	    1680
2023-07-11 15:20:00	    Copper	        884	    9	    2240
2023-07-11 15:20:00	    Non-Copper	    430	    79	    2240
2023-07-11 17:20:00	    Copper	        1522	15	    2800
2023-07-11 17:20:00	    Non-Copper	    788	    105	    2800
2023-07-11 19:20:00	    Copper	        3859	93	    3360
2023-07-11 19:20:00	    Non-Copper	    1053	198	    3360
2023-07-11 21:20:00	    Copper	        3975	101	    3920
2023-07-11 21:20:00	    Non-Copper	    1061	198	    3920
2023-07-11 23:20:00	    Copper	        4219	165	    4480
2023-07-11 23:20:00	    Non-Copper	    1061	198	    4480
2023-07-12 01:20:00	    Copper	        4487	181	    5040
2023-07-12 01:20:00	    Non-Copper	    1061	198	    5040
2023-07-12 03:20:00	    Copper	        5673	220	    5600
2023-07-12 03:20:00	    Non-Copper	    1180	245	    5600
2023-07-12 05:20:00	    Copper	        6063	258	    6160
2023-07-12 05:20:00	    Non-Copper	    1396	340	    6160
2023-07-12 07:20:00	    Copper	        7772	273	    6720
2023-07-12 07:20:00	    Non-Copper	    2584	495	    6720
*/