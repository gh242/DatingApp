DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';
DECLARE @TargetOutput200mm int;
SET @TargetOutput200mm = 2560;


with
TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
),
tempC as (
select 'N'=(N-440)/120*@TargetOutput200mm/12, 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempB
)
select * from tempC

--N		Interval
-------	------
--426	2023-07-04 11:20:00
--640	2023-07-04 13:20:00
--853	2023-07-04 15:20:00
--1066	2023-07-04 17:20:00
--1280	2023-07-04 19:20:00
--1493	2023-07-04 21:20:00
--1706	2023-07-04 23:20:00
--1920	2023-07-05 01:20:00
--2133	2023-07-05 03:20:00
--2346	2023-07-05 05:20:00
--2560	2023-07-05 07:20:00