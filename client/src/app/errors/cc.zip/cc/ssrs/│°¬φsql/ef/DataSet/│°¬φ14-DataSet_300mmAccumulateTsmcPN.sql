USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230712';

  select 'Seq'=case when CustomerPN like 'V650000T%' then 5
                    when CustomerPN like 'V650000Q%' then 10
                    when CustomerPN like 'V650000P%' then 11
                    when CustomerPN like 'V650000O%' then 12
                    when CustomerPN like 'V650000[ABCN]%' then 13
                    when CustomerPN like 'V650000[DEF]%' then 14
                    when CustomerPN like 'V650003P%' then 21
                    when CustomerPN like 'V650003O%' then 22
                    when CustomerPN like 'V650003[ABCN]%' then 23
                    when CustomerPN like 'V650006[DEF]%' then  24
                    when CustomerPN like 'V650004P%' then 31
                    when CustomerPN like 'V650004O%' then 32
                    when CustomerPN like 'V650004[ABCN]%' then 33
                    when CustomerPN like 'V650007[DEF]%'then  34
                    when CustomerPN='V600001' then  41
                    when CustomerPN='V65000013O' then 51
                    when CustomerPN='V65000013A' then 52
                    when CustomerPN like 'V65000013[DEF]%' then 53
                    when CustomerPN='V65000311D' then 61
                    when CustomerPN like 'V65000313%' then 62
                    else 99
                    end,
  'CustomerPN'=case when CustomerPN like 'V650000[DEF]%' then 'V650000F'
                    when CustomerPN like 'V650006[DEF]%' then 'V650006F'
                    when CustomerPN like 'V650007[DEF]%' then 'V650007F'
                    when CustomerPN like 'V650000[ABCN]%' then 'V650000A'
                    when CustomerPN like 'V650003[ABCN]%' then 'V650003A'
                    when CustomerPN like 'V650004[ABCN]%' then 'V650004A'
                    when CustomerPN like 'V650000Q%' then 'V650000Q' 
                    when CustomerPN like 'V650000P%' then 'V650000P' 
                    when CustomerPN like 'V650000O%' then 'V650000O' 
                    when CustomerPN like 'V650003O%' then 'V650003O' 
                    when CustomerPN like 'V650004O%' then 'V650004O'
                    when CustomerPN like 'V65000311D%' then 'V65000311D'
                    when CustomerPN like 'V600001%' then 'V600001'
                    when CustomerPN like 'V65000013[DEF]%' then 'V65000013F'
                    else rtrim(CustomerPN)
                    end
          ,'Qty'=sum(Qty)
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between @YYYYMMDD-Day(@YYYYMMDD)+1 and @YYYYMMDD
and Customer='TSC'
      group by case when CustomerPN like 'V650000T%' then 5
                    when CustomerPN like 'V650000Q%' then 10
                    when CustomerPN like 'V650000P%' then 11
                    when CustomerPN like 'V650000O%' then 12
                    when CustomerPN like 'V650000[ABCN]%' then 13
                    when CustomerPN like 'V650000[DEF]%' then 14
                    when CustomerPN like 'V650003P%' then 21
                    when CustomerPN like 'V650003O%' then 22
                    when CustomerPN like 'V650003[ABCN]%' then 23
                    when CustomerPN like 'V650006[DEF]%' then  24
                    when CustomerPN like 'V650004P%' then 31
                    when CustomerPN like 'V650004O%' then 32
                    when CustomerPN like 'V650004[ABCN]%' then 33
                    when CustomerPN like 'V650007[DEF]%'then  34
                    when CustomerPN='V600001' then  41
                    when CustomerPN='V65000013O' then 51
                    when CustomerPN='V65000013A' then 52
                    when CustomerPN like 'V65000013[DEF]%' then 53
                    when CustomerPN='V65000311D' then 61
                    when CustomerPN like 'V65000313%' then 62
                    else 99
                    end,
                case when CustomerPN like 'V650000[DEF]%' then 'V650000F'
                    when CustomerPN like 'V650006[DEF]%' then 'V650006F'
                    when CustomerPN like 'V650007[DEF]%' then 'V650007F'
                    when CustomerPN like 'V650000[ABCN]%' then 'V650000A'
                    when CustomerPN like 'V650003[ABCN]%' then 'V650003A'
                    when CustomerPN like 'V650004[ABCN]%' then 'V650004A'
                    when CustomerPN like 'V650000Q%' then 'V650000Q' 
                    when CustomerPN like 'V650000P%' then 'V650000P' 
                    when CustomerPN like 'V650000O%' then 'V650000O' 
                    when CustomerPN like 'V650003O%' then 'V650003O' 
                    when CustomerPN like 'V650004O%' then 'V650004O'
                    when CustomerPN like 'V65000311D%' then 'V65000311D'
                    when CustomerPN like 'V600001%' then 'V600001'
                    when CustomerPN like 'V65000013[DEF]%' then 'V65000013F'
                    else rtrim(CustomerPN)
                    end


union all
select 'Seq'=100
          ,'CustomerPN'='RCS-Rework'
          ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between left(convert(char(8), @YYYYMMDD, 112), 6)+'01'  and convert(char(8), @YYYYMMDD, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
and MFG_MOVE>0

GO

/*
產生結果如下  20230718 執行時間，為20230718 16:05
Seq	CustomerPN	    Qty
------------------------
41	V600001	        1000
99	V600001	        75
99	V600011	        100
52	V65000013A	    3175
53	V65000013F	    175
99	V65000013P	    575
13	V650000A	    8625
14	V650000F	    5075
11	V650000P	    2625
10	V650000Q	    2075
5	V650000T	    850
61	V65000311D	    975
99	V65000311D	    2700
62	V65000313C	    2150
62	V65000313C1	    1900
62	V65000313C3	    475
23	V650003A	    32675
21	V650003P	    7475
33	V650004A	    25225
31	V650004P	    950
24	V650006F	    22325
34	V650007F	    10675
99	V650021A	    3975
99	V650021B	    225
99	V650021D	    100
99	V650021F	    2575
99	V650021P	    2200
99	V650021Q	    2450
99	V650022A	    25
99	V650022F	    25
100	RCS-Rework	    -3517
*/