--SELECT 'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
--                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
--FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock), [EDC].[dbo].[View_PackingImageFN] B WITH (nolock)
--WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
--                   A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
--                   A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
--                   A.FG_MFGDate > '20150101' AND A.FG_MFGDate <> '20201213' AND 
--                   A.FG_MFGDate <> '20201214' /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
--                    A.FG_Valid = 'Y' /* 1234567890123456789012345678901234567*/ AND A.FG_BarCode1 = substring(B.Barcode, 1, 1) AND 
--                   A.FG_BarCode2 = substring(B.Barcode, 3, 8) AND A.FG_BarCode3 = substring(B.Barcode, 12, 10) AND 
--                   A.FG_BarCode4 = substring(B.Barcode, 23, 10) AND A.FG_BarCode5 = substring(B.Barcode, 33, 2) AND 
--                   A.FG_BarCode6 = substring(B.Barcode, 36, 2)


--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:29
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------
-- Outside	2022-09-03 00:00:00.000	20220903	6C-29-0005	95M9U1	25	2022-09-04 03:39:13.000
-- Outside	2022-09-03 00:00:00.000	20220903	V650003P	2SM8C1	25	2022-09-04 00:29:53.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650000F	2AM8E1	25	2022-09-04 09:06:00.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650000A	2AM8E1	25	2022-09-04 17:55:31.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650000F	2AM8E1	25	2022-09-04 09:36:58.000
-- Outside	2022-09-04 00:00:00.000	20220904	V65000013A	26M8R1	25	2022-09-04 21:15:21.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650006F	26M8R1	25	2022-09-04 23:08:48.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650007D	22M8J1	25	2022-09-04 14:50:27.000
-- Outside	2022-09-04 00:00:00.000	20220904	V650000A	21M8E1	25	2022-09-04 18:52:50.000
-- Outside	2021-07-17 00:00:00.000	20210717	V650000F	2SL7E1	25	2021-07-18 04:35:28.000
-- Outside	2021-07-18 00:00:00.000	20210718	V650004A	26L7J1	25	2021-07-18 18:43:21.000
-- Outside	2021-07-18 00:00:00.000	20210718	V650004A	26L7J1	25	2021-07-18 17:56:18.000
-- Outside	2021-07-17 00:00:00.000	20210717	V650004P	26L7J1	25	2021-07-18 00:43:29.000


--SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
--                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
--FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock), [EDC].[dbo].[View_PackingImageFN] B WITH (nolock)
--WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
--                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
--                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND A.FG_MFGDate > '20150101' AND 
--                   A.FG_MFGDate <> '20201213' AND 
--                   A.FG_MFGDate <> '20201214' /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
--                    A.FG_Valid = 'Y' AND A.FG_BarCode1 = substring(B.Barcode, 1, 1) AND A.FG_BarCode2 = substring(B.Barcode, 3, 8) AND 
--                   A.FG_BarCode3 = substring(B.Barcode, 12, 10) AND A.FG_BarCode4 = substring(B.Barcode, 23, 10) AND 
--                   A.FG_BarCode5 = substring(B.Barcode, 33, 2) AND A.FG_BarCode6 = substring(B.Barcode, 36, 2)

--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:31
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------
--Inside	2023-04-20 00:00:00.000	20230420	             PSD2MZ	25	2023-04-20 15:34:30.000
--Inside	2023-04-20 00:00:00.000	20230420	             PSD2MZ	25	2023-04-20 12:50:25.000
--Inside	2022-09-21 00:00:00.000	20220921	             95M9X1	25	2022-09-21 18:22:11.000
--Inside	2022-06-04 00:00:00.000	20220604	             9YM5X1	25	2022-06-04 14:45:12.000
--Inside	2023-04-20 00:00:00.000	20230420	             PSD2MZ	25	2023-04-20 08:36:05.000
--Inside	2022-07-20 00:00:00.000	20220720	             9YM7X1	25	2022-07-21 05:48:08.000
--Inside	2022-08-15 00:00:00.000	20220815	             95M8X1	25	2022-08-15 16:15:25.000
--Inside	2022-09-24 00:00:00.000	20220924	             9YM5X1	25	2022-09-24 15:36:11.000
--Inside	2021-09-23 00:00:00.000	20210923	C021-0003X   9KL9X3	25	2021-09-23 13:26:51.000
--Inside	2021-08-18 00:00:00.000	20210818	             95L6X5	25	2021-08-19 01:38:40.000
--Inside	2022-10-07 00:00:00.000	20221007	             95MAX1	25	2022-10-07 20:13:55.000


--SELECT  'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
--                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
--FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
--WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
--                   A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
--                   A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
--                   (A.FG_MFGDate = '20201213' OR
--                   A.FG_MFGDate = '20201214') 
--                   /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
--                    A.FG_Valid = 'Y'

--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:31
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------
-- Outside	2020-12-13 00:00:00.000	20201213	V65000013P	2SKBH1	25	2020-12-14 00:33:55.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650006D	26KBC1	25	2020-12-14 20:53:08.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650003A	26KBC1	25	2020-12-14 11:22:09.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650003A	26KBC1	25	2020-12-14 11:42:45.000
-- Outside	2020-12-13 00:00:00.000	20201213	V650007F	21KBJ1	25	2020-12-14 00:15:13.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650006D	26KBC1	25	2020-12-14 12:38:13.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650007D	21KBJ1	25	2020-12-14 08:16:26.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650003A	26KBC1	25	2020-12-14 15:56:55.000
-- Outside	2020-12-13 00:00:00.000	20201213	V650004A	21KBJ1	25	2020-12-14 00:18:04.000
-- Outside	2020-12-14 00:00:00.000	20201214	V650006D	26KBC1	25	2020-12-14 18:32:08.000


--SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
--                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
--FROM      [RCS].[dbo].[FG_Barcode] A WITH (nolock)
--WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
--                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
--                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND (A.FG_MFGDate = '20201213' OR
--                   A.FG_MFGDate = '20201214') 
--                   /*and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )*/ AND
--                    A.FG_Valid = 'Y'

--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:31
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------
--�S���

-- SELECT  'Category' = 'Outside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
--                    + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, 'FG_Customer' = rtrim(A.FG_Customer), 
--                    'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
-- FROM      [RCS].[dbo].[FG_Barcode_His] A WITH (nolock)
-- WHERE   A.FG_BarCode4 LIKE '[1-9]%' AND A.FG_BarCode4 NOT LIKE '3[KM]__X%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE '9[5BCHKYT]__X_%' /*internal revenue*/ AND 
--                    A.FG_BarCode4 NOT LIKE '[39]___[QVW]%' /*Oxide*/ AND A.FG_Customer <> 'V65000313G' AND 
--                    A.FG_MFGDate > '20150101'

--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:31
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------          
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 12:02:58.000
-- Outside	2019-06-18 00:00:00.000	20190618	02-14-0004	6AJ6E2	25	2019-06-19 06:00:04.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 18:04:06.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 12:31:09.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 16:51:25.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 23:53:48.000
-- Outside	2019-06-18 00:00:00.000	20190618	02-14-0004	6AJ6E2	25	2019-06-19 02:46:48.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 16:27:33.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0004	6AJ6E2	25	2019-06-19 11:23:03.000
-- Outside	2019-06-19 00:00:00.000	20190619	02-14-0003	6AJ6E2	25	2019-06-19 13:52:43.000


SELECT  'Category' = 'Inside', 'MFG_Date' = cast(LEFT(A.FG_MFGDate, 4) + '-' + subString(A.FG_MFGDate, 5, 2) 
                   + '-' + RIGHT(A.FG_MFGDate, 2) AS datetime), 'MFGDate' = A.FG_MFGDate, A.FG_Customer, 
                   'LotNo' = LEFT(A.FG_BarCode4, 6), 'Qty' = cast(A.FG_BarCode6 AS integer), Print_Date
FROM      [RCS].[dbo].[FG_Barcode_His] A WITH (nolock)
WHERE   (A.FG_BarCode4 LIKE '3[KM]__X%' OR
                   A.FG_BarCode4 LIKE '9[5BCHKYT]__X_%' OR
                   A.FG_BarCode4 LIKE 'PS_2[ME]_%') AND A.FG_Customer <> 'V65000313G' AND A.FG_MFGDate > '20150101'

--���͵��G�p�U  20230717 ����ɶ��A��20230717 13:31
--Category	MFG_Date				MFGDate	    FG_Customer	LotNo	Qty	Print_Date
-----------------------------------------------------------------------------------------------  
-- Inside	2021-09-09 00:00:00.000	20210909	             95L3X4	25	2021-09-10 03:11:44.000
-- Inside	2021-09-09 00:00:00.000	20210909	             95L3X4	25	2021-09-09 13:17:53.000
-- Inside	2021-09-09 00:00:00.000	20210909	             95L3X4	25	2021-09-10 04:30:58.000
-- Inside	2021-09-09 00:00:00.000	20210909	             95L3X4	25	2021-09-09 13:57:17.000
-- Inside	2021-07-13 00:00:00.000	20210713	C021-0003X   9KL7X1	25	2021-07-13 18:53:22.000
-- Inside	2021-07-13 00:00:00.000	20210713	C021-0003X   9KL7X1	25	2021-07-13 17:18:52.000
-- Inside	2021-09-09 00:00:00.000	20210909	             95L3X4	25	2021-09-10 02:10:38.000
-- Inside	2021-08-29 00:00:00.000	20210829	             95L8X1	25	2021-08-29 13:22:43.000