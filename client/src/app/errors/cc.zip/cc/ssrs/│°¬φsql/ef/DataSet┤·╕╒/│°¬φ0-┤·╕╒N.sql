with TempB as (
select N=440+120+120
union all 
select N+120 from TempB where N<1880
)
select * from TempB

--N
------
--680
--800
--920
--1040
--1160
--1280
--1400
--1520
--1640
--1760
--1880