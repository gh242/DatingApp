DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230704';

DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;

with TempA as (
select Print_Date
         ,'HighT'=Qty
         ,'HighQ'=0
         ,'HighP'=0
         ,'Normal'=0
         ,'Low'=0
from SSRS_Output_300mm_Time with(nolock)
where MFG_Date=@YYYYMMDD
and FG_Customer like 'V65%[T]'
union all
--select Print_Date
--         ,'HighT'=0
--         ,'HighQ'=Qty
--         ,'HighP'=0
--         ,'Normal'=0
--         ,'Low'=0
--from SSRS_Output_300mm_Time with(nolock)
--where MFG_Date=@YYYYMMDD
--and FG_Customer like 'V65%[Q]'

select 'Print_Date'=DateAdd(mi, 1760, @YYYYMMDD)
         ,'HighT'=0
         ,'HighQ'=0
         ,'HighP'=0
          ,'Normal'=-1*MANU_QTY
          ,'Low'=0
from [RCS_NEW].[dbo].[FN_MANUFACTURE] with(nolock)
where MANU_MFGDATE=convert(char(8), @YYYYMMDD, 112) 
and MANU_FROM_EQUID=810
and MANU_FROM_LOTNO like '%RR%'
AND MANU_FMLB='M'
and MANU_QTY>0
)

select * from TempA

-- Print_Date				HigthT HightQ HightP Normal Low
-----------------------------------------------------
--2023-07-05 05:20:00.000	0	0	0	-25	    0
--2023-07-05 05:20:00.000	0	0	0	-25	    0
--2023-07-05 05:20:00.000	0	0	0	-75	    0
--2023-07-05 05:20:00.000	0	0	0	-75	    0
--2023-07-05 05:20:00.000	0	0	0	-175	0
--2023-07-05 05:20:00.000	0	0	0	-225	0