USE [EDC]
GO

/****** Object:  View [dbo].[EDC_VIEW_810_Map_T7ID_FN]    Script Date: 2023/7/26 上午 10:33:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







/*C(hart_SP_RPW350.Thickness_Center + 2)

 				     Left Join Chart_Day_Mapping
 	   On EDC_VIEW_810_Map.Station_Name=Chart_Day_Mapping.StationName
	 And EDC_VIEW_810_Map.Collection_Time=Chart_Day_Mapping.CollectionTime
	
Where Collection_Time>'2006-03-07 07:20:00'*/
ALTER VIEW [dbo].[EDC_VIEW_810_Map_T7ID_FN]
AS

SELECT    dbo.EDC_VIEW_810_Map.STATION_NAME, dbo.EDC_VIEW_810_Map.COLLECTION_TIME, dbo.EDC_VIEW_810_Map.SourceSlot, 
                      dbo.EDC_VIEW_810_Map.DestinationSlot, dbo.EDC_VIEW_810_Map.Lot_ID, CASE WHEN dbo.EDC_VIEW_810_Map.Lot_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADED' THEN 'GRADED3' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.045-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.032-CLEAN' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = '45-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = '45-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = '45-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = '45-SORT' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-GRADE-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEO' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEOB' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 500 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 180 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.045-CLEAN-8' AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEN' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-GRADE' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEN' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEN' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-SORT' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEN' THEN CASE WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2___[FN]%' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 300 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20 THEN 'POLISH' WHEN dbo.EDC_VIEW_810_Map.LOT_ID LIKE '2%' AND 
                      dbo.EDC_VIEW_810_Map.LOT_ID NOT LIKE '2___[FN]%' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 180 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 < 500) OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_19 > 20) 
                      THEN 'POLISH' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-DEF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = '65-DEF-3MM-SORT') AND 
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED' THEN 'GRADEF' WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-AF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'SI-0.065-ADF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-AF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-ADF' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-AF-3MM' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-0.065-ADF-3MM') 
                      THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' THEN 'REJECTED' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname
                       = '9XE309-3' THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 + dbo.EDC_VIEW_810_Map.FLAW_COUNTS_24) 
                      > 15 THEN 'GRADEB' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' THEN 'REJECTED' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname
                       = 'PSC-12M' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'PSC-12M-SORT') THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADES' AND 
                      ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 25 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 <= 45) AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 <= 20)) 
                      THEN 'GRADEA' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADES' AND (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 20) THEN 'GRADEB' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15) AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 <= 90 THEN 'GRADEB' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 90 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15) THEN 'REPOLISH' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEB' AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 90 THEN 'REPOLISH' WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'UMC306-3' OR
                      dbo.EDC_VIEW_810_Map.ppexecname = 'EG-UMC306-3') THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'PASS' AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 30 THEN 'RECLEAN' WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname LIKE 'UMC306-3%' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'EG-UMC306-3%') THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname LIKE '%MX308-3%' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE
                       = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'TEST-POLISH' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'TEST-POLISH-%') THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN (dbo.EDC_VIEW_810_Map.ppexecname = 'T3E-TD1G' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'T3E-XD1G' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'T6E-TDG' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'T6E-YZDG' OR
                      dbo.EDC_VIEW_810_Map.ppexecname LIKE 'T4E-T5-[TX]DG') THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE LIKE 'GRADEG%' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE LIKE 'REJECT%') 
                      THEN 'GRADEG' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname LIKE 'WB309-3%' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE
                       = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECTED' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'IMI305-3' THEN CASE WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE
                       = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname = 'JB309-5' THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE
                       = 'GRADEA' AND (dbo.EDC_VIEW_810_Map.Flaw_Counts_4 + dbo.EDC_VIEW_810_Map.Flaw_Counts_27) 
                      > 30 THEN 'REPOLISH' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' THEN 'REJECTED' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname
                       = 'JB309-3' THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.Flaw_Counts_5 + dbo.EDC_VIEW_810_Map.Flaw_Counts_28) 
                      > 25 THEN 'REPOLISH' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' THEN 'REJECTED' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END WHEN dbo.EDC_VIEW_810_Map.ppexecname
                       = 'PSC-12M-DEF' THEN CASE WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADES' AND ((dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 25 AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 <= 45) AND (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15 AND dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 <= 20)) 
                      THEN 'GRADEA' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADES' AND (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 20) THEN 'GRADEB' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15) AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 <= 90 THEN 'GRADEB' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEA' AND 
                      (dbo.EDC_VIEW_810_Map.FLAW_COUNTS_1 > 45 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 90 OR
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_4 > 15) THEN 'REJECT' WHEN dbo.EDC_VIEW_810_Map.WAFERGRADE = 'GRADEB' AND 
                      dbo.EDC_VIEW_810_Map.FLAW_COUNTS_2 > 90 THEN 'REJECT' WHEN (dbo.EDC_VIEW_810_Map.WAFERGRADE = 'OVERLOAD' OR
                      dbo.EDC_VIEW_810_Map.WAFERGRADE = 'REJECTED') 
                      THEN 'REJECT' ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END ELSE dbo.EDC_VIEW_810_Map.WAFERGRADE END AS WAFERGRADE, 
                      dbo.EDC_VIEW_810_Map.PPExecName, dbo.EDC_VIEW_810_Map.Flaw_Counts_0, dbo.EDC_VIEW_810_Map.Flaw_Counts_1, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_2, dbo.EDC_VIEW_810_Map.Flaw_Counts_3, dbo.EDC_VIEW_810_Map.Flaw_Counts_4, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_5, dbo.EDC_VIEW_810_Map.Flaw_Counts_6, dbo.EDC_VIEW_810_Map.Flaw_Counts_7, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_8, dbo.EDC_VIEW_810_Map.Flaw_Counts_9, dbo.EDC_VIEW_810_Map.Flaw_Counts_10, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_11, dbo.EDC_VIEW_810_Map.Flaw_Counts_12, dbo.EDC_VIEW_810_Map.Flaw_Counts_13, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_14, dbo.EDC_VIEW_810_Map.Flaw_Counts_15, dbo.EDC_VIEW_810_Map.Flaw_Counts_16, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_17, dbo.EDC_VIEW_810_Map.Flaw_Counts_18, dbo.EDC_VIEW_810_Map.Flaw_Counts_19, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_20, dbo.EDC_VIEW_810_Map.Flaw_Counts_21, dbo.EDC_VIEW_810_Map.Flaw_Counts_22, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_23, dbo.EDC_VIEW_810_Map.Flaw_Counts_24, dbo.EDC_VIEW_810_Map.Flaw_Counts_25, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_26, dbo.EDC_VIEW_810_Map.Flaw_Counts_27, dbo.EDC_VIEW_810_Map.Flaw_Counts_28, 
                      dbo.EDC_VIEW_810_Map.Flaw_Counts_29, dbo.EDC_VIEW_810_Map.HazeAverage, dbo.EDC_VIEW_810_Map.HazePeak, dbo.EDC_VIEW_810_Map.DFNHazeAvg, 
                      dbo.EDC_VIEW_810_Map.DFNHazePeak, dbo.EDC_VIEW_810_Map.Sumofallcount_Unclustered, dbo.EDC_VIEW_810_Map.DFTotalSlipLineLength, 
                      dbo.EDC_VIEW_810_Map.KlarfName, CASE WHEN EDC_DATA_RPW350.[T7_ID1] = 'ERROR' AND 
                      EDC_DATA_RPW350.[T7_ID2] = 'ERROR' THEN 'NONE' WHEN EDC_DATA_RPW350.[T7_ID1] = 'ERROR' AND 
                      EDC_DATA_RPW350.[T7_ID2] <> 'ERROR' THEN LEFT(EDC_DATA_RPW350.[T7_ID2], 10) ELSE LEFT(EDC_DATA_RPW350.[T7_ID1], 10) END AS T7ID, 
                      CASE WHEN (dbo.EDC_DATA_RPW350.Lot_ID LIKE '9[6XZ]%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE '7[28]%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE '44%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE '2%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE '1___M%' OR dbo.EDC_DATA_RPW350.Lot_ID LIKE '9U__[CD]%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE '5[13]%' OR dbo.EDC_DATA_RPW350.Lot_ID LIKE '6N%'  OR dbo.EDC_DATA_RPW350.Lot_ID LIKE '58__C%' OR
                      dbo.EDC_DATA_RPW350.Lot_ID LIKE 'PSG3E1%') THEN LEFT(dbo.EDC_DATA_RPW350.Lot_ID, 6) 
                      + dbo.EDC_DATA_RPW350.Sender WHEN dbo.EDC_DATA_RPW350.Lot_ID LIKE '2%' AND 
                      dbo.EDC_DATA_RPW350.Sender LIKE '2%' THEN dbo.EDC_DATA_RPW350.Sender ELSE dbo.EDC_DATA_RPW350.Lot_ID END AS RPW350_LotID, 
                      dbo.EDC_DATA_RPW350.File_Name AS RPW350_FileName, dbo.EDC_DATA_RPW350.Destination_Cassette AS DestCassette, 
                      dbo.EDC_DATA_RPW350.Destination_SlotNo AS DestSlotID, dbo.EDC_DATA_RPW350.Thickness_Center, dbo.EDC_DATA_RPW350.TTV, 
                      dbo.Chart_SP_RPW350.TTV_Before, dbo.EDC_DATA_RPW350.BowBf, dbo.EDC_DATA_RPW350.WarpBf, dbo.EDC_DATA_RPW350.Resistivity, 
                      dbo.EDC_DATA_RPW350.PN_Type, dbo.EDC_DATA_RPW350.Class, 
                      dbo.Chart_SP_RPW350.LastPolish_Thickness_Center_Before - dbo.Chart_SP_RPW350.Thickness_Center AS LastPolish_Thickness_Center_Variation, 
                      dbo.Chart_SP_RPW350.TTV - dbo.Chart_SP_RPW350.LastPolish_TTV_Before AS LastPolish_TTV_Variation, 
                      dbo.Chart_SP_RPW350.WarpBf - dbo.Chart_SP_RPW350.LastPolish_WarpBf_Before AS LastPolish_WarpBf_Variation, 
                      dbo.Chart_SP_RPW350.Thickness_Center_Before - dbo.Chart_SP_RPW350.Thickness_Center AS Thickness_Center_Variation, 
                      dbo.Chart_SP_RPW350.TTV - dbo.Chart_SP_RPW350.TTV_Before AS TTV_Variation, 
                      dbo.Chart_SP_RPW350.WarpBf - dbo.Chart_SP_RPW350.WarpBf_Before AS WarpBf_Variation, 
                      dbo.Chart_SP_RPW350.LastPolish_Collection_Time_Before AS LastPolish_Collection_Time, dbo.Chart_SP_RPW350.File_Name AS LastPolish_LotID, 
                      dbo.Chart_SP_RPW350.LastPolish_PN_Type_Before AS LastPolish_PN_Type_Variation, 
                      dbo.Chart_SP_RPW350.Thickness_Center_Before_Visera - dbo.Chart_SP_RPW350.Thickness_Center AS Thickness_Center_Variation_Visera, 
                      dbo.EDC_VIEW_810_Map.Map,
					  T.Show
FROM         dbo.EDC_VIEW_810_Map WITH (Nolock) LEFT OUTER JOIN
                      dbo.EDC_DATA_RPW350 WITH (Nolock) ON dbo.EDC_VIEW_810_Map.STATION_NAME = dbo.EDC_DATA_RPW350.TBI_StationName AND 
                      dbo.EDC_VIEW_810_Map.COLLECTION_TIME = dbo.EDC_DATA_RPW350.TBI_CollectionTime LEFT OUTER JOIN
                      dbo.Chart_SP_RPW350 WITH (Nolock) ON dbo.EDC_VIEW_810_Map.STATION_NAME = dbo.Chart_SP_RPW350.TBI_StationName AND 
                      dbo.EDC_VIEW_810_Map.COLLECTION_TIME = dbo.Chart_SP_RPW350.TBI_CollectionTime AND 
                      dbo.Chart_SP_RPW350.Thickness_Center_Before > dbo.Chart_SP_RPW350.Thickness_Center
					  LEFT JOIN ( select distinct InlineLOT,Show from TableShot.dbo.View_SupplierACC) as T on SUBSTRING(EDC_VIEW_810_Map.Lot_ID,3,4)=SUBSTRING(T.InlineLOT,3,4)  And EDC_VIEW_810_Map.Lot_ID Like '[A-Z]%'
					
GO


