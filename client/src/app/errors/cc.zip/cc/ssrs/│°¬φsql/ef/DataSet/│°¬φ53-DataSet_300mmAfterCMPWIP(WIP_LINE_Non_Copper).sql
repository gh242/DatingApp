USE [RCS_New]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';
DECLARE @TargetOutput300mm int;
SET @TargetOutput300mm = 12800;
DECLARE @Stripper FLOAT;
SET @Stripper = 1.05;


with TempA as (
select N=440
union all 
select N+120 from TempA where N<1880
),

tempB as (
select 'Interval'=DateAdd(mi, N, @YYYYMMDD) from TempA
)

select 'Interval'=a.WIP_DATE
          ,a.WIP_LINE
          ,'Qty'=sum(a.WIP_QTY)
from FN_WIP_2HOUR a with(nolock), tempB b
where a.WIP_DATE=b.Interval
and (a.WIP_EQUID=670 or a.WIP_EQUID=663 or a.WIP_EQUID=680 or a.WIP_EQUID=755 or a.WIP_EQUID=810 or a.WIP_EQUID=811 or a.WIP_EQUID=815)  
group by a.WIP_DATE, a.WIP_LINE, a.WIP_EQUID


union all
select Interval, 'Non-Copper', 0 from tempB where getdate()>=Interval
union all
select Interval, 'Copper', 0 from tempB where getdate()>=Interval


GO