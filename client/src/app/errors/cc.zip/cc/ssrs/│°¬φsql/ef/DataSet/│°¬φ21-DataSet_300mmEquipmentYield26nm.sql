USE [WarInfo]
GO

DECLARE @YYYYMMDD SMALLDATETIME;
SET @YYYYMMDD = '20230711';

with TempA as (
-- Non-Copper
select 'Line'='Non-Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,'Pass'=sum(case when WAFERGRADE='GRADEQ' then 1
                                        else 0
                                        end)
          ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 25 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and (LotID like '[1-9]%' or LotID like 'PS__2%')
and LotID not like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner

/*
-- Copper
union all
select 'Line'='Copper'
           ,Polisher
          ,'PreCleaner'=PreCleaner+PreCleanSide
          ,FinalCleaner
          ,'Pass'=sum(case when WAFERGRADE='GRADEQ' then 1
                                        else 0
                                        end)
          ,'PassP'=sum(case when WAFERGRADE='GRADEP' then 1
                                        else 0
                                        end)
          ,'Total'=count(*)
from EDA_Tencorlog with(nolock)
where ( ParticleSize1 between 25 and 26 )
and CollectionTime>=DateAdd(n, 440, @YYYYMMDD) 
and CollectionTime<DateAdd(n, 440, @YYYYMMDD+1)
and LotID like '[1-9]___[BCDHLUYIS]%'
and LotID not like '5-%'
and LotID not like 'EG%'
and LotID not like '%SPC'
and LotID not like '%-R[RT]'
and LotID not like '%-QQ'
and LotID not like '____[QW]%'
and LotID not like '%TEST%'
group by Polisher, PreCleaner+PreCleanSide, FinalCleaner
*/
)


select a.*
         ,'Fail'=a.Total-a.Pass-a.PassP
          ,'Yield'=1.0000*a.Pass/a.Total
          ,'YieldP'=1.0000*a.PassP/a.Total
from TempA a

GO

/*
執行時間為:20230719 10:25
產生結果如下 
Line	    Polisher	PreCleaner	FinalCleaner	Pass	PassP	Total	Fail	Yield	            YieldP
-------------------------------------------------------------------------------------------------------------------------
Non-Copper	19	        Ebara4L	    ACM1	        12	    2	    15	    1	    0.800000000000000	0.133333333333333
Non-Copper	18	        Ebara4R	    ACM1	        22	    1	    24	    1	    0.916666666666666	0.041666666666666
*/