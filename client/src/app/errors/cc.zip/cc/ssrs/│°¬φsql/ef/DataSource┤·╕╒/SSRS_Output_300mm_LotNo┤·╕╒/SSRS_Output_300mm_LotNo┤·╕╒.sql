USE [WarInfo]
GO

/*
 [RCS].[dbo].[FG_Barcode]
 [EDC].[dbo].[View_PackingImageFN]

*/

/****** Object:  View [dbo].[SSRS_Output_300mm_LotNo]    Script Date: 2023/7/24 上午 11:06:45 ******/
-- SET ANSI_NULLS ON
-- GO

-- SET QUOTED_IDENTIFIER ON
-- GO

-- ALTER VIEW [dbo].[SSRS_Output_300mm_LotNo]
-- AS
select x.Category
      ,'MFGDate'=cast(left(x.MFGDate, 4)+'-'+subString(x.MFGDate, 5, 2)+'-'+right(x.MFGDate, 2) as datetime)
	  ,'MFGShift'=case when MFGShift='A' or MFGShift='C' then 'D' -- 如果是A或C, 顯示D
	                   when MFGShift='B' or MFGShift='D' then 'N' -- 如果是B或D, 顯示N
					   else 'N/A'
				  end
      ,x.Customer
      ,'PsiPN'=x.FG_PSI
      ,'CustomerPN'=case when x.FG_Customer='' or x.FG_Customer is null then 'N/A' -- 如果FG_Customer是空或是null，顯示'N/A'
                         ELSE rtrim(x.FG_Customer)
                	end
      ,x.LotNo
      ,x.Qty
	FROM (
-----------------------------------1.Outside-------A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'-------------------------------------------
		-- Outside
		select 
			-- top(20)*
			--'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)  -- 3WSTSCCRELKX001 從第4碼取3碼 TSC
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImageFN] B  with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
/*
select top(20)* from [RCS].[dbo].[FG_Barcode]
FG_MFGDate	FG_MFGType	FG_PSI				FG_Customer		FG_BarCode1	FG_BarCode2	FG_BarCode3	FG_BarCode4	FG_BarCode5	FG_BarCode6	FG_WaferGrade	FG_BoxNo	FG_AutoPrint	FG_Account	FG_Valid	Print_Date				Print_Times	Print_Mode
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
20201128	D			3WSTSCCRELKX001   	V650007F        5			20201129	7Z706407SL	2TKBJ17F0B	 			25			NULL			051 		Y				EDCUSER		Y			2020-11-29 03:17:01.000	1			X
20201128	D			3WSTSCCRELKX001   	V650004A        5			20201129	7Z730M04SL	2TKBJ14AXB	 			25			NULL			052 		Y				EDCUSER		Y			2020-11-29 03:32:53.000	1			X
20201129	D			3WSTSCCRELKX001   	V650003P        5			20201129	8A344M79SL	2BKBC13P0B	 			25			NULL			255 		Y				EDCUSER		Y			2020-11-29 22:09:34.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003P        5			20201129	8C102316SL	2BKBC13P0B	 			25			NULL			178 		Y				EDCUSER		Y			2020-11-29 15:09:40.000	1			X
20201129	A			3WSTSCCRELKX001   	V650007F        5			20201129	8C211B55SL	2TKBJ17F0B	 			25			NULL			089 		Y				EDCUSER		Y			2020-11-29 16:20:07.000	1			X
20201129	D			3WSTSCCRELKX001   	V650003A        5			20201129	8C255N27SL	2BKBC13ATB	 			25			NULL			273 		Y				EDCUSER		Y			2020-11-29 23:40:39.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003P        5			20201129	8C347137SL	2BKBC13P0B	 			25			NULL			226 		Y				EDCUSER		Y			2020-11-29 19:10:21.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003A        5			20201129	8C421936SL	2BKBC13AXB	 			25			NULL			190 		Y				EDCUSER		Y			2020-11-29 16:25:38.000	1			X
20201129	D			3WSTSCCRELKX001   	V650003A        5			20201129	8C503B99SL	2BKBC13AXB	 			25			NULL			266 		Y				EDCUSER		Y			2020-11-29 22:46:02.000	1			X
20201129	A			3WSTSCCRELKX001   	V650000Q        5			20201129	8C536H59SL	2SKBE100QB	 			25			NULL			348 		Y				EDCUSER		Y			2020-11-29 14:23:00.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003A        5			20201129	8C608G33SL	2BKBC13AXB	 			25			NULL			153 		Y				EDCUSER		Y			2020-11-29 12:41:26.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003A        5			20201129	8C715M82SL	2BKBC13ATB	 			25			NULL			198 		Y				EDCUSER		Y			2020-11-29 17:01:20.000	1			X
20201129	A			3WSTSCCRELKX001   	V650007D        5			20201129	8C806360SL	2TKBJ17D0B	 			25			NULL			097 		Y				EDCUSER		Y			2020-11-29 17:47:30.000	1			X
20201129	D			3WSTSCCRELKX001   	V650007D        5			20201129	8D202H93SL	2TKBJ17D0B	 			25			NULL			116 		Y				EDCUSER		Y			2020-11-29 23:58:50.000	1			X
20201129	A			3WSTSCCRELKX001   	V650000A        5			20201129	8D304H35SL	2SKBE10AXB	 			25			NULL			351 		Y				EDCUSER		Y			2020-11-29 14:50:52.000	1			X
20201128	D			3WSTSCCRELKX001   	V650000Q        5			20201129	8D401625SL	2SKBE100QB	 			25			NULL			330 		Y				EDCUSER		Y			2020-11-29 05:23:46.000	1			X
20201129	A			3WSTSCCRELKX001   	V650000Q        5			20201129	8D414H82SL	2SKBE100QB	 			25			NULL			344 		Y				EDCUSER		Y			2020-11-29 12:06:36.000	1			X
20201129	A			3WSTSCCRELKX001   	V650006F        5			20201129	8D501850SL	2BKBC16F0B	 			25			NULL			113 		Y				EDCUSER		Y			2020-11-29 08:00:01.000	1			X
20201128	D			3WSTSCCRELKX001   	V650000F        5			20201129	8D606E10SL	21KBE10F0B	 			25			NULL			194 		Y				EDCUSER		Y			2020-11-29 02:50:36.000	1			X
20201129	A			3WSTSCCRELKX001   	V650003P        5			20201129	8D610M54SL	2BKBC13P0B	 			25			NULL			201 		Y				EDCUSER		Y			2020-11-29 17:20:27.000	1			X
*/

/*
select * from [EDC].[dbo].[View_PackingImageFN]
453617筆
Barcode	                                (沒有資料行名稱)
-------------------------------------------------------
1-20220721-145843-WLM7I2TB07TP-25    	3
1-20221112-081434-HMMAE3NA0B  -12    	3
2-20211206-231754-ADL8P4NA2CTN-25    	2
1-20221203-083225-WLLRI1XB0CXP-25    	3
2-20220908-013837-PCM8E1A209A2-25    	3
5-20230420-WDZZU122ES-26N4C13AX4  -25	5
5-20230506-FE50D052TM-24N5E10AX5  -25	5
5-20230417-D060W289ZS-26N4J14P04  -25	5
5-20230222-HD0AE259TM-72N2J1NAO2  -25	4
5-20230208-WEHCP176ES-2SN1C16D02  -25	5
*/

		  -- 5-20171006-TY33E171SE-2PH9E10F0A  -25
		  -- 1234567890123456789012345678901234567
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)
/*

[RCS].[dbo].[FG_Barcode]
Category	MFGDate		MFGShift	Customer	FG_PSI				FG_Customer	   LotNo	Qty
-----------------------------------------------------------------------------------------------
Outside		20230720	D			TSC			3WSTSCCRELKX001   	V650021Q       22N741	225
Outside		20230721	A			PSC			3WSPSCCRELKC001   	02-14-0018     6AN7C1	25
Outside		20230721	A			TSC			3WSTSCCRELKX001   	V650007F       26N7J1	250
Outside		20230721	B			TSC			3WSTSCCRELKX001   	V650003A1      26N7C1	25
Outside		20230722	B			PSC			3WSPSCCRELKX001   	02-14-0025     6AN7E1	50
Outside		20230722	B			TSC			3WSTSCCRELKX001   	V65000311DD    23N7U1	475
Outside		20230722	B			TSC			3WSTSCCRELKX001   	V650003A1      26N7C1	25
Outside		20230722	B			TSC			3WSTSCCRELKX001   	V650006F       26N7R1	75
Outside		20230722	C			PSC			3WSPSCCRELKX001   	02-14-0025     6AN7E1	50
Outside		20230722	C			TSC			3WSTSCCRELKX001   	V65000311DD    23N7U1	400
Outside		20230723	C			TSC			3WSTSCCRELKX001   	V650006F       2SN7C1	25
Outside		20230724	A			INM			3WSINMCRELKC002   	180-ECDT8      52N5C1	25
Outside		20230724	A			TSC			3WSTSCCRELKX001   	V650006F1      29N7F1	25

*/
-----------------------------------1.Inside-------A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'-------------------------------------------
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
               ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock), [EDC].[dbo].[View_PackingImageFN] B  with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and A.FG_MFGDate<>'20201213' and A.FG_MFGDate<>'20201214'
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		  and A.FG_BarCode1=substring(B.Barcode, 1, 1)
		  and A.FG_BarCode2=substring(B.Barcode, 3, 8)
		  and A.FG_BarCode3=substring(B.Barcode, 12, 10)
		  and A.FG_BarCode4=substring(B.Barcode, 23, 10)
		  and A.FG_BarCode5=substring(B.Barcode, 33, 2)
		  and A.FG_BarCode6=substring(B.Barcode, 36, 2)
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)

-----------------------------------2.Outside-----(A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')---------------------------------------------
		-- Outside  20201213 virus crash
		union all
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)

-----------------------------------2.Inside-----(A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')---------------------------------------------
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
               ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		  and (A.FG_MFGDate='20201213' or A.FG_MFGDate='20201214')
		  --and ( A.FG_Valid='Y' or (A.FG_Valid='N' and A.FG_MFGDate<>convert(char(8), EDC.dbo.[RealDateToMfgDate]([Print_Date]), 112)) )
		  and  A.FG_Valid = 'Y'
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)

-----------------------------------3.Outside------A.FG_MFGDate>'20150101'--------------------------------------------
		-- Jasont requet 2019/7/30
		-- Outside
		union all
		select --'ID'=newid()
			   'Category'='Outside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
			   ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where A.FG_BarCode4 like '[1-9]%'
		  and A.FG_BarCode4 not like '3[KM]__X%'			--internal revenue
		  and A.FG_BarCode4 not like '9[5BCHKYT]__X_%'		--internal revenue
		  and A.FG_BarCode4 not like '[39]___[QVW]%'		--Oxide
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)
-----------------------------------3.Inside---A.FG_MFGDate>'20150101'-----------------------------------------------
		-- Inside
		union all
		select --'ID'=newid()
			   'Category'='Inside'
			   --,'MFG_Date'=cast(left(A.FG_MFGDate, 4)+'-'+subString(A.FG_MFGDate, 5, 2)+'-'+right(A.FG_MFGDate, 2) as datetime)
			   ,'MFGDate'=A.FG_MFGDate
			   ,'MFGShift'=A.FG_MFGType
			   --,'LotNo'=left(A.FG_BarCode4, 6)
			   ,'Customer'=substring(A.FG_PSI, 4, 3)
			   ,A.FG_PSI
			   ,A.FG_Customer
			   ,'LotNo'=left(A.FG_BarCode4,6)
               ,'Qty'=sum(cast(A.FG_BarCode6 as integer))
		from [RCS].[dbo].[FG_Barcode_His] A with(nolock)
		where (A.FG_BarCode4 like '3[KM]__X%' or 
		       A.FG_BarCode4 like '9[5BCHKYT]__X_%' or
		       A.FG_BarCode4 like 'PS_2[ME]_%')
		  and A.FG_Customer<>'V65000313G'
		  and A.FG_MFGDate>'20150101'
		 group by A.FG_MFGDate, A.FG_MFGType, substring(A.FG_PSI, 4, 3), A.FG_PSI, FG_Customer, left(A.FG_BarCode4,6)
		) x


GO

/*
MFGDate					MFGShift	Customer	PsiPN				CustomerPN	LotNo	Qty
-------------------------------------------------------------------------------------------
2022-05-03 00:00:00.000	N			PSI			3WSPSICRELKM001   	N/A			PSD2MZ	75
2022-05-04 00:00:00.000	D			PSI			3WSPSICRELKM001   	N/A			PSD2MZ	75
2022-05-05 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	175
2022-05-05 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	275
2022-05-05 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	150
2022-05-06 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	500
2022-05-06 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	300
2022-05-07 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	500
2022-05-13 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	250
2022-05-14 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	75
2022-05-20 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	100
2022-06-02 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	50
2022-06-02 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	175
2022-06-03 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	50
2022-06-03 00:00:00.000	N			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	25
2022-06-04 00:00:00.000	D			HGY			4WSHGYCRELKX100   	N/A			9YM5X1	150
*/


