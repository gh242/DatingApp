/*
with CTE	as (
select N=0
union all 
select N+1 from CTE where N<DateDiff(day, @EndDate-1*@DistanceDaily, @EndDate) 
),

TempDay as (
select 'MFG_Date'=cast(DateAdd(day, -1*N, @EndDate) as date) from CTE
),
*/

with TempA as (
select MFGDate, 'OutputQtyHigh'=sum(OutputQtyHigh), 'OutputQtyNormal'=sum(OutputQtyNormal), 'OutputQtyLow'=sum(OutputQtyLow)
from (
select MFGDate
       ,'OutputQtyHigh'=sum(Qty)
       ,'OutputQtyNormal'=0
       ,'OutputQtyLow'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between (@EndDate-1*@DistanceDaily) and @EndDate
and CustomerPN like '%P'
group by MFGDate
union all
select MFGDate
       ,'OutputQtyHigh'=0
       ,'OutputQtyNormal'=sum(Qty)
       ,'OutputQtyLow'=0
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between (@EndDate-1*@DistanceDaily) and @EndDate
and CustomerPN not like '%[DFP]'
and CustomerPN not like '%F1'
and CustomerPN not like '02-14-0018'
and CustomerPN not like '02-14-002[156]'
and CustomerPN not like '02-14-003[034]'
and LotNo not like 'PSD2MZ_F[TX]%]'
group by MFGDate
union all
select MFGDate
       ,'OutputQtyHigh'=0
       ,'OutputQtyNormal'=0
       ,'OutputQtyLow'=sum(Qty)
from SSRS_Output_300mm_LotNo with(nolock)
where MFGDate between (@EndDate-1*@DistanceDaily) and @EndDate
and (CustomerPN like '%[DF]' or 
         CustomerPN like '%F1' or
         CustomerPN like '02-14-0018' or  
         CustomerPN like '02-14-002[156]' or 
         CustomerPN like '02-14-003[034]'or
         LotNo like 'PSD2MZ_F[TX]%]') 
group by MFGDate
union all
select 'MFGDate'=cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
       ,'OutputQtyHigh'=0
       ,'OutputQtyNormal'=-1*sum(MFG_MOVE)
       ,'OutputQtyLow'=0
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between convert(char(8), @EndDate-1*@DistanceDaily, 112) 
and convert(char(8), @EndDate, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
group by cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
) x
group by MFGDate),

TempB as (
select MFGDate
          ,CustomerPN
         ,'Qty'=sum(Qty)
from SSRS_Output_300mm with(nolock)
where MFGDate between (@EndDate-1*@DistanceDaily) and @EndDate
group by MFGDate, CustomerPN
/*
union all
select 'MFGDate'=cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
       ,'CustomerPN'='Rework'
       ,'Qty'=-1*sum(MFG_MOVE)
from [RCS_NEW].[dbo].[FN_MFG_WORK] with(nolock)
where MFG_Date between convert(char(8), @EndDate-1*@DistanceDaily, 112) 
and convert(char(8), @EndDate, 112) 
and MFG_EQUID=810
and MFG_LOTNO like '%RR%'
group by cast(left(MFG_DATE, 4)+'-'+substring(MFG_DATE, 5, 2)+'-'+right(MFG_DATE, 2) as Smalldatetime)
*/
),

TempC as (
select x.RN
         ,'KDMAT'=case when x.KDMAT like '_% _%' then left(x.KDMAT, charindex(' ', x.KDMAT)-1)
                                   else x.KDMAT
                                   end
         ,x.SalePrice
from (
   select 'RN'=row_number() over (partition by case when KDMAT like '_% _%' then left(KDMAT, charindex(' ', KDMAT)-1)
                                   else KDMAT
                                   end 
                                                          order by AUDAT desc)
              ,KDMAT
              ,'SalePrice'=case when KDMAT like '199900000000020%' then 580
                                        else NETPR*KURSK
                                        end
   from sap_sd_so_v
   where NETPR>0
   and VKORG='1100'
   ) x
where x.RN=1),

TempD as (
select b.MFGDate, 'Revenue'=sum(b.Qty*isnull(c.SalePrice, 300))
from TempB b left join TempC c
on b.CustomerPN=c.KDMAT
group by b.MFGDate)


--select 'MFGDate'=right(convert(char(10), x.MFGDate, 111), 5)
select x.MFGDate
         ,OutputQtyHigh
         ,OutputQtyNormal
         ,OutputQtyLow
         ,'OutputQtyA'=[WarInfo].[dbo].[AccumalateOutput]('300mm', x.MFGDate)
         ,'TargetQty'=y.TargetQty300mm
         ,'TargetQtyA'=[WarInfo].[dbo].[AccumalateTargetOutput]('300mm', x.MFGDate)
          ,z.Revenue
from TempA x left join [WarInfo].[dbo].[TargetOutput] y with(nolock)
	               --on convert(char(6), x.MFGDate, 112)=convert(char(6), y.TargetDate, 112)
                              on x.MFGDate=y.TargetDate
                        left join TempD z
	              on x.MFGDate=z.MFGDate
order by x.MFGDate desc



/*
執行時間為:20230721 13:56
產生結果如下 
跑了4分57秒
MFGDate	                    OutputQtyHigh  OutputQtyNormal	OutputQtyLow	OutputQtyA	TargetQty	TargetQtyA	Revenue
-------------------------------------------------------------------------------------------------------------------------------
2023-07-04 00:00:00.000	    1025	        9000	        3875	        52425	    11506	    46024	    6066586.8750000
2023-07-03 00:00:00.000	    625	            9475	        3400	        38525	    11506	    34518	    5778108.8750000
2023-07-02 00:00:00.000	    950	            7450	        3650	        25025	    11506	    23012	    5083095.0000000
2023-07-01 00:00:00.000	    1150	        7925	        3900	        12975	    11506	    11506	    5469943.1000000
2023-06-30 00:00:00.000	    725	            7950	        3500	        384336	    12850	    385500	    5146996.8000000
2023-06-29 00:00:00.000	    925	            7000	        3475	        372161	    12850	    372650	    4784089.6750000
2023-06-28 00:00:00.000	    1375	        7539	        3500	        360761	    12850	    359800	    5631149.2000000
2023-06-27 00:00:00.000	    1100	        8148	        3975	        348347	    12850	    346950	    5831510.3000000
2023-06-26 00:00:00.000	    1225	        7495	        3750	        335124	    12850	    334100	    5387725.7500000
2023-06-25 00:00:00.000	    1350	        7799	        3925	        322654	    12850	    321250	    5559699.3500000
2023-06-24 00:00:00.000	    1250	        9200	        4025	        309580	    12850	    308400	    6110542.2500000
2023-06-23 00:00:00.000	    1250	        8689	        4000	        295105	    12850	    295550	    6121494.7250000
2023-06-22 00:00:00.000	    1125	        8575	        3525	        281166	    12850	    282700	    5754577.5750000
2023-06-21 00:00:00.000	    1425	        8838	        3275	        267941	    12850	    269850	    5929051.8750000
2023-06-20 00:00:00.000	    1050	        8875	        3400	        254403	    12850	    257000	    5772352.4250000
2023-06-19 00:00:00.000	    725	            7425	        4000	        241078	    12850	    244150	    5103451.9500000
2023-06-18 00:00:00.000	    1200	        9100	        3575	        228928	    12850	    231300	    5856030.0000000
2023-06-17 00:00:00.000	    1275	        8110	        3700	        215053	    12850	    218450	    6039905.6250000
2023-06-16 00:00:00.000	    1125	        7322	        3650	        201968	    12850	    205600	    5615091.8750000
2023-06-15 00:00:00.000	    1200	        7793	        3675	        189871	    12850	    192750	    5475607.5000000
2023-06-14 00:00:00.000	    1200	        8400	        3125	        177203	    12850	    179900	    5491192.5000000
2023-06-13 00:00:00.000	    1050	        7500	        3875	        164478	    12850	    167050	    5410976.2500000
2023-06-12 00:00:00.000	    1225	        7850	        3950	        152053	    12850	    154200	    5568429.3750000
2023-06-11 00:00:00.000	    1100	        8945	        3425	        139028	    12850	    141350	    5797322.3000000
2023-06-10 00:00:00.000	    950	            8651	        3600	        125558	    12850	    128500	    5690425.8000000
2023-06-09 00:00:00.000	    1125	        7204	        3550	        112357	    12850	    115650	    5135216.8750000
2023-06-08 00:00:00.000	    950	            7710	        3525	        100478	    12850	    102800	    5139551.2500000
2023-06-07 00:00:00.000	    1400	        8427	        3075	        88293	    12850	    89950	    5557987.5000000
2023-06-06 00:00:00.000	    1525	        7875	        2975	        75391	    12850	    77100	    5349805.6750000
2023-06-05 00:00:00.000	    1400	        7625	        3050	        63016	    12850	    64250	    5269711.0000000
2023-06-04 00:00:00.000	    1625	        8150	        3250	        50941	    12850	    51400	    5609612.0250000
2023-06-03 00:00:00.000	    1600	        7677	        3550	        37916	    12850	    38550	    5450064.0000000

*/