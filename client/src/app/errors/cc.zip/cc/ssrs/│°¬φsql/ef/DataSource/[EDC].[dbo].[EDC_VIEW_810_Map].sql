USE [EDC]
GO

/****** Object:  View [dbo].[EDC_VIEW_810_Map]    Script Date: 2023/7/26 上午 10:35:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






ALTER VIEW [dbo].[EDC_VIEW_810_Map]
AS
SELECT     dbo.EDC_DATA_810.STATION_NAME, dbo.EDC_DATA_810.COLLECTION_TIME, dbo.EDC_DATA_810.WAFER_SEQ AS SourceSlot, 
                      CASE WHEN dbo.EDC_DATA_810.PLANT_ORDER = '' THEN 0 ELSE CAST(dbo.EDC_DATA_810.PLANT_ORDER AS Smallint) END AS 'DestinationSlot', 
                      CASE WHEN Lot_ID IS NULL OR
                      Lot_ID = ' ' THEN 'TEST' ELSE Lot_ID END AS 'Lot_ID', CASE WHEN (Recipe = 'PSC213-8A' OR
                      Recipe = 'PSC230-8A') AND AVG_PARTICLE = 0 THEN 'GRADEA' WHEN Recipe = 'PSC213-8S' AND AVG_PARTICLE = 0 THEN 'GRADES' WHEN (Recipe = '215550-5B' OR
                      Recipe = '215120-5B' OR
                      Recipe = 'T8-5B') AND AVG_PARTICLE = 0 THEN 'GRADEB' WHEN (Recipe = '215550-5B' OR
                      Recipe = '215120-5B' OR
                      Recipe = 'T8-5B') AND (AVG_PARTICLE = 1 OR
                      AVG_PARTICLE = 2) THEN 'REJECT' WHEN (Recipe = '215550-5D' OR
                      Recipe = '215120-5D' OR
                      Recipe = 'T8-5D') AND AVG_PARTICLE = 0 THEN 'GRADED' WHEN (Recipe = '215550-5D' OR
                      Recipe = '215120-5D' OR
                      Recipe = 'T8-5D') AND (AVG_PARTICLE = 1 OR
                      AVG_PARTICLE = 2) THEN 'REJECT' WHEN Recipe <> '215550-5B' AND Recipe <> '215550-5D' AND Recipe <> '215120-5B' AND Recipe <> '215120-5D' AND 
                      Recipe <> 'T8-5B' AND Recipe <> 'T8-5D' AND AVG_PARTICLE = 0 THEN 'PASS' WHEN Recipe <> '215550-5B' AND Recipe <> '215550-5D' AND 
                      Recipe <> '215120-5B' AND Recipe <> '215120-5D' AND Recipe <> 'T8-5B' AND Recipe <> 'T8-5D' AND (AVG_PARTICLE = 1 OR
                      AVG_PARTICLE = 2) THEN 'REJECT' ELSE 'REJECTED' END AS 'WaferGrade', dbo.EDC_DATA_810.RECIPE AS PPExecName, 
                      CASE WHEN (Station_Name = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') 
                      THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4
                       + df_defect_bin_limits_5 + df_defect_bin_limits_6 + df_defect_bin_limits_7) 
                      WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4
                       + df_defect_bin_limits_5 + df_defect_bin_limits_6) 
                      WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4
                       + df_defect_bin_limits_5) 
                      WHEN maintain_seq = 5 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4)
                       WHEN maintain_seq = 4 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3) 
                      WHEN maintain_seq = 3 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1 + df_defect_bin_limits_2) 
                      WHEN maintain_seq = 2 THEN (df_defect_min + df_defect_bin_limits_0 + df_defect_bin_limits_1) 
                      WHEN maintain_seq = 1 THEN (df_defect_min + df_defect_bin_limits_0) ELSE df_defect_bin_limits_0 END ELSE particle_cnt_0 END AS 'Flaw_Counts_0', 
                      CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') 
                      THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5
                       + df_defect_bin_limits_6 + df_defect_bin_limits_7) 
                      WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5
                       + df_defect_bin_limits_6) 
                      WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5)
                       WHEN maintain_seq = 5 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4) 
                      WHEN maintain_seq = 4 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2 + df_defect_bin_limits_3) 
                      WHEN maintain_seq = 3 THEN (df_defect_min + df_defect_bin_limits_1 + df_defect_bin_limits_2) 
                      WHEN maintain_seq = 2 THEN (df_defect_min + df_defect_bin_limits_1) 
                      WHEN maintain_seq = 1 THEN 0 ELSE df_defect_bin_limits_1 END ELSE particle_cnt_1 END AS 'Flaw_Counts_1', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') 
                      THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6
                       + df_defect_bin_limits_7) 
                      WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6)
                       WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5) 
                      WHEN maintain_seq = 5 THEN (df_defect_min + df_defect_bin_limits_2 + df_defect_bin_limits_3 + df_defect_bin_limits_4) 
                      WHEN maintain_seq = 4 THEN (df_defect_min + df_defect_bin_limits_2 + df_defect_bin_limits_3) 
                      WHEN maintain_seq = 3 THEN (df_defect_min + df_defect_bin_limits_2) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 THEN 0 ELSE df_defect_bin_limits_2 END ELSE particle_cnt_2 END AS 'Flaw_Counts_2', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') 
                      THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6 + df_defect_bin_limits_7)
                       WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6) 
                      WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_3 + df_defect_bin_limits_4 + df_defect_bin_limits_5) 
                      WHEN maintain_seq = 5 THEN (df_defect_min + df_defect_bin_limits_3 + df_defect_bin_limits_4) 
                      WHEN maintain_seq = 4 THEN (df_defect_min + df_defect_bin_limits_3) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 OR
                      maintain_seq = 3 THEN 0 ELSE df_defect_bin_limits_3 END ELSE particle_cnt_3 END AS 'Flaw_Counts_3', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') 
                      THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6 + df_defect_bin_limits_7) 
                      WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_4 + df_defect_bin_limits_5 + df_defect_bin_limits_6) 
                      WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_4 + df_defect_bin_limits_5) 
                      WHEN maintain_seq = 5 THEN (df_defect_min + df_defect_bin_limits_4) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 OR
                      maintain_seq = 3 OR
                      maintain_seq = 4 THEN 0 ELSE df_defect_bin_limits_4 END ELSE particle_cnt_4 END AS 'Flaw_Counts_4', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_5 + df_defect_bin_limits_6 + df_defect_bin_limits_7)
                       WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_5 + df_defect_bin_limits_6) 
                      WHEN maintain_seq = 6 THEN (df_defect_min + df_defect_bin_limits_5) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 OR
                      maintain_seq = 3 OR
                      maintain_seq = 4 OR
                      maintain_seq = 5 THEN 0 ELSE df_defect_bin_limits_5 END ELSE particle_cnt_5 END AS 'Flaw_Counts_5', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_6 + df_defect_bin_limits_7) 
                      WHEN maintain_seq = 7 THEN (df_defect_min + df_defect_bin_limits_6) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 OR
                      maintain_seq = 3 OR
                      maintain_seq = 4 OR
                      maintain_seq = 5 OR
                      maintain_seq = 6 THEN 0 ELSE df_defect_bin_limits_6 END ELSE particle_cnt_6 END AS 'Flaw_Counts_6', CASE WHEN (STATION_NAME = 'TENCOR_02' OR
                      STATION_NAME = 'TENCOR_03') THEN CASE WHEN maintain_seq = 8 THEN (df_defect_min + df_defect_bin_limits_7) WHEN maintain_seq = 1 OR
                      maintain_seq = 2 OR
                      maintain_seq = 3 OR
                      maintain_seq = 4 OR
                      maintain_seq = 5 OR
                      maintain_seq = 6 OR
                      maintain_seq = 7 THEN 0 ELSE df_defect_bin_limits_7 END ELSE particle_cnt_7 END AS 'Flaw_Counts_7', dbo.EDC_DATA_810.DF_DEFECT_MIN AS Flaw_Counts_8, 
                      dbo.EDC_DATA_810.DF_SCRATCH_COUNT AS Flaw_Counts_9, dbo.EDC_DATA_810.DF_DEFECT_STDV AS Flaw_Counts_10, 
                      dbo.EDC_DATA_810.HAZE_LEVEL_9 AS Flaw_Counts_11, 0 AS 'Flaw_Counts_12', 0 AS 'Flaw_Counts_13', 0 AS 'Flaw_Counts_14', 0 AS 'Flaw_Counts_15', 
                      0 AS 'Flaw_Counts_16', 0 AS 'Flaw_Counts_17', 0 AS 'Flaw_Counts_18', 0 AS 'Flaw_Counts_19', 0 AS 'Flaw_Counts_20', 0 AS 'Flaw_Counts_21', 
                      0 AS 'Flaw_Counts_22', 0 AS 'Flaw_Counts_23', 0 AS 'Flaw_Counts_24', 0 AS 'Flaw_Counts_25', 0 AS 'Flaw_Counts_26', 0 AS 'Flaw_Counts_27', 
                      0 AS 'Flaw_Counts_28', 0 AS 'Flaw_Counts_29', dbo.EDC_DATA_810.AVG_HAZE AS HazeAverage, 0 AS 'HazePeak', 0 AS 'DFNHazeAvg', 0 AS 'DFNHazePeak', 
                      CAST(dbo.EDC_DATA_810.HAZE_LEVEL_0 AS Numeric(8, 2)) AS 'Haze_Counts_0', CAST(dbo.EDC_DATA_810.HAZE_LEVEL_1 AS Numeric(8, 2)) AS 'Haze_Counts_1', 
                      CAST(dbo.EDC_DATA_810.HAZE_LEVEL_2 AS Numeric(8, 2)) AS 'Haze_Counts_2', CAST(dbo.EDC_DATA_810.HAZE_LEVEL_3 AS Numeric(8, 2)) AS 'Haze_Counts_3', 
                      CAST(dbo.EDC_DATA_810.HAZE_LEVEL_4 AS Numeric(8, 2)) AS 'Haze_Counts_4', CAST(dbo.EDC_DATA_810.HAZE_LEVEL_5 AS Numeric(8, 2)) AS 'Haze_Counts_5', 
                      CAST(dbo.EDC_DATA_810.HAZE_LEVEL_6 AS Numeric(8, 2)) AS 'Haze_Counts_6', CAST(dbo.EDC_DATA_810.HAZE_LEVEL_7 AS Numeric(8, 2)) AS 'Haze_Counts_7', 
                      CAST(dbo.EDC_DATA_810.HAZE_LEVEL_8 AS Numeric(8, 2)) AS 'Haze_Counts_8', 0 AS 'Haze_Counts_9', dbo.EDC_DATA_810_Map.KlarfName, 
                      dbo.EDC_DATA_810_Map.Map, 0 AS 'Sumofallcount_Unclustered', 0 AS 'DFTotalSlipLineLength'
					  ,[EDC].[dbo].[Equipment_List].EquipmentSN as EquipmentNo --add EquipmentSN
FROM         dbo.EDC_DATA_810 WITH (Nolock) LEFT OUTER JOIN
                      dbo.EDC_DATA_810_Map WITH (Nolock) ON dbo.EDC_DATA_810.STATION_NAME = dbo.EDC_DATA_810_Map.StationName AND 
                      dbo.EDC_DATA_810.COLLECTION_TIME = dbo.EDC_DATA_810_Map.CollectionTime
					  LEFT join [EDC].[dbo].[Equipment_List] on dbo.EDC_DATA_810.STATION_NAME = [EDC].[dbo].[Equipment_List].StationName --add EquipmentSN
WHERE     (dbo.EDC_DATA_810.MACHINE_ID IS NOT NULL)
UNION ALL
SELECT     dbo.EDC_VIEW_TBI.StationName, dbo.EDC_VIEW_TBI.CollectionTime, dbo.EDC_VIEW_TBI.SrcSlotID, dbo.EDC_VIEW_TBI.DestSlotID, dbo.EDC_VIEW_TBI.LotID, 
                      CASE WHEN (EDC_VIEW_TBI.RecipeName = 'TEST-MIX' OR
                      EDC_VIEW_TBI.RecipeName = 'TEST-RECLEAN' OR
                      EDC_VIEW_TBI.RecipeName = 'TS-12X' OR
                      EDC_VIEW_TBI.RecipeName = 'T12_F') 
                      THEN CASE WHEN EDC_VIEW_TBI.DispositionName = 'GRADED' or EDC_VIEW_TBI.DispositionName = 'GRADEE' or EDC_VIEW_TBI.DispositionName
                       LIKE 'GRADEF%' THEN 'Mechanical' ELSE EDC_VIEW_TBI.DispositionName END WHEN EDC_VIEW_TBI.RecipeName = 'NE-12' THEN CASE WHEN EDC_VIEW_TBI.DispositionName
                       = 'PASS' AND 
                      DFDefectBinCount_2 > 10 THEN 'RECLEAN' ELSE EDC_VIEW_TBI.DispositionName END ELSE EDC_VIEW_TBI.DispositionName END AS 'EDC_VIEW_TBI.DispositionName',
                       dbo.EDC_VIEW_TBI.RecipeName, dbo.EDC_VIEW_TBI.DFDefectBinCount_1, dbo.EDC_VIEW_TBI.DFDefectBinCount_2, dbo.EDC_VIEW_TBI.DFDefectBinCount_3, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_4, dbo.EDC_VIEW_TBI.DFDefectBinCount_5, dbo.EDC_VIEW_TBI.DFDefectBinCount_6, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_7, dbo.EDC_VIEW_TBI.DFDefectBinCount_8, dbo.EDC_VIEW_TBI.DFDefectBinCount_9, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_10, dbo.EDC_VIEW_TBI.DFDefectBinCount_11, dbo.EDC_VIEW_TBI.DFDefectBinCount_12, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_13, dbo.EDC_VIEW_TBI.DFDefectBinCount_14, dbo.EDC_VIEW_TBI.DFDefectBinCount_15, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_16, dbo.EDC_VIEW_TBI.DFDefectBinCount_17, dbo.EDC_VIEW_TBI.DFDefectBinCount_18, 
                      dbo.EDC_VIEW_TBI.DFDefectBinCount_19, 
					  --ISNULL(dbo.EDC_VIEW_TBI.DFAreaCount, 0) AS Expr1, 20220323 add SP5 要直接取DFAreaCount即為cluster值(request by Season)
					  case when EDC_VIEW_TBI.RecipeName like '%IMC303-3%' and  EDC_VIEW_TBI.StationName<>'TENCOR_12' then ISNULL(dbo.EDC_VIEW_TBI.DFAreaCount, 0)-ISNULL(dbo.EDC_VIEW_TBI.[DFDefectBinCount_18], 0) 
							else ISNULL(dbo.EDC_VIEW_TBI.DFAreaCount, 0) end AS Expr1, 
					  ISNULL(dbo.EDC_VIEW_TBI.DFScratchCount, 0) AS Expr2, 
                      ISNULL(dbo.EDC_VIEW_TBI.DFTotalArea, 0) AS Expr3, ISNULL(dbo.EDC_VIEW_TBI.DFTotalScratchLength, 0) AS Expr4, dbo.EDC_VIEW_TBI.DFDefectLPDNCount_1, 
                      dbo.EDC_VIEW_TBI.DFDefectLPDNCount_2, dbo.EDC_VIEW_TBI.DFDefectLPDNCount_3, dbo.EDC_VIEW_TBI.DFDefectLPDNCount_4, 
                      dbo.EDC_VIEW_TBI.DFDefectLPDNCount_5, dbo.EDC_VIEW_TBI.DFDefectLPDNCount_6, dbo.EDC_VIEW_TBI.DFSumAllDefects, dbo.EDC_VIEW_TBI.DFHazeAvg, 
                      dbo.EDC_VIEW_TBI.DFHazePeak, dbo.EDC_VIEW_TBI.DFNHazeAvg, dbo.EDC_VIEW_TBI.DFNHazePeak, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_1, 
                      dbo.EDC_VIEW_TBI.DFHazeBinPercentage_2, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_3, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_4, 
                      dbo.EDC_VIEW_TBI.DFHazeBinPercentage_5, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_6, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_7, 
                      dbo.EDC_VIEW_TBI.DFHazeBinPercentage_8, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_9, dbo.EDC_VIEW_TBI.DFHazeBinPercentage_10, 
                      EDC_DATA_810_Map_1.KlarfName, EDC_DATA_810_Map_1.Map, dbo.EDC_VIEW_TBI.Sumofallcount_Unclustered, dbo.EDC_VIEW_TBI.DFTotalSlipLineLength
					  ,[EDC].[dbo].[Equipment_List].EquipmentSN as EquipmentNo  --add  EquipmentSN
FROM         dbo.EDC_VIEW_TBI WITH (Nolock) LEFT OUTER JOIN
                      dbo.EDC_DATA_810_Map AS EDC_DATA_810_Map_1 WITH (Nolock) ON dbo.EDC_VIEW_TBI.StationName = EDC_DATA_810_Map_1.StationName AND 
                      dbo.EDC_VIEW_TBI.CollectionTime = EDC_DATA_810_Map_1.CollectionTime
					  LEFT join [EDC].[dbo].[Equipment_List] on dbo.EDC_VIEW_TBI.StationName = [EDC].[dbo].[Equipment_List].StationName --add  EquipmentSN
WHERE     (dbo.EDC_VIEW_TBI.DispositionName IS NOT NULL)
GO


