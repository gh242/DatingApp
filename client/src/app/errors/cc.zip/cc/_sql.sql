/****** SSMS 中 SelectTopNRows 命令的指令碼  ******/
SELECT TOP (1000) [StationName]
      ,[CollectionTime]
      ,[LotID]
      ,[SrcSlotID]
      ,[DispositionName]
      ,[RecipeName]
      ,[KlarfName]
      ,[Map]
  FROM [EDC].[dbo].[EDC_DATA_810_Map]
  where [DispositionName] > '2023-07-11'