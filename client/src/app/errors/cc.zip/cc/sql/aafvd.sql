USE [EDC]
GO

SELECT [StationName]
      ,[CollectionTime]
      ,[LotID]
      ,[SrcSlotID]
      ,[DispositionName]
      ,[RecipeName]
      ,[KlarfName]
      ,[Map]
  FROM [dbo].[EDC_DATA_810_Map]
  Where 
  CollectionTime>='2023/7/11 09:30:00'
  --and   CollectionTime <='2023/7/11 10:30:00'


	